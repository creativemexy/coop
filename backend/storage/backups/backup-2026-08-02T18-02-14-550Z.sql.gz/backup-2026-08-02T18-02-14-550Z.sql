--
-- PostgreSQL database dump
--

\restrict 7LF6XupuJlEB4G6r3wDY664qvsSshXUWQUFrc0ivQ4bpcCKr43LND4XBresXy2C

-- Dumped from database version 16.13 (Homebrew)
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: accounts_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.accounts_type_enum AS ENUM (
    'asset',
    'liability',
    'equity',
    'revenue',
    'expense'
);


--
-- Name: adjustment_requests_adjustment_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.adjustment_requests_adjustment_type_enum AS ENUM (
    'metadata_correction',
    'journal_entry'
);


--
-- Name: adjustment_requests_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.adjustment_requests_status_enum AS ENUM (
    'pending',
    'approved',
    'rejected'
);


--
-- Name: apex_organizations_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.apex_organizations_status_enum AS ENUM (
    'active',
    'inactive'
);


--
-- Name: audit_logs_action_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.audit_logs_action_enum AS ENUM (
    'LOGIN',
    'LOGIN_FAILED',
    'LOGOUT',
    'PASSWORD_CHANGE',
    'PASSWORD_RESET',
    'USER_CREATE',
    'USER_UPDATE',
    'USER_DEACTIVATE',
    'USER_DELETE',
    'ROLE_CHANGE',
    'KYC_SUBMIT',
    'KYC_APPROVE',
    'KYC_REJECT',
    'SETTINGS_CHANGE',
    'BRANDING_CHANGE',
    'RETENTION_PURGE',
    'LOAN_APPROVE',
    'LOAN_REJECT'
);


--
-- Name: bnpl_approval_requests_request_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_approval_requests_request_type_enum AS ENUM (
    'product_change',
    'manual_override',
    'user_suspension',
    'write_off',
    'restructuring',
    'eligibility_exception',
    'tenant_product_enablement',
    'policy_template_change'
);


--
-- Name: bnpl_approval_requests_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_approval_requests_status_enum AS ENUM (
    'pending',
    'approved',
    'rejected'
);


--
-- Name: bnpl_collection_playbooks_trigger_event_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_collection_playbooks_trigger_event_enum AS ENUM (
    'first_delinquency',
    'repeated_delinquency',
    'high_risk',
    'payment_failure',
    'exception_case'
);


--
-- Name: bnpl_collection_priorities_entity_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_collection_priorities_entity_type_enum AS ENUM (
    'subscription',
    'user'
);


--
-- Name: bnpl_collection_priorities_priority_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_collection_priorities_priority_enum AS ENUM (
    'low',
    'medium',
    'high',
    'critical'
);


--
-- Name: bnpl_collection_queues_priority_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_collection_queues_priority_enum AS ENUM (
    'low',
    'medium',
    'high',
    'critical'
);


--
-- Name: bnpl_collection_queues_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_collection_queues_status_enum AS ENUM (
    'pending',
    'contacted',
    'in_negotiation',
    'escalated',
    'resolved',
    'closed'
);


--
-- Name: bnpl_exception_cases_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_exception_cases_status_enum AS ENUM (
    'open',
    'investigating',
    'resolved',
    'escalated'
);


--
-- Name: bnpl_exception_reasons_category_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_exception_reasons_category_enum AS ENUM (
    'failed_payment',
    'late_payment',
    'mismatch_amount',
    'missing_webhook',
    'eligibility_exception',
    'other'
);


--
-- Name: bnpl_exception_reasons_escalation_action_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_exception_reasons_escalation_action_enum AS ENUM (
    'auto_resolve',
    'manual_review',
    'supervisor_escalation',
    'write_off'
);


--
-- Name: bnpl_installments_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_installments_status_enum AS ENUM (
    'pending',
    'paid',
    'overdue'
);


--
-- Name: bnpl_plan_configs_due_date_rule_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_plan_configs_due_date_rule_enum AS ENUM (
    'same_day_monthly',
    'end_of_month'
);


--
-- Name: bnpl_plan_configs_interest_model_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_plan_configs_interest_model_enum AS ENUM (
    'fixed_monthly_fee',
    'reducing_balance',
    'simple'
);


--
-- Name: bnpl_plan_configs_late_fee_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_plan_configs_late_fee_type_enum AS ENUM (
    'percentage',
    'flat'
);


--
-- Name: bnpl_plans_interest_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_plans_interest_type_enum AS ENUM (
    'flat',
    'monthly_fee',
    'reducing_balance'
);


--
-- Name: bnpl_plans_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_plans_status_enum AS ENUM (
    'active',
    'inactive',
    'retired'
);


--
-- Name: bnpl_processing_steps_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_processing_steps_status_enum AS ENUM (
    'pending',
    'in_progress',
    'completed',
    'failed'
);


--
-- Name: bnpl_processing_steps_step_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_processing_steps_step_type_enum AS ENUM (
    'payment_intent',
    'disbursement',
    'installment_generation',
    'settlement',
    'reconciliation'
);


--
-- Name: bnpl_risk_flags_entity_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_risk_flags_entity_type_enum AS ENUM (
    'subscription',
    'user'
);


--
-- Name: bnpl_risk_flags_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_risk_flags_status_enum AS ENUM (
    'open',
    'investigating',
    'resolved',
    'dismissed'
);


--
-- Name: bnpl_subscriptions_payout_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_subscriptions_payout_status_enum AS ENUM (
    'pending',
    'completed',
    'failed'
);


--
-- Name: bnpl_subscriptions_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bnpl_subscriptions_status_enum AS ENUM (
    'created',
    'pending_payment',
    'disbursed',
    'active_repayment',
    'settled',
    'defaulted'
);


--
-- Name: disputes_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.disputes_status_enum AS ENUM (
    'opened',
    'investigating',
    'resolved',
    'dismissed'
);


--
-- Name: disputes_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.disputes_type_enum AS ENUM (
    'bnpl',
    'investment',
    'payment',
    'other'
);


--
-- Name: distribution_runs_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.distribution_runs_status_enum AS ENUM (
    'computing',
    'payouts_ready',
    'approved',
    'paid',
    'failed'
);


--
-- Name: distributions_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.distributions_status_enum AS ENUM (
    'draft',
    'pending_approval',
    'approved',
    'executed',
    'failed'
);


--
-- Name: distributions_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.distributions_type_enum AS ENUM (
    'dividend',
    'interest',
    'profit_share'
);


--
-- Name: feature_flags_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.feature_flags_status_enum AS ENUM (
    'enabled',
    'disabled',
    'rolling_out',
    'deprecated'
);


--
-- Name: fee_pots_pot_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.fee_pots_pot_type_enum AS ENUM (
    'business_manager',
    'platform',
    'organization',
    'apex',
    'admin'
);


--
-- Name: fee_share_ledger_source_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.fee_share_ledger_source_enum AS ENUM (
    'bnpl',
    'loan',
    'investment',
    'registration'
);


--
-- Name: in_app_notifications_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.in_app_notifications_type_enum AS ENUM (
    'info',
    'success',
    'warning',
    'error'
);


--
-- Name: incidents_severity_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.incidents_severity_enum AS ENUM (
    'critical',
    'high',
    'medium',
    'low'
);


--
-- Name: incidents_source_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.incidents_source_enum AS ENUM (
    'monitoring',
    'user_reported',
    'system_alert',
    'payment_failure',
    'security',
    'performance'
);


--
-- Name: incidents_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.incidents_status_enum AS ENUM (
    'detected',
    'investigating',
    'mitigated',
    'resolved',
    'closed'
);


--
-- Name: investment_corporate_actions_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_corporate_actions_status_enum AS ENUM (
    'pending',
    'approved',
    'executed',
    'cancelled'
);


--
-- Name: investment_corporate_actions_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_corporate_actions_type_enum AS ENUM (
    'split',
    'bonus',
    'dividend',
    'buyback'
);


--
-- Name: investment_eligibility_rules_kyc_required_level_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_eligibility_rules_kyc_required_level_enum AS ENUM (
    'none',
    'basic',
    'advanced'
);


--
-- Name: investment_orders_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_orders_status_enum AS ENUM (
    'placed',
    'payment_confirmed',
    'invested',
    'allocated',
    'cancelled',
    'failed'
);


--
-- Name: investment_pricing_config_accrual_method_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_pricing_config_accrual_method_enum AS ENUM (
    'simple',
    'compound'
);


--
-- Name: investment_pricing_config_formula_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_pricing_config_formula_type_enum AS ENUM (
    'simple',
    'nav_based'
);


--
-- Name: investment_pricing_config_nav_schedule_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_pricing_config_nav_schedule_enum AS ENUM (
    'daily',
    'weekly',
    'monthly'
);


--
-- Name: investment_products_distributionfrequency_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_products_distributionfrequency_enum AS ENUM (
    'monthly',
    'quarterly',
    'annually',
    'maturity'
);


--
-- Name: investment_products_risktier_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_products_risktier_enum AS ENUM (
    'low',
    'medium',
    'high'
);


--
-- Name: investment_products_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_products_status_enum AS ENUM (
    'draft',
    'pending_review',
    'active',
    'suspended',
    'closed',
    'archived'
);


--
-- Name: investment_products_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.investment_products_type_enum AS ENUM (
    'shares',
    'fixed_income',
    'pooled'
);


--
-- Name: journal_entries_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.journal_entries_status_enum AS ENUM (
    'draft',
    'posted'
);


--
-- Name: kyc_submissions_provider_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.kyc_submissions_provider_enum AS ENUM (
    'korapay'
);


--
-- Name: kyc_submissions_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.kyc_submissions_status_enum AS ENUM (
    'none',
    'pending',
    'approved',
    'rejected'
);


--
-- Name: loan_repayments_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.loan_repayments_status_enum AS ENUM (
    'pending',
    'paid',
    'overdue'
);


--
-- Name: loans_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.loans_status_enum AS ENUM (
    'pending',
    'approved',
    'active',
    'completed',
    'defaulted',
    'rejected'
);


--
-- Name: notification_templates_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.notification_templates_type_enum AS ENUM (
    'sms',
    'email'
);


--
-- Name: organizations_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.organizations_status_enum AS ENUM (
    'active',
    'inactive'
);


--
-- Name: payments_payout_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payments_payout_status_enum AS ENUM (
    'pending',
    'completed',
    'failed'
);


--
-- Name: payments_provider_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payments_provider_enum AS ENUM (
    'paystack',
    'firstbank',
    'wema',
    'korapay'
);


--
-- Name: payments_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payments_status_enum AS ENUM (
    'pending',
    'success',
    'failed',
    'successful'
);


--
-- Name: policy_templates_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.policy_templates_status_enum AS ENUM (
    'draft',
    'pending_approval',
    'active',
    'superseded',
    'rejected'
);


--
-- Name: policy_templates_template_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.policy_templates_template_type_enum AS ENUM (
    'bnpl_product',
    'kyc_requirement',
    'manager_action',
    'interest_rate',
    'collection'
);


--
-- Name: reconciliation_results_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.reconciliation_results_status_enum AS ENUM (
    'matched',
    'unmatched',
    'needs_review'
);


--
-- Name: reconciliation_runs_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.reconciliation_runs_status_enum AS ENUM (
    'in_progress',
    'completed',
    'failed'
);


--
-- Name: redemption_requests_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.redemption_requests_status_enum AS ENUM (
    'requested',
    'approved',
    'processed',
    'paid',
    'rejected'
);


--
-- Name: referrals_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.referrals_status_enum AS ENUM (
    'pending',
    'completed',
    'expired'
);


--
-- Name: saved_payment_methods_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.saved_payment_methods_type_enum AS ENUM (
    'card',
    'bank'
);


--
-- Name: savings_transactions_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.savings_transactions_type_enum AS ENUM (
    'deposit',
    'withdrawal',
    'interest',
    'goal_deposit',
    'goal_withdrawal',
    'loan_service_fee'
);


--
-- Name: secrets_category_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.secrets_category_enum AS ENUM (
    'api_key',
    'webhook_secret',
    'encryption_key',
    'database',
    'smtp',
    'payment_gateway',
    'other'
);


--
-- Name: share_issuance_cycles_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.share_issuance_cycles_status_enum AS ENUM (
    'pending',
    'approved',
    'active',
    'closed'
);


--
-- Name: sms_logs_provider_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sms_logs_provider_enum AS ENUM (
    'termii'
);


--
-- Name: sms_logs_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sms_logs_status_enum AS ENUM (
    'sent',
    'failed'
);


--
-- Name: support_tickets_category_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.support_tickets_category_enum AS ENUM (
    'order_inquiry',
    'repayment_issue',
    'technical_glitch',
    'reconciliation',
    'other',
    'investment_issue'
);


--
-- Name: support_tickets_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.support_tickets_status_enum AS ENUM (
    'open',
    'in_progress',
    'resolved',
    'closed'
);


--
-- Name: tenant_onboarding_requests_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tenant_onboarding_requests_status_enum AS ENUM (
    'draft',
    'submitted',
    'compliance_review',
    'approved',
    'rejected',
    'onboarded'
);


--
-- Name: users_kyc_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.users_kyc_status_enum AS ENUM (
    'none',
    'pending',
    'approved',
    'rejected'
);


--
-- Name: users_role_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.users_role_enum AS ENUM (
    'super_admin',
    'operational_admin',
    'accountant',
    'business_manager',
    'apex_business_manager',
    'supervisor',
    'loan_manager',
    'bnpl_manager',
    'investment_manager',
    'individual',
    'operations'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(255) NOT NULL,
    type public.accounts_type_enum NOT NULL,
    organization_id uuid,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: adjustment_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.adjustment_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    adjustment_type public.adjustment_requests_adjustment_type_enum NOT NULL,
    description character varying(255) NOT NULL,
    reason_code character varying(50) NOT NULL,
    changes jsonb NOT NULL,
    reference_type character varying(100),
    reference_id uuid,
    status public.adjustment_requests_status_enum DEFAULT 'pending'::public.adjustment_requests_status_enum NOT NULL,
    rejection_reason text,
    requested_by uuid NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: apex_organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.apex_organizations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(100) NOT NULL,
    status public.apex_organizations_status_enum DEFAULT 'active'::public.apex_organizations_status_enum NOT NULL,
    created_by uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    bank_name character varying(255),
    account_name character varying(255),
    account_number character varying(20),
    sort_code character varying(20),
    bank_code character varying(20),
    address character varying(255),
    contact_email character varying(255),
    contact_phone character varying(20),
    contact_person_name character varying(255),
    contact_person_phone character varying(20),
    contact_person_email character varying(255)
);


--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_settings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    action public.audit_logs_action_enum NOT NULL,
    "entityType" character varying(100),
    "entityId" uuid,
    performed_by uuid,
    metadata jsonb,
    "ipAddress" character varying(45),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_approval_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_approval_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    request_type public.bnpl_approval_requests_request_type_enum NOT NULL,
    status public.bnpl_approval_requests_status_enum DEFAULT 'pending'::public.bnpl_approval_requests_status_enum NOT NULL,
    request_data jsonb NOT NULL,
    reason text,
    rejection_reason text,
    requested_by uuid NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    entity_type character varying(100) NOT NULL,
    entity_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    changes jsonb,
    reason text,
    performed_by uuid NOT NULL,
    performer_name character varying(255),
    "ipAddress" character varying(45),
    evidence text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_catalog_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_catalog_images (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    catalog_item_id uuid NOT NULL,
    url character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_catalog_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_catalog_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    price numeric(15,2) NOT NULL,
    image_url character varying,
    created_by uuid NOT NULL,
    is_global boolean DEFAULT true NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_catalog_org_eligibility; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_catalog_org_eligibility (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    catalog_item_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_collection_playbooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_collection_playbooks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    trigger_event public.bnpl_collection_playbooks_trigger_event_enum NOT NULL,
    recommended_actions jsonb NOT NULL,
    requires_approval boolean DEFAULT false NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_collection_priorities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_collection_priorities (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    entity_type public.bnpl_collection_priorities_entity_type_enum NOT NULL,
    entity_id uuid NOT NULL,
    priority public.bnpl_collection_priorities_priority_enum NOT NULL,
    reason text,
    assigned_by uuid NOT NULL,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_collection_queues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_collection_queues (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    subscription_id uuid NOT NULL,
    user_id uuid NOT NULL,
    status public.bnpl_collection_queues_status_enum DEFAULT 'pending'::public.bnpl_collection_queues_status_enum NOT NULL,
    priority public.bnpl_collection_queues_priority_enum DEFAULT 'medium'::public.bnpl_collection_queues_priority_enum NOT NULL,
    days_overdue integer DEFAULT 0 NOT NULL,
    total_overdue_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    outstanding_principal numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    last_contacted_at timestamp without time zone,
    agent_note text,
    assigned_to uuid,
    assigned_by uuid NOT NULL,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_exception_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_exception_cases (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    subscription_id uuid NOT NULL,
    reason_id uuid NOT NULL,
    description text,
    status public.bnpl_exception_cases_status_enum DEFAULT 'open'::public.bnpl_exception_cases_status_enum NOT NULL,
    created_by uuid NOT NULL,
    assigned_to uuid,
    resolution text,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_exception_reasons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_exception_reasons (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    category public.bnpl_exception_reasons_category_enum DEFAULT 'other'::public.bnpl_exception_reasons_category_enum NOT NULL,
    escalation_threshold_days integer,
    escalation_threshold_count integer,
    escalation_action public.bnpl_exception_reasons_escalation_action_enum DEFAULT 'manual_review'::public.bnpl_exception_reasons_escalation_action_enum NOT NULL
);


--
-- Name: bnpl_idempotency_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_idempotency_keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    idempotency_key character varying(255) NOT NULL,
    operation character varying(100) NOT NULL,
    reference_id uuid,
    status character varying(50) DEFAULT 'completed'::character varying NOT NULL,
    result jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_installments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_installments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    subscription_id uuid NOT NULL,
    due_date date NOT NULL,
    amount numeric(15,2) NOT NULL,
    status public.bnpl_installments_status_enum DEFAULT 'pending'::public.bnpl_installments_status_enum NOT NULL,
    paid_at timestamp without time zone,
    payment_reference character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    late_fee_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    grace_period_end date
);


--
-- Name: bnpl_plan_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_plan_configs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    available_tenors jsonb NOT NULL,
    interest_model public.bnpl_plan_configs_interest_model_enum DEFAULT 'simple'::public.bnpl_plan_configs_interest_model_enum NOT NULL,
    max_principal numeric(15,2),
    require_membership boolean DEFAULT false NOT NULL,
    due_date_rule public.bnpl_plan_configs_due_date_rule_enum DEFAULT 'same_day_monthly'::public.bnpl_plan_configs_due_date_rule_enum NOT NULL,
    grace_period_days integer DEFAULT 0 NOT NULL,
    late_fee_type public.bnpl_plan_configs_late_fee_type_enum DEFAULT 'percentage'::public.bnpl_plan_configs_late_fee_type_enum NOT NULL,
    late_fee_value numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    created_by uuid NOT NULL,
    updated_by uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_plans (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    catalog_item_id uuid NOT NULL,
    down_payment_percent numeric(5,2) NOT NULL,
    installment_count integer NOT NULL,
    installment_frequency character varying(20) NOT NULL,
    "interestRate" numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    tenor_options jsonb,
    min_principal numeric(12,2),
    max_principal numeric(12,2),
    eligibility_bands jsonb,
    interest_type public.bnpl_plans_interest_type_enum DEFAULT 'flat'::public.bnpl_plans_interest_type_enum NOT NULL,
    monthly_fee_rate numeric(5,2),
    grace_period_days integer DEFAULT 0 NOT NULL,
    late_fee_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    late_fee_cap_days integer,
    is_enabled boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    status public.bnpl_plans_status_enum DEFAULT 'active'::public.bnpl_plans_status_enum NOT NULL
);


--
-- Name: bnpl_processing_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_processing_steps (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    subscription_id uuid NOT NULL,
    step_type public.bnpl_processing_steps_step_type_enum NOT NULL,
    status public.bnpl_processing_steps_status_enum DEFAULT 'pending'::public.bnpl_processing_steps_status_enum NOT NULL,
    idempotency_key character varying(255),
    metadata jsonb,
    error_message text,
    retry_count integer DEFAULT 0 NOT NULL,
    external_reference character varying(255),
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_risk_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_risk_flags (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    entity_type public.bnpl_risk_flags_entity_type_enum NOT NULL,
    entity_id uuid NOT NULL,
    reason character varying(255) NOT NULL,
    description text,
    flagged_by character varying(255) NOT NULL,
    status public.bnpl_risk_flags_status_enum DEFAULT 'open'::public.bnpl_risk_flags_status_enum NOT NULL,
    resolved_by uuid,
    resolution_note text,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bnpl_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bnpl_subscriptions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    status public.bnpl_subscriptions_status_enum DEFAULT 'created'::public.bnpl_subscriptions_status_enum NOT NULL,
    down_payment numeric(15,2) NOT NULL,
    total_amount numeric(15,2) NOT NULL,
    amount_paid numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    next_installment_date date,
    provider_reference character varying,
    payout_status public.bnpl_subscriptions_payout_status_enum DEFAULT 'pending'::public.bnpl_subscriptions_payout_status_enum NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    disbursement_reference character varying,
    disbursed_at timestamp without time zone,
    settled_at timestamp without time zone,
    approved_at timestamp without time zone
);


--
-- Name: device_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    device_fingerprint character varying(255) NOT NULL,
    device_name character varying(255),
    device_type character varying(50),
    os character varying(100),
    browser character varying(100),
    ip_address character varying(45),
    is_trusted boolean DEFAULT false NOT NULL,
    last_used_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: disputes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.disputes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    type public.disputes_type_enum NOT NULL,
    reference_id uuid NOT NULL,
    user_id uuid NOT NULL,
    reason character varying(500) NOT NULL,
    status public.disputes_status_enum DEFAULT 'opened'::public.disputes_status_enum NOT NULL,
    resolution text,
    resolved_by uuid,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: distribution_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distribution_payments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    holding_id uuid NOT NULL,
    distribution_id uuid NOT NULL,
    amount numeric(15,2) NOT NULL,
    units_at_record integer NOT NULL,
    is_paid boolean DEFAULT false NOT NULL,
    paid_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: distribution_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distribution_runs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    distribution_id uuid NOT NULL,
    product_id uuid NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    total_accrued numeric(15,2) NOT NULL,
    total_holdings integer NOT NULL,
    payout_count integer DEFAULT 0 NOT NULL,
    success_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    status public.distribution_runs_status_enum DEFAULT 'computing'::public.distribution_runs_status_enum NOT NULL,
    run_summary jsonb,
    approved_by uuid,
    approved_at timestamp without time zone,
    executed_by uuid,
    executed_at timestamp without time zone,
    created_by uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: distributions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.distributions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid NOT NULL,
    type public.distributions_type_enum NOT NULL,
    amount_per_unit numeric(15,2) NOT NULL,
    total_pool numeric(15,2) NOT NULL,
    record_date date NOT NULL,
    pay_date date NOT NULL,
    description character varying(255),
    is_paid boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    status public.distributions_status_enum DEFAULT 'draft'::public.distributions_status_enum NOT NULL,
    approved_by uuid,
    approved_at timestamp without time zone,
    created_by uuid
);


--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flags (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status public.feature_flags_status_enum DEFAULT 'disabled'::public.feature_flags_status_enum NOT NULL,
    environments jsonb DEFAULT '{}'::jsonb NOT NULL,
    cohort_rules jsonb,
    rollout_percentage integer DEFAULT 0 NOT NULL,
    created_by uuid NOT NULL,
    updated_by uuid,
    enabled_at timestamp without time zone,
    is_kill_switch boolean DEFAULT false NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: fee_pots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fee_pots (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    balance numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    pot_type public.fee_pots_pot_type_enum NOT NULL,
    entity_id character varying(100) NOT NULL
);


--
-- Name: fee_share_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fee_share_ledger (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    payment_id uuid NOT NULL,
    source public.fee_share_ledger_source_enum NOT NULL,
    total_fee numeric(15,2) NOT NULL,
    super_admin_share numeric(15,2) NOT NULL,
    super_admin_user_id uuid NOT NULL,
    platform_share numeric(15,2) NOT NULL,
    organization_share numeric(15,2) NOT NULL,
    organization_id uuid,
    apex_share numeric(15,2) NOT NULL,
    apex_org_id uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: fee_withdrawal_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fee_withdrawal_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    pot_type character varying(50) NOT NULL,
    amount numeric(15,2) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    requested_by uuid NOT NULL,
    approved_by uuid,
    account_number character varying(20),
    bank_code character varying(20),
    bank_name character varying(100),
    note text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: global_risk_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.global_risk_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "ruleKey" character varying(100) NOT NULL,
    description character varying(255) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    config jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: global_security_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.global_security_config (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL,
    description character varying(255),
    value_type character varying(50) DEFAULT 'string'::character varying NOT NULL,
    updated_by uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: in_app_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.in_app_notifications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id character varying NOT NULL,
    title character varying(255) NOT NULL,
    message text,
    type public.in_app_notifications_type_enum DEFAULT 'info'::public.in_app_notifications_type_enum NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    link character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incidents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    severity public.incidents_severity_enum NOT NULL,
    status public.incidents_status_enum DEFAULT 'detected'::public.incidents_status_enum NOT NULL,
    source public.incidents_source_enum NOT NULL,
    tenant_id uuid,
    affected_systems jsonb,
    metrics jsonb,
    resolution_steps jsonb,
    assigned_to uuid,
    reported_by uuid NOT NULL,
    resolved_by uuid,
    detected_at timestamp without time zone DEFAULT now() NOT NULL,
    resolved_at timestamp without time zone,
    root_cause text,
    action_items text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: investment_corporate_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investment_corporate_actions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid NOT NULL,
    type public.investment_corporate_actions_type_enum NOT NULL,
    description character varying(500),
    ratio_numerator numeric(10,4) DEFAULT '1'::numeric NOT NULL,
    ratio_denominator numeric(10,4) DEFAULT '1'::numeric NOT NULL,
    effective_date date NOT NULL,
    status public.investment_corporate_actions_status_enum DEFAULT 'pending'::public.investment_corporate_actions_status_enum NOT NULL,
    execution_result jsonb,
    approved_by uuid,
    approved_at timestamp without time zone,
    executed_by uuid,
    executed_at timestamp without time zone,
    created_by uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: investment_eligibility_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investment_eligibility_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid NOT NULL,
    kyc_required_level public.investment_eligibility_rules_kyc_required_level_enum DEFAULT 'basic'::public.investment_eligibility_rules_kyc_required_level_enum NOT NULL,
    require_membership boolean DEFAULT false NOT NULL,
    allowed_geographies jsonb,
    accreditation_required boolean DEFAULT false NOT NULL,
    investor_whitelist jsonb,
    investor_blacklist jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: investment_holdings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investment_holdings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    order_id uuid NOT NULL,
    units integer NOT NULL,
    cost_basis numeric(15,2) NOT NULL,
    current_value numeric(15,2),
    locked_until date,
    maturity_date date,
    is_locked boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: investment_nav_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investment_nav_snapshots (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid NOT NULL,
    nav numeric(15,2) NOT NULL,
    unit_price numeric(15,2) NOT NULL,
    snapshot_date date NOT NULL,
    created_by uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: investment_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investment_orders (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    amount numeric(15,2) NOT NULL,
    units integer,
    unit_price numeric(15,2),
    fee numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    product_version integer,
    status public.investment_orders_status_enum DEFAULT 'placed'::public.investment_orders_status_enum NOT NULL,
    payment_reference character varying,
    payment_id uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: investment_pricing_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investment_pricing_config (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid NOT NULL,
    formula_type public.investment_pricing_config_formula_type_enum DEFAULT 'simple'::public.investment_pricing_config_formula_type_enum NOT NULL,
    min_unit_price numeric(15,2),
    max_unit_price numeric(15,2),
    nav_schedule public.investment_pricing_config_nav_schedule_enum,
    allow_corporate_actions boolean DEFAULT false NOT NULL,
    distribution_approval_required boolean DEFAULT true NOT NULL,
    accrual_method public.investment_pricing_config_accrual_method_enum DEFAULT 'simple'::public.investment_pricing_config_accrual_method_enum NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: investment_product_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investment_product_versions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid NOT NULL,
    version integer NOT NULL,
    snapshot jsonb NOT NULL,
    change_summary character varying,
    changed_by uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: investment_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investment_products (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    type public.investment_products_type_enum NOT NULL,
    "riskTier" public.investment_products_risktier_enum DEFAULT 'medium'::public.investment_products_risktier_enum NOT NULL,
    minimum_investment numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    maximum_investment numeric(15,2),
    total_capacity numeric(15,2),
    current_capacity numeric(15,2),
    per_investor_caps jsonb,
    unit_price numeric(15,2),
    lock_in_days integer DEFAULT 0 NOT NULL,
    tenor_days integer,
    management_fee_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    expected_return_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    profit_sharing_rules text,
    "distributionFrequency" public.investment_products_distributionfrequency_enum DEFAULT 'maturity'::public.investment_products_distributionfrequency_enum NOT NULL,
    total_units integer,
    available_units integer,
    is_open boolean DEFAULT true NOT NULL,
    status public.investment_products_status_enum DEFAULT 'active'::public.investment_products_status_enum NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    organization_id uuid,
    created_by uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    description text,
    entry_date date NOT NULL,
    status public.journal_entries_status_enum DEFAULT 'draft'::public.journal_entries_status_enum NOT NULL,
    posted_by uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    posted_at timestamp without time zone
);


--
-- Name: journal_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_lines (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    journal_entry_id uuid NOT NULL,
    account_id uuid NOT NULL,
    debit numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    credit numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    organization_id uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: kyc_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kyc_submissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    provider public.kyc_submissions_provider_enum DEFAULT 'korapay'::public.kyc_submissions_provider_enum NOT NULL,
    reference character varying(255) NOT NULL,
    status public.kyc_submissions_status_enum DEFAULT 'pending'::public.kyc_submissions_status_enum NOT NULL,
    provider_response jsonb,
    submitted_at timestamp without time zone DEFAULT now() NOT NULL,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    rejection_reason text,
    "identityType" character varying(50) DEFAULT 'bvn'::character varying NOT NULL
);


--
-- Name: loan_repayments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loan_repayments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    loan_id uuid NOT NULL,
    due_date date NOT NULL,
    amount numeric(15,2) NOT NULL,
    paid_at timestamp without time zone,
    payment_reference character varying,
    status public.loan_repayments_status_enum DEFAULT 'pending'::public.loan_repayments_status_enum NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: loans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loans (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    amount numeric(15,2) NOT NULL,
    interest_rate numeric(5,2) DEFAULT '5'::numeric NOT NULL,
    duration integer NOT NULL,
    monthly_payment numeric(15,2) NOT NULL,
    total_repayment numeric(15,2) NOT NULL,
    amount_paid numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    purpose character varying(500),
    status public.loans_status_enum DEFAULT 'pending'::public.loans_status_enum NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    service_fee numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    service_fee_paid boolean DEFAULT false NOT NULL,
    service_fee_paid_at timestamp without time zone,
    service_fee_tx_id uuid
);


--
-- Name: login_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id character varying NOT NULL,
    ip_address character varying(45),
    user_agent text,
    device character varying(100),
    location character varying(100),
    success boolean DEFAULT true NOT NULL,
    reason character varying(255),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key character varying(100) NOT NULL,
    type public.notification_templates_type_enum NOT NULL,
    subject character varying(255),
    body text NOT NULL,
    variables jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(100) NOT NULL,
    apex_org_id uuid NOT NULL,
    status public.organizations_status_enum DEFAULT 'active'::public.organizations_status_enum NOT NULL,
    created_by uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    address character varying(255),
    contact_email character varying(255),
    contact_phone character varying(20),
    contact_person_name character varying(255),
    contact_person_phone character varying(20),
    contact_person_email character varying(255),
    bank_name character varying(255),
    account_name character varying(255),
    account_number character varying(20),
    sort_code character varying(20),
    bank_code character varying(20)
);


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    subscription_id uuid,
    amount numeric(15,2) NOT NULL,
    fee numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    provider public.payments_provider_enum NOT NULL,
    provider_reference character varying(255) NOT NULL,
    status public.payments_status_enum DEFAULT 'pending'::public.payments_status_enum NOT NULL,
    metadata jsonb,
    payout_status public.payments_payout_status_enum DEFAULT 'pending'::public.payments_payout_status_enum NOT NULL,
    payout_reference character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: policy_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy_templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    template_type public.policy_templates_template_type_enum NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    status public.policy_templates_status_enum DEFAULT 'draft'::public.policy_templates_status_enum NOT NULL,
    rules jsonb NOT NULL,
    metadata jsonb,
    created_by uuid NOT NULL,
    approved_by uuid,
    approved_at timestamp without time zone,
    change_summary text,
    superseded_by uuid,
    parent_template_id uuid,
    is_applicable_to_all_tenants boolean DEFAULT true NOT NULL,
    applicable_tenant_ids text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: reconciliation_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reconciliation_results (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    run_id uuid NOT NULL,
    subscription_id uuid NOT NULL,
    installment_id uuid,
    expected_amount numeric(15,2) NOT NULL,
    actual_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    discrepancy numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    expected_date date,
    actual_date date,
    status public.reconciliation_results_status_enum DEFAULT 'unmatched'::public.reconciliation_results_status_enum NOT NULL,
    notes text,
    flags text,
    organization_id uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: reconciliation_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reconciliation_runs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    range_start date NOT NULL,
    range_end date NOT NULL,
    status public.reconciliation_runs_status_enum DEFAULT 'in_progress'::public.reconciliation_runs_status_enum NOT NULL,
    total_expected integer DEFAULT 0 NOT NULL,
    total_actual integer DEFAULT 0 NOT NULL,
    match_count integer DEFAULT 0 NOT NULL,
    mismatch_count integer DEFAULT 0 NOT NULL,
    expected_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    actual_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    discrepancy numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    organization_id uuid,
    run_by uuid NOT NULL,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: redemption_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.redemption_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    holding_id uuid NOT NULL,
    units integer NOT NULL,
    amount numeric(15,2) NOT NULL,
    status public.redemption_requests_status_enum DEFAULT 'requested'::public.redemption_requests_status_enum NOT NULL,
    reason text,
    rejection_reason text,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: referrals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.referrals (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    referrer_id character varying NOT NULL,
    referee_id character varying,
    referee_email character varying(255) NOT NULL,
    referral_code character varying(20) NOT NULL,
    status public.referrals_status_enum DEFAULT 'pending'::public.referrals_status_enum NOT NULL,
    reward_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    reward_paid boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: saved_payment_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_payment_methods (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id character varying NOT NULL,
    type public.saved_payment_methods_type_enum NOT NULL,
    provider character varying(50) NOT NULL,
    provider_token character varying(255),
    last4 character varying(4),
    card_brand character varying(50),
    expiry_month character varying(2),
    expiry_year character varying(4),
    bank_name character varying(255),
    account_number character varying(20),
    account_name character varying(255),
    is_default boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: savings_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.savings_accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    balance numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    target_amount numeric(15,2),
    status character varying DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    goal_balance numeric(15,2) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: savings_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.savings_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    account_id uuid NOT NULL,
    type public.savings_transactions_type_enum NOT NULL,
    amount numeric(15,2) NOT NULL,
    balance_before numeric(15,2) NOT NULL,
    balance_after numeric(15,2) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: secrets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.secrets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key character varying(255) NOT NULL,
    encrypted_value text NOT NULL,
    category public.secrets_category_enum DEFAULT 'other'::public.secrets_category_enum NOT NULL,
    description text,
    tenant_id uuid,
    is_rotation_enabled boolean DEFAULT false NOT NULL,
    last_rotated_at timestamp without time zone,
    rotation_interval_days integer,
    created_by uuid NOT NULL,
    updated_by uuid,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: share_issuance_cycles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.share_issuance_cycles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid NOT NULL,
    cycle_name character varying(255) NOT NULL,
    total_units integer NOT NULL,
    allocated_units integer DEFAULT 0 NOT NULL,
    unit_price numeric(15,2) NOT NULL,
    total_value numeric(15,2) NOT NULL,
    open_date date,
    close_date date,
    status public.share_issuance_cycles_status_enum DEFAULT 'pending'::public.share_issuance_cycles_status_enum NOT NULL,
    approved_by uuid,
    approved_at timestamp without time zone,
    created_by uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: sms_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    recipient character varying(20) NOT NULL,
    message text NOT NULL,
    event_type character varying(50) NOT NULL,
    provider public.sms_logs_provider_enum DEFAULT 'termii'::public.sms_logs_provider_enum NOT NULL,
    status public.sms_logs_status_enum DEFAULT 'sent'::public.sms_logs_status_enum NOT NULL,
    provider_response jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_tickets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    subject character varying(255) NOT NULL,
    description text,
    status public.support_tickets_status_enum DEFAULT 'open'::public.support_tickets_status_enum NOT NULL,
    category public.support_tickets_category_enum DEFAULT 'other'::public.support_tickets_category_enum NOT NULL,
    related_order_id uuid,
    related_payment_id uuid,
    created_by uuid NOT NULL,
    assigned_to uuid,
    resolution_note text,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: tenant_onboarding_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_onboarding_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    org_name character varying(255) NOT NULL,
    org_code character varying(100) NOT NULL,
    apex_org_id uuid NOT NULL,
    status public.tenant_onboarding_requests_status_enum DEFAULT 'draft'::public.tenant_onboarding_requests_status_enum NOT NULL,
    compliance_docs jsonb,
    kyc_requirements jsonb,
    product_config jsonb,
    contact_info jsonb,
    rejection_reason text,
    review_notes text,
    submitted_by uuid NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp without time zone,
    onboarded_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ticket_messages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ticket_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    sender_role character varying(20) NOT NULL,
    message text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_activities (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id character varying NOT NULL,
    action character varying(100) NOT NULL,
    details jsonb,
    ip_address character varying(45),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role public.users_role_enum NOT NULL,
    apex_org_id uuid,
    organization_id uuid,
    kyc_status public.users_kyc_status_enum DEFAULT 'none'::public.users_kyc_status_enum NOT NULL,
    kyc_reference character varying,
    is_active boolean DEFAULT true NOT NULL,
    refresh_token_hash character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    registration_fee_paid boolean DEFAULT false NOT NULL,
    reset_token character varying,
    reset_token_expiry timestamp without time zone,
    social_provider character varying,
    social_id character varying,
    notification_preferences jsonb,
    referral_code character varying(20),
    referred_by character varying,
    referral_count integer DEFAULT 0 NOT NULL,
    referral_earnings numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    failed_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp without time zone,
    email_hash character varying(64),
    phone_hash character varying(64),
    phone character varying(255),
    deleted_at timestamp without time zone,
    kyc_verified_at timestamp without time zone,
    kyc_image text,
    first_name character varying(255),
    last_name character varying(255),
    must_change_password boolean DEFAULT false NOT NULL
);


--
-- Name: webhook_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    provider character varying(100) NOT NULL,
    event_type character varying(100) NOT NULL,
    event_id character varying(255) NOT NULL,
    payment_id text,
    status character varying(50) NOT NULL,
    payload jsonb,
    error_message text,
    retry_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (id, code, name, type, organization_id, is_system, created_at, updated_at, description, is_active) FROM stdin;
5295f298-5f27-494e-8b98-4a9482fe8b5d	1000	Cash	asset	\N	t	2026-07-22 19:32:13.307011	2026-07-22 19:32:13.307011	\N	t
993c8285-4f60-4443-ad56-9be8bf143956	1100	Bank Account	asset	\N	t	2026-07-22 19:32:13.316004	2026-07-22 19:32:13.316004	\N	t
6ca8bbb9-5cfb-439a-8c69-e644c10c1997	1200	Accounts Receivable	asset	\N	t	2026-07-22 19:32:13.327487	2026-07-22 19:32:13.327487	\N	t
6aecc93c-8f57-428c-8e8a-afcda7c6c9bf	2000	Accounts Payable	liability	\N	t	2026-07-22 19:32:13.337656	2026-07-22 19:32:13.337656	\N	t
7a176c94-1003-4d61-a11a-e40d72882ad8	2100	BNPL Revenue Liability	liability	\N	t	2026-07-22 19:32:13.345478	2026-07-22 19:32:13.345478	\N	t
1f5e9094-dc9f-42cb-bfd0-394ff876d879	3000	Retained Earnings	equity	\N	t	2026-07-22 19:32:13.351836	2026-07-22 19:32:13.351836	\N	t
8f7e3e29-fa3e-4760-acbd-716cbca21540	4000	BNPL Fee Revenue	revenue	\N	t	2026-07-22 19:32:13.35799	2026-07-22 19:32:13.35799	\N	t
d85e2b87-e757-4650-b402-f4dae7206f2b	4100	Platform Fee Revenue	revenue	\N	t	2026-07-22 19:32:13.370212	2026-07-22 19:32:13.370212	\N	t
2086b3d8-fa8b-4a89-bbee-cad72f244d0c	5000	Operating Expenses	expense	\N	t	2026-07-22 19:32:13.378721	2026-07-22 19:32:13.378721	\N	t
e80aa85a-ebf6-43f1-ab8c-6c3af33d8525	5100	Payout Expenses	expense	\N	t	2026-07-22 19:32:13.385842	2026-07-22 19:32:13.385842	\N	t
bdced685-b18e-4c23-b4a3-5b9ce2ea8b4d	5200	Processing Fees	expense	\N	t	2026-07-22 19:32:13.388319	2026-07-22 19:32:13.388319	\N	t
eafb37b3-c508-4931-8f02-3fbaa68968f3	4200	Registration Fee Revenue	revenue	\N	t	2026-07-22 21:11:50.332944	2026-07-22 21:11:50.332944	\N	t
ca16d2c9-a58f-41c3-bb4a-d0e2dfb1ad4c	1010	Bank Account - Main Operations	asset	\N	f	2026-07-31 12:53:19.153901	2026-07-31 12:53:19.153901	Primary operating bank account for day-to-day settlements.	t
15321ab9-18c7-4a22-bc3b-92b06aff90f8	1020	Bank Account - Paystack Settlement	asset	\N	f	2026-07-31 12:53:19.17132	2026-07-31 12:53:19.17132	Holds funds settled by Paystack before distribution to fee pots.	t
477bcce5-2a57-4949-8192-116ef049f624	1030	Bank Account - Investment Sweep	asset	\N	f	2026-07-31 12:53:19.178018	2026-07-31 12:53:19.178018	Bank account backing pooled and fixed-income investment products.	t
b8709696-4756-4ec8-a03e-2043f728585c	1110	BNPL Loans Receivable	asset	\N	f	2026-07-31 12:53:19.182498	2026-07-31 12:53:19.182498	Principal outstanding on BNPL and micro-loan facilities.	t
1711d160-f06c-4cac-b549-38e1a61f8452	1120	Accrued Interest Receivable	asset	\N	f	2026-07-31 12:53:19.18525	2026-07-31 12:53:19.18525	Interest income earned but not yet received or invoiced.	t
c89cf304-3305-46b8-95d1-978ecfa0709f	1130	Fee Receivable from Tenants	asset	\N	f	2026-07-31 12:53:19.187957	2026-07-31 12:53:19.187957	Fee share owed by tenant organizations to the platform.	t
1f1eb33a-2257-4e93-9476-3c3aba0f00d2	1300	Investment Securities	asset	\N	f	2026-07-31 12:53:19.195832	2026-07-31 12:53:19.195832	Marketable securities and pooled investment holdings.	t
01196470-23a6-4f0f-b645-ceac4ff15b1f	1400	Allowance for Credit Losses	asset	\N	f	2026-07-31 12:53:19.198625	2026-07-31 12:53:19.198625	Contra-asset reserving expected credit losses on receivables.	t
6ff4f831-c7e1-44b6-b990-83b5d8328ca6	1500	Intercompany Receivable	asset	\N	f	2026-07-31 12:53:19.201391	2026-07-31 12:53:19.201391	Funds owed between group entities.	t
6ae3e537-1b17-4376-8914-14547aa51c4b	2110	Member Deposits & Savings	liability	\N	f	2026-07-31 12:53:19.207976	2026-07-31 12:53:19.207976	Customer savings and deposits held by the platform.	t
0a4bb2bc-bb8e-4e82-89db-6f75bbebe111	2120	Unearned Revenue	liability	\N	f	2026-07-31 12:53:19.21231	2026-07-31 12:53:19.21231	Revenue received in advance and not yet earned.	t
d274a767-ef1c-4fcc-8ee5-689ccdc034d6	2130	Fee Pots Payable	liability	\N	f	2026-07-31 12:53:19.214966	2026-07-31 12:53:19.214966	Accumulated fee shares owed to fee pots and their stakeholders.	t
9f455e85-bd9b-4be7-a9a3-5449a9f0a07c	2200	Accrued Expenses	liability	\N	f	2026-07-31 12:53:19.217171	2026-07-31 12:53:19.217171	Expenses incurred but not yet paid.	t
2401a339-bae7-43b4-89b2-f76321c33212	2210	Interest Payable	liability	\N	f	2026-07-31 12:53:19.219223	2026-07-31 12:53:19.219223	Interest owed to members and lenders.	t
f9f6bbbe-3324-40d9-a359-4b6aa78fc0e2	2220	Withholding Tax Payable	liability	\N	f	2026-07-31 12:53:19.221298	2026-07-31 12:53:19.221298	WHT collected and due to the tax authority.	t
88c93bf3-6da0-44ce-98e5-780e728e9147	2300	Intercompany Payable	liability	\N	f	2026-07-31 12:53:19.22746	2026-07-31 12:53:19.22746	Funds owed between group entities.	t
98855492-8bff-4d76-923f-95c5f2b7d39c	3010	Share Capital	equity	\N	f	2026-07-31 12:53:19.230989	2026-07-31 12:53:19.230989	Paid-in capital contributed by shareholders.	t
c8221536-becd-43c8-88ed-3d8c6436320a	3020	Current Year Earnings	equity	\N	f	2026-07-31 12:53:19.233482	2026-07-31 12:53:19.233482	Net profit attributable to the current accounting period.	t
bfca88e4-1c30-4914-b30a-564a3d565817	3030	Appropriated Reserves	equity	\N	f	2026-07-31 12:53:19.235668	2026-07-31 12:53:19.235668	Earnings set aside for defined purposes.	t
a096076b-6116-4c5d-8bad-a61ee829d606	4300	Interest Income - BNPL	revenue	\N	f	2026-07-31 12:53:19.243395	2026-07-31 12:53:19.243395	Interest earned on BNPL and loan principal.	t
3cd7e904-adbd-4ac3-8ef4-6512702dfee8	4310	Late Fee Income	revenue	\N	f	2026-07-31 12:53:19.246177	2026-07-31 12:53:19.246177	Penalty and late-payment fees collected.	t
c6fadcef-4199-4690-b18e-b6bca25f9304	4320	Investment Income	revenue	\N	f	2026-07-31 12:53:19.248555	2026-07-31 12:53:19.248555	Returns from pooled and fixed-income investments.	t
7e28dd87-30b6-4477-a367-6480d8ac9ae2	4330	Merchant Commission Revenue	revenue	\N	f	2026-07-31 12:53:19.250721	2026-07-31 12:53:19.250721	Commission earned from merchant sales.	t
de167f65-c10d-43ab-b719-c0c80b8f07bb	4340	Withdrawal & Payout Fee Revenue	revenue	\N	f	2026-07-31 12:53:19.252627	2026-07-31 12:53:19.252627	Fees charged on withdrawals and payouts.	t
2b662494-3af9-4aac-b44e-473686e358d1	5210	Payment Gateway Fees	expense	\N	f	2026-07-31 12:53:19.259462	2026-07-31 12:53:19.259462	Card, transfer and gateway transaction fees.	t
46eab849-0e8b-4e66-a023-ea95a1ad9f7e	5220	Bank Charges	expense	\N	f	2026-07-31 12:53:19.262577	2026-07-31 12:53:19.262577	Account maintenance and bank service charges.	t
a5f45e96-894d-47d8-b91f-192a4aa1b870	5300	Salaries & Wages	expense	\N	f	2026-07-31 12:53:19.265377	2026-07-31 12:53:19.265377	Staff compensation and benefits.	t
d43f50f0-3f17-431a-bd45-a4ebcad587ab	5310	Marketing & Advertising	expense	\N	f	2026-07-31 12:53:19.267554	2026-07-31 12:53:19.267554	Customer acquisition and brand marketing spend.	t
8c894d58-b937-44de-a430-61a87ff83741	5320	Rent & Utilities	expense	\N	f	2026-07-31 12:53:19.269598	2026-07-31 12:53:19.269598	Office rent and utility bills.	t
5faaf2f1-e4a9-45b4-95e4-42ec2bc046c3	5330	Software & Subscriptions	expense	\N	f	2026-07-31 12:53:19.271312	2026-07-31 12:53:19.271312	SaaS and infrastructure subscriptions.	t
73580371-bb9a-4e8b-8604-7bf96e28e5f1	5400	Depreciation & Amortisation	expense	\N	f	2026-07-31 12:53:19.27755	2026-07-31 12:53:19.27755	Systematic allocation of fixed asset and intangible costs.	t
15c6507d-c461-4e6a-985d-65abc8f6f12d	5410	Allowance for Bad Debts	expense	\N	f	2026-07-31 12:53:19.280371	2026-07-31 12:53:19.280371	Charges recognising expected uncollectible receivables.	t
7e94e2bd-6cac-4246-9c69-bd3d6f6b7573	5500	Tax Expense	expense	\N	f	2026-07-31 12:53:19.282848	2026-07-31 12:53:19.282848	Corporate income tax and other tax charges.	t
a8a51c2e-40ec-4ba9-8396-2281873dcae6	1240	Prepaid Expenses	asset	\N	f	2026-07-31 13:01:27.123761	2026-07-31 13:01:27.123761	Payments made in advance for services consumed over time.	t
\.


--
-- Data for Name: adjustment_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.adjustment_requests (id, adjustment_type, description, reason_code, changes, reference_type, reference_id, status, rejection_reason, requested_by, reviewed_by, reviewed_at, created_at, updated_at) FROM stdin;
0224dccd-48a9-4c41-a539-39687498e765	metadata_correction	Installment marked paid but payment reference missing from webhook payload	MISSING_WEBHOOK	{"paymentReference": "PR-INST-A-006"}	installment	b0d51976-eb23-446b-a096-c84786ee004f	pending	\N	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	\N	\N	2026-07-31 13:24:12.297527	2026-07-31 13:24:12.297527
29e51fd7-82ef-4ef7-a0cb-45823a0ee7f5	metadata_correction	Corrected due date recorded against wrong installment	DATA_ENTRY_ERROR	{"notes": "Re-scheduled after grace period", "dueDate": "2026-08-08"}	installment	f6116a9f-1ce5-4411-8d20-8aedc1a11f29	approved	\N	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-30 01:00:00	2026-07-31 13:24:12.297527	2026-07-31 13:24:12.297527
268ba73d-484a-46f9-a306-8b1a0bda5e4a	journal_entry	Duplicate journal entry proposed for BNPL fee income	DUPLICATE_ENTRY	{}	journal	\N	rejected	Identical entry already posted on the same date	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-29 01:00:00	2026-07-31 13:24:12.297527	2026-07-31 13:24:12.297527
\.


--
-- Data for Name: apex_organizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.apex_organizations (id, name, code, status, created_by, created_at, updated_at, bank_name, account_name, account_number, sort_code, bank_code, address, contact_email, contact_phone, contact_person_name, contact_person_phone, contact_person_email) FROM stdin;
c148cc61-b0ba-4d8f-be6b-39f34e1538e1	Demo Apex Cooperative	APEX001	active	\N	2026-07-22 19:32:13.391636	2026-07-22 19:32:13.391636	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
b8ecfc27-24f1-4dd5-9668-9ba5b2d420ed	Lagos State Cooperative	APEX002	active	\N	2026-07-22 21:29:28.501025	2026-07-22 21:29:28.501025	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
94fa108c-1fc3-45b1-829c-0183e2a31eb6	Federal Employees Alliance	APEX003	active	\N	2026-07-22 21:29:28.51954	2026-07-22 21:29:28.51954	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
63bc3543-39e3-4c1c-85b4-c3f2802099c5	Tech Workers Cooperative	APEX004	active	\N	2026-07-22 21:29:28.526808	2026-07-22 21:29:28.526808	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_settings (id, key, value, updated_at) FROM stdin;
c7009b1a-82e0-4350-96da-4e8aa190629e	registration_fee	5000	2026-07-22 20:46:32.308657
db863787-9ad6-4038-ac4d-984d11e36519	fee_platform_percent	30	2026-07-22 21:18:57.628672
75e358b7-b90f-4ac8-b0c6-c5e188ea3404	fee_organization_percent	35	2026-07-22 21:18:57.650442
02302660-f228-4e49-9a49-849fc66db272	fee_apex_percent	15	2026-07-22 21:18:57.652119
f0538f9e-78b1-4976-90a7-31fff1b1b849	credit_limit_multiplier_with_loan		2026-07-25 00:44:05.693976
dd24b359-8e6f-4618-b98d-2ca324eb4fd4	credit_limit_multiplier_no_loan		2026-07-25 00:44:05.707684
af7fe125-4fdd-4764-902d-c6ece4718b62	credit_limit_max_cap		2026-07-25 00:44:05.707749
5b2a7c61-78de-4109-9337-6c90252b1379	loan_multiplier		2026-07-25 00:44:05.718216
6c73ad46-5cd1-4862-9ecd-bcc455db68e5	credit_limit_vesting_months		2026-07-25 00:44:05.714663
4244e31a-7ee5-4d4f-8947-e76d4808b2c6	loan_vesting_months		2026-07-25 00:44:05.719448
4032dfac-2f0d-4126-b37f-3400e541d0b6	withdrawals_enabled	false	2026-07-25 01:26:31.111093
c6f5f8dc-57b9-4840-943e-35d0af0004bf	backup_enabled	true	2026-07-31 00:30:29.02418
e660fe3f-50a3-422d-bad8-b8ec6db7b5aa	fee_super_admin_percent	20	2026-07-22 21:18:57.653844
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, action, "entityType", "entityId", performed_by, metadata, "ipAddress", created_at) FROM stdin;
4f41796c-a765-458e-a7b0-68ec8cd6890c	LOGIN	User	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	{}	::1	2026-07-30 16:48:48.80232
7a56412e-7bb4-41f2-8fd8-10d43e2e5adc	USER_CREATE	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	{"role": "individual", "email": "kolo@coop.com"}	\N	2026-07-30 17:03:48.466684
2e940a9d-35f1-405b-b737-8344b564e575	LOGIN	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	{}	::1	2026-07-30 17:15:51.326592
2cb1f6d4-1284-4f31-ae71-1f9d7c1f129c	LOGIN	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	{}	::1	2026-07-30 17:29:46.294654
6751a08f-7807-444c-b8d8-fb4a43a5a00c	LOGIN	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	{}	::1	2026-07-30 17:34:26.950635
18ab1bb7-b3b1-4f21-8b74-c43a1f113e49	LOGIN	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	{}	::1	2026-07-30 19:51:10.793891
6dc86629-d6af-4f89-b084-fbc4fb8da5d0	LOGIN	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	{}	::1	2026-07-30 20:35:12.189077
f2a5c493-d788-4b96-970f-6e306da06374	LOGIN	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	{}	::1	2026-07-30 21:43:41.681529
f4204fd2-107a-4b8e-b527-d356443536ec	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-30 21:53:41.291456
1716acb8-ffcc-4eed-bd03-6c017de0310d	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-30 22:29:59.527031
863ab08b-30fd-4c56-a576-e8093cab8ea1	LOGIN	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	{}	::1	2026-07-30 22:42:04.353244
95c865d3-298f-4cd8-a7a1-e741585af47b	LOGIN	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	{}	::1	2026-07-30 22:52:51.362648
d65f3f01-d109-4fe8-913f-518548c57304	LOGIN	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	{}	::1	2026-07-30 22:59:20.925354
f92d478c-a898-4c86-a4a6-8afb42e711a9	LOGOUT	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	\N	\N	2026-07-30 23:00:19.209959
a25845d8-d846-4ea2-ae5b-f4a7ecec5426	LOGIN	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	{}	::1	2026-07-30 23:00:24.840879
f7ad5bb9-1a20-4669-9811-967cf26daaba	LOGOUT	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	\N	\N	2026-07-30 23:13:10.104069
0c57062a-4bf6-46ac-aeb8-768f9359f76d	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-30 23:13:17.84073
9bac6033-2ba4-4cf3-aeb2-e76a7ca57e2d	LOGOUT	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	\N	\N	2026-07-30 23:13:28.578263
925f66bf-3ce5-471e-8234-328f8c667971	LOGIN	User	f1cc999e-326f-46e4-9a00-b5eac95ae581	f1cc999e-326f-46e4-9a00-b5eac95ae581	{}	::1	2026-07-30 23:13:38.291807
be7ce2dc-372e-4837-9480-ed9fa3864aea	LOGOUT	User	f1cc999e-326f-46e4-9a00-b5eac95ae581	f1cc999e-326f-46e4-9a00-b5eac95ae581	\N	\N	2026-07-30 23:14:10.07525
2ea5aa98-90f6-42be-bbbc-15bab7a17cc5	LOGIN	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	{}	::1	2026-07-30 23:14:19.123073
d624271e-50fe-4a00-bec9-d377cf70aa33	LOGIN	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	{}	::1	2026-07-30 23:37:08.576739
c5b9e8ee-069b-4692-b145-4897ff8ac266	LOGIN	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	{}	::1	2026-07-30 23:52:37.748579
92af8886-5cd7-4be9-be93-e330d7042cb4	RETENTION_PURGE	\N	\N	\N	{"purged": {"sms_logs": 0, "webhook_logs": 0, "login_history": 0, "kyc_anonymized": 0, "bnpl_audit_logs": 0, "device_sessions": 0, "kyc_submissions": 0, "support_tickets": 0, "user_activities": 0, "in_app_notifications": 0}, "anonymized": 0}	\N	2026-07-31 00:00:00.084123
5bb9e569-74d0-4f3e-a105-3525b03143f6	LOGOUT	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	\N	\N	2026-07-31 00:03:50.506293
48e28f16-f2cd-445b-813b-f3147feb98e4	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 00:03:55.907986
530b1cc4-28d0-4998-a4e3-0dfaf2d45f0c	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 00:20:06.084681
2bb90432-cf28-4acc-8527-1425da4142a6	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 00:34:26.102248
2a0e63db-bd91-4aa1-b3c2-e26f0355cb94	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 00:51:39.592739
b2a946d2-8fbe-4046-bf5a-f6e9a6f7a176	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 10:37:59.557344
221db111-c553-4193-a1f0-fbe047db070a	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 10:53:41.759928
840c8937-66f5-4f45-8d4e-a7fa1d532967	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 10:53:59.896302
74ac1ea4-0709-4e9b-acc8-26f76af1f58a	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 10:54:39.111109
5fa9fba1-3df0-4633-a1df-e98a21882af9	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 10:54:47.081028
638107e8-5a00-4b4c-9bbb-fa9c5b316851	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 10:54:55.403394
00044474-92be-4941-9c2c-cad3a53cf31a	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 11:06:17.09179
c1831eca-e68f-4247-b70f-5497600f17b0	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 11:09:19.729707
3d7c8e9c-12a6-40d2-ba5c-7411ea94b6ae	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 11:16:03.3912
ae75f53e-a0d6-4efe-8f08-e64d694cd659	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 11:16:10.774099
d427585d-2850-423c-8f47-7a56215d6872	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 11:25:58.882843
e37923a2-febf-44f4-9ef8-eb7602e2299d	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 11:26:27.115242
784752be-630d-416f-87d7-2cfc01327a71	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 11:26:32.456575
7319a768-3ece-4309-a3b2-3845bc7f7e72	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 11:26:38.472361
ae753a91-53b4-4258-b6f9-f81694717c46	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 11:46:21.029563
356aeac6-442c-4e38-abfe-fff9ec46445b	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 11:46:43.211871
3e9d79b7-f94e-4bbe-ad6a-dc8ee582ece6	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 12:05:49.376722
19f02df4-4506-4bf1-9eff-0987d4fddc9e	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 12:28:49.196122
0f094099-597c-427d-8e17-65a96a9a5791	LOGOUT	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	\N	\N	2026-07-31 12:38:16.981782
dead8481-79cf-4160-8135-930808849523	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-07-31 12:38:24.958217
7e859931-7924-40ff-b693-d2dab3cce52e	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 12:42:24.67894
b2a440d0-83c1-4b1d-9602-6275dd1433f1	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-07-31 12:54:32.901896
dc9ac548-3f21-40b1-9566-4252eb1f84d8	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-07-31 12:54:57.69916
b4432f29-605c-4ad3-a372-0c6c8dfce16c	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-07-31 12:55:59.590494
17c4747b-b6ca-4f35-b5a8-4f39f2a75d58	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-07-31 13:01:34.905051
3066bb14-72c0-40e3-8234-7d7047122846	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-07-31 13:25:57.299479
31e2e34c-3006-4af6-add7-ab6c7419a1ae	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-07-31 13:26:05.244716
326f423b-1519-4c85-baf3-8c6fa68b6740	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-07-31 13:32:05.039133
4d5f3e26-41ca-4d94-b2ed-a1e9bbf1abea	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-07-31 13:34:57.34702
e5387e68-8c1b-4dce-81c1-29ee80ec6ddc	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-07-31 13:37:51.707911
121e1f85-7c89-408f-9743-147945857de8	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-07-31 13:53:31.481071
236e83bd-d155-4272-9ee0-56e9797d514b	LOGOUT	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	\N	\N	2026-07-31 13:55:43.324707
a7d51a97-eae3-4352-a662-b59d86b994d7	LOGIN	User	f1cc999e-326f-46e4-9a00-b5eac95ae581	f1cc999e-326f-46e4-9a00-b5eac95ae581	{}	::1	2026-07-31 13:55:50.923687
2b16963b-83b9-429f-abf7-7b6008f15e4b	RETENTION_PURGE	\N	\N	\N	{"purged": {"sms_logs": 0, "webhook_logs": 0, "login_history": 0, "kyc_anonymized": 0, "bnpl_audit_logs": 0, "device_sessions": 0, "kyc_submissions": 0, "support_tickets": 0, "user_activities": 0, "in_app_notifications": 0}, "anonymized": 0}	\N	2026-08-01 00:14:35.936612
8142fe5f-badd-4d2f-b3cf-1c1fcaa01415	LOGIN	User	f1cc999e-326f-46e4-9a00-b5eac95ae581	f1cc999e-326f-46e4-9a00-b5eac95ae581	{}	::1	2026-08-01 19:25:21.395946
857999e2-6fa9-4471-b711-379da08d964f	LOGOUT	User	f1cc999e-326f-46e4-9a00-b5eac95ae581	f1cc999e-326f-46e4-9a00-b5eac95ae581	\N	\N	2026-08-01 19:25:49.297293
567156d0-b972-4cef-a44e-6e7829d8dfca	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-01 19:26:03.801123
af6e6d4b-e8d9-4553-beae-83bbbd41bf0c	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-01 19:32:31.187248
935498a3-e8be-46cd-971b-59699cddaff9	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-01 19:34:18.108673
aa097767-5f97-4bd4-b3c1-781032d61088	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-01 19:35:11.953956
662c6055-1fed-441d-af85-8a705734e5f5	LOGIN	User	27626449-01e5-4a80-aeaf-3243caf42466	27626449-01e5-4a80-aeaf-3243caf42466	{}	::1	2026-08-01 19:35:33.828848
8022d41b-349b-4306-8104-b8896ee6e1f4	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-01 19:35:44.661409
ee9c7bcc-b013-4306-822a-dfbabad65487	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-01 19:36:15.834879
e52c396b-88e2-4ff6-b09e-e3cf1a691562	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-01 19:36:45.057592
e2279a8d-e1ce-4e4d-b64b-4e15f063f9ac	LOGIN	User	0158c520-82d2-42ec-86b9-23165db8602e	0158c520-82d2-42ec-86b9-23165db8602e	{}	::1	2026-08-01 19:36:46.292048
ae96ab6c-74a9-400e-8332-d7fecc7ded0e	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-01 19:42:38.988904
2d097bc8-a914-4a5d-a102-fa5a18e1117a	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-01 19:50:46.158917
acba4edf-9bb6-4814-bcbb-2a919b8b20a3	PASSWORD_CHANGE	User	e04cbdc4-0926-4d69-90ae-4e91ea617ed5	e04cbdc4-0926-4d69-90ae-4e91ea617ed5	{"reason": "first_login"}	\N	2026-08-01 19:51:09.949789
fb12c2ac-9460-4ad6-a132-fc611c499b3b	LOGIN	User	e04cbdc4-0926-4d69-90ae-4e91ea617ed5	e04cbdc4-0926-4d69-90ae-4e91ea617ed5	{}	::1	2026-08-01 19:51:10.199876
a225e097-5f8f-4361-9c24-69297016ca0d	LOGIN_FAILED	User	e04cbdc4-0926-4d69-90ae-4e91ea617ed5	\N	{"reason": "Invalid password", "attempt": 1}	::1	2026-08-01 19:51:10.416812
2dc1a423-6c95-4898-a25b-e5e4c13230fd	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-08-01 19:51:19.393991
a97e77c8-776a-498e-bb5f-202026244228	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-01 19:52:39.504925
94436ff6-ca56-4681-b9b5-5a3e397b575f	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-08-01 19:55:34.945866
b0fd14eb-046c-4244-ab2b-9e6f5ea77021	LOGOUT	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	\N	\N	2026-08-01 19:55:40.806666
bdd0e033-e734-4652-b29e-2e7182a93c29	LOGIN	User	5a53b031-f7c7-4b2d-a7ff-d3f4cf319009	5a53b031-f7c7-4b2d-a7ff-d3f4cf319009	{}	::1	2026-08-01 19:56:55.696195
b1bcddad-cda0-4d00-a457-2b307452bd7a	LOGOUT	User	5a53b031-f7c7-4b2d-a7ff-d3f4cf319009	5a53b031-f7c7-4b2d-a7ff-d3f4cf319009	\N	\N	2026-08-01 19:57:13.150773
0bfc3337-60f6-47ff-b53d-dfcb79072338	LOGIN	User	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	{}	::1	2026-08-01 19:57:22.034451
e70bff98-d489-4df2-8c9b-4c778cb87dce	LOGOUT	User	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	\N	\N	2026-08-01 19:58:15.197957
7c7d4c9f-09ee-4464-b792-df7028ecd181	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 19:59:29.229144
eadc7afe-c5db-4e71-8e8b-596f22e4780e	LOGOUT	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	\N	\N	2026-08-01 20:05:53.887595
00360f68-3ee8-4884-901b-67b413f47d02	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:06:13.652778
74c8ea02-4d1a-462f-b2b9-6d36358a7b55	LOGOUT	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	\N	\N	2026-08-01 20:08:02.597055
ce117d67-47eb-45ca-b4ed-f36f5d8e2f7b	LOGIN	User	f1cc999e-326f-46e4-9a00-b5eac95ae581	f1cc999e-326f-46e4-9a00-b5eac95ae581	{}	::1	2026-08-01 20:08:26.483475
c77390c7-7524-4b83-8708-158f7d6dfd96	LOGOUT	User	f1cc999e-326f-46e4-9a00-b5eac95ae581	f1cc999e-326f-46e4-9a00-b5eac95ae581	\N	\N	2026-08-01 20:08:37.388027
2a33487f-951c-4f09-a50b-d79527def176	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:08:44.293259
3559b8c1-837d-4f4a-8b80-3f716fde120c	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:08:56.247281
921ed859-0afd-4deb-8cec-6f39d95a8a38	LOGOUT	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	\N	\N	2026-08-01 20:11:19.93038
5b52682b-f8bf-4eee-8daf-26be1559a950	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:11:32.985828
f2b97ee3-c931-4a24-886f-42c5479006f1	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:13:09.726899
332b2c9a-0a44-4856-8c83-536d314121ea	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:16:58.461247
914d2ca6-c542-4fff-b72b-44ffd272b857	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:21:27.752542
b38bb366-d8fe-4b13-84af-f7c3a42b4a68	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:21:33.305912
3669863c-5d2d-4c8e-83a9-896125260fc2	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:21:42.459729
2a010633-51c7-4044-829e-156d4c23afdd	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:27:13.389793
7daa95ff-0224-4fbc-96a0-d8f8959b147f	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:27:41.296328
2a11e8cc-a4e2-42a1-9a10-b50e7ec9d688	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:27:48.414715
fa07a5ee-803a-4d7a-a9f3-6647eb52b73b	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:28:13.184339
814f2b09-84c5-4b17-815d-516b56e62307	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:44:59.494581
235ee258-7667-4790-87a0-293bca394a0c	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:48:34.471035
68f7a70b-7b09-419b-81d7-6f6a2d453c1e	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 20:49:40.994676
51696cc3-7be4-4700-8316-57cbc1307379	LOGOUT	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	\N	\N	2026-08-01 21:01:39.972865
fca73a17-645e-412e-833b-52b41a5d1246	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 21:06:16.314822
5264cf2e-d143-4a32-a414-1f324d978fea	LOGOUT	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	\N	\N	2026-08-01 21:07:04.712161
e34379c2-c209-4b07-876f-a03ecadb646f	LOGIN	User	f1cc999e-326f-46e4-9a00-b5eac95ae581	f1cc999e-326f-46e4-9a00-b5eac95ae581	{}	::1	2026-08-01 21:07:13.635593
f64121ed-a607-4ce7-8c3c-a79525fe3d50	LOGOUT	User	f1cc999e-326f-46e4-9a00-b5eac95ae581	f1cc999e-326f-46e4-9a00-b5eac95ae581	\N	\N	2026-08-01 21:07:24.920096
33d3f013-92de-4afa-ade5-4a136cf96a5b	LOGIN	User	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	{}	::1	2026-08-01 21:07:40.744948
815548b3-496d-453e-af58-b0e58907c3bb	LOGOUT	User	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	\N	\N	2026-08-01 21:08:05.787172
f64c1e57-da38-4be5-b9e0-392fa3bb5671	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 21:08:16.192769
78e82dae-c62d-4dfa-b036-7739d2db7163	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 21:13:57.190085
4dc49d53-a302-4957-a22e-356cfcb9cd9d	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 21:14:09.474931
87523675-637d-4fe1-804b-957afe28b725	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 21:14:16.98531
e6b3dce7-c402-4f71-9b61-a4d09e87f123	LOGOUT	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	\N	\N	2026-08-01 21:21:45.340872
b9c55b26-4940-4211-ad46-36fa42a6bfcd	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-01 21:21:55.849705
624ff9fb-2448-4860-9e86-c7b6f1f12d5c	LOGOUT	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	\N	\N	2026-08-01 21:23:09.689819
d534db4f-4a32-4bd8-8fe9-4508075fdec3	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 21:23:20.647711
c5f23731-35d0-456d-9257-001789424df3	LOGIN	User	6ccb2ee7-4961-4316-b230-04598845ef6c	6ccb2ee7-4961-4316-b230-04598845ef6c	{}	::1	2026-08-01 21:36:18.137473
ff92c23c-9f75-4c22-ae5e-ebd215c3b635	LOGIN	User	6ccb2ee7-4961-4316-b230-04598845ef6c	6ccb2ee7-4961-4316-b230-04598845ef6c	{}	::1	2026-08-01 21:36:26.045206
4d9621be-a6b6-4dbd-911a-166d068ccfb8	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 21:56:42.394684
49d5ef27-c77e-4a41-b0a2-b6e2beb06dc6	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 22:00:01.649628
b2d72fa0-0a25-4096-9a71-dc5524f74b0e	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-01 22:05:57.522628
f6824381-17dd-4e4d-9f8f-2d9fb717cbbc	RETENTION_PURGE	\N	\N	\N	{"purged": {"sms_logs": 0, "webhook_logs": 0, "login_history": 0, "kyc_anonymized": 0, "bnpl_audit_logs": 0, "device_sessions": 0, "kyc_submissions": 0, "support_tickets": 0, "user_activities": 0, "in_app_notifications": 0}, "anonymized": 0}	\N	2026-08-02 00:00:00.228891
7ca21c4f-1cef-4366-8195-628bc0930867	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-02 10:28:42.019695
c796309a-3c9c-486a-8530-ebd852dc962c	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-02 10:32:33.573258
d26cf424-17d6-4abb-8a2e-10e60eb09170	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-02 10:45:45.966962
ba27505b-257b-4fae-b562-a16cab521997	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-02 10:46:56.272564
640f605b-5ccc-4310-a008-70479a9a1549	LOGOUT	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	\N	\N	2026-08-02 10:47:49.724622
8c8af93b-abd9-41c4-9f53-f8d9881f8997	LOGIN	User	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	{}	::1	2026-08-02 10:48:29.236593
199afba9-6088-444d-b89a-415b7bb5d358	LOGIN	User	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	{}	::1	2026-08-02 10:54:43.830415
dd28271b-7dc7-4d84-9e4a-dd4144c89a53	LOGIN	User	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	{}	::1	2026-08-02 11:02:02.187541
c24edeaf-8cbe-4e7f-b126-1a039e3c5b9e	LOGIN	User	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	{}	::1	2026-08-02 11:07:52.193182
d6af0b02-f53d-45e4-9d8b-7c69117dd274	LOGIN	User	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	{}	::1	2026-08-02 11:15:40.041031
ddc87e77-5466-49e9-9216-5c8ccdfbae8b	LOGOUT	User	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	\N	\N	2026-08-02 11:20:11.877337
7c8e09bb-f411-4791-9ee6-64d6e38ea2e5	LOGIN	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	{}	::1	2026-08-02 11:20:20.314115
b9de0407-4bf5-422d-b0f8-28a70323c380	LOGOUT	User	dd856b59-9087-464f-aaae-7aa764d00670	dd856b59-9087-464f-aaae-7aa764d00670	\N	\N	2026-08-02 11:21:58.297844
657aa5aa-aa67-44f6-bf48-784adfeb164c	LOGIN	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	{}	::1	2026-08-02 11:22:13.687515
5c0dddbb-1f65-4093-8744-d6fec02ce53d	LOGIN	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	{}	::1	2026-08-02 11:40:10.046826
e30b3dee-f6ae-496f-9708-12d667d436c9	LOGIN	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	{}	::1	2026-08-02 11:55:15.59131
f1744fa9-a644-4610-ad2f-0c5c58315bae	LOGIN	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	{}	::1	2026-08-02 12:07:45.586253
b550ef49-e389-42c1-936f-a1e268466dbe	LOGIN	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	{}	::1	2026-08-02 12:11:22.149249
7f0fdad0-dd07-4b5c-b345-ba7461062002	LOGOUT	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	\N	\N	2026-08-02 12:14:37.983786
47f351e5-ad65-443a-bd1b-e32dd52ac706	LOGIN	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	{}	::1	2026-08-02 12:35:47.964516
d1aab1e8-3d57-4019-bac4-e1fc1e887f8a	LOGOUT	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	\N	\N	2026-08-02 12:39:36.762354
4ce2d5e2-9d20-4ca9-b751-f17f40cdd4e8	LOGIN	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	{}	::1	2026-08-02 12:40:27.641646
8aca0cd4-0aa5-49df-aeae-e46fb056a774	LOGOUT	User	560fb107-91f5-4df9-aa38-714c5fc0cfb6	560fb107-91f5-4df9-aa38-714c5fc0cfb6	\N	\N	2026-08-02 12:43:48.623054
cde45a71-dfd1-4bcc-9b27-87e5a32a7303	LOGIN	User	f1cc999e-326f-46e4-9a00-b5eac95ae581	f1cc999e-326f-46e4-9a00-b5eac95ae581	{}	::1	2026-08-02 12:44:06.009897
890ea4d6-ccc5-4886-b840-d4a8ad396c79	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 12:54:37.376482
4014846d-8378-4318-8743-54a487bdbb40	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 12:54:41.909314
3d5fbe64-1738-488f-a818-1ffb676cca5f	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 12:54:47.064942
9d095eb2-9f6a-47f8-b97c-3126415f1458	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 12:54:52.348435
98366b74-3cc2-40af-947f-e2ddaf4a9496	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 12:54:58.405047
35f008ed-2c69-4323-8639-b2e00b0866ea	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 12:56:33.038611
4e817117-f374-43ea-9c81-e8fe8edd1bc0	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 12:56:49.127591
eb036af5-f461-4b6b-bcca-01cb1818fe6e	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 12:57:52.469799
ea900886-4584-4399-84a2-82365a544f50	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 12:57:57.546126
cdc234d2-1406-4c75-91f1-1a3784748cac	LOGIN	User	f1cc999e-326f-46e4-9a00-b5eac95ae581	f1cc999e-326f-46e4-9a00-b5eac95ae581	{}	::1	2026-08-02 13:04:04.941131
1ffcfc2b-d041-467a-a782-869d82a1a2fc	LOGOUT	User	f1cc999e-326f-46e4-9a00-b5eac95ae581	f1cc999e-326f-46e4-9a00-b5eac95ae581	\N	\N	2026-08-02 13:08:52.571255
0b5d1863-001b-492e-90ad-db61ab8c06a4	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 13:09:26.763448
92a3a341-27d9-4af6-b778-18993f5f140f	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 13:17:02.957614
c02d86fb-d4a8-404e-996c-5e3a332777c1	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 13:17:10.584073
a3f9a66c-1b9e-4387-8c93-a377aac6d5e2	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 13:17:26.295511
6e149c83-c1b9-4db2-9018-6d16aea7d04b	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 13:17:34.133351
ee1d879a-12dd-4db9-a605-a372107dd824	LOGIN	User	aa38f00e-7fbd-4d31-890f-d63c6ef2b452	aa38f00e-7fbd-4d31-890f-d63c6ef2b452	{}	::1	2026-08-02 13:17:40.912
506b1d17-fda7-4111-ade6-12c1b6114153	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 13:18:13.426751
5fc901f0-b06e-4687-99ef-4bcac7a162fc	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 13:18:20.524337
849ca94b-40b1-4c0c-8544-9cee88f271c1	USER_CREATE	User	0779d3d4-9a41-441f-9823-49702b064aa6	0779d3d4-9a41-441f-9823-49702b064aa6	{"role": "individual", "email": "dup1@coop.com", "pendingPayment": true}	\N	2026-08-02 13:26:06.80066
19823b40-5e46-4ae9-a5fe-40fe937bb777	USER_CREATE	User	bb3b64c5-0635-4521-85fc-b90dc5f369f8	bb3b64c5-0635-4521-85fc-b90dc5f369f8	{"role": "individual", "email": "fresh1@coop.com", "pendingPayment": true}	\N	2026-08-02 13:26:07.103165
deb67624-1a86-4de4-acab-c0802ecdf048	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 13:26:20.669577
1121c997-04f3-4b61-8f85-056e1637242d	LOGIN	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	{}	::1	2026-08-02 13:26:29.075263
07b756df-a5ee-4b93-820a-e990da07b935	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 13:28:00.341029
ac011d2c-bdbb-4501-9558-b4b8fe693051	LOGIN	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	{}	::1	2026-08-02 13:28:27.804292
9e78addd-5c48-457a-bfb3-4cac725b1f56	LOGIN_FAILED	User	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	\N	{"reason": "Invalid password", "attempt": 1}	::1	2026-08-02 13:28:40.791972
b0dfec29-5fbe-4b95-b6d7-b02715cebe06	LOGIN	User	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	bd5e5ca7-46dc-4ff7-bb20-ef2e77b16782	{}	::1	2026-08-02 13:30:13.036958
31268be5-7b33-4f18-a86f-6e5306367181	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 13:30:21.873191
d5571913-7f42-40d3-b8b5-9ee0e4b55e1c	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 13:42:24.108097
36bbdf56-d7e8-4254-91a8-abbdb1c12133	LOGIN	User	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	{}	::1	2026-08-02 13:42:46.173469
a1a1f72d-cfa7-44a5-a81f-6cbd5aa8116d	LOGIN	User	fff19150-f8f4-4330-a063-63d1b0d82372	fff19150-f8f4-4330-a063-63d1b0d82372	{}	::1	2026-08-02 13:50:36.631919
4769bd18-e16d-4ce0-8c4a-0c525cce2a2d	LOGIN_FAILED	User	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	\N	{"reason": "Invalid password", "attempt": 1}	::1	2026-08-02 14:00:38.750623
5c9314d4-0bf8-460c-b74f-8d84ed79bfd7	LOGIN	User	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	{}	::1	2026-08-02 14:00:51.04523
e6468355-0687-4434-82b4-493960e138a1	LOGIN	User	fff19150-f8f4-4330-a063-63d1b0d82372	fff19150-f8f4-4330-a063-63d1b0d82372	{}	::1	2026-08-02 14:00:52.083117
6cf0681d-b275-4228-b7a5-a5a741a3734f	LOGOUT	User	fff19150-f8f4-4330-a063-63d1b0d82372	fff19150-f8f4-4330-a063-63d1b0d82372	\N	\N	2026-08-02 14:01:39.75607
a5456771-f270-4143-bb17-53e756c659dc	LOGIN	User	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	{}	::1	2026-08-02 14:01:47.013299
b364db37-50da-4c18-ac0e-b2ff6c17ed01	LOGIN	User	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	{}	::1	2026-08-02 14:28:12.711434
d4b1b43b-1a9c-4fc3-a6ee-c6ee42b4ce6b	LOGIN	User	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	{}	::1	2026-08-02 14:43:29.849746
51d26cd6-edf6-4f91-b7b4-d82c170d1191	LOGIN	User	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	{}	::1	2026-08-02 14:58:52.482823
c0ada0d9-9baa-4699-a3a1-7d84e9fd86e2	LOGOUT	User	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	\N	\N	2026-08-02 15:09:13.733761
49436208-9800-4427-95a3-c7140f48f8b9	LOGIN	User	fff19150-f8f4-4330-a063-63d1b0d82372	fff19150-f8f4-4330-a063-63d1b0d82372	{}	::1	2026-08-02 15:16:45.374113
65610f30-2b01-4fad-b955-b1539c7a8bab	LOGIN	User	fff19150-f8f4-4330-a063-63d1b0d82372	fff19150-f8f4-4330-a063-63d1b0d82372	{}	::1	2026-08-02 15:34:58.8576
97897cc8-566a-4e07-8b18-ef03f36c6eb9	LOGIN	User	fff19150-f8f4-4330-a063-63d1b0d82372	fff19150-f8f4-4330-a063-63d1b0d82372	{}	::1	2026-08-02 15:36:24.545394
c49ced2c-2a63-4948-8562-de9871b529ef	LOGIN	User	fff19150-f8f4-4330-a063-63d1b0d82372	fff19150-f8f4-4330-a063-63d1b0d82372	{}	::1	2026-08-02 15:39:45.102548
8c888d65-b061-4300-8298-5b1c195970c7	LOGIN	User	fff19150-f8f4-4330-a063-63d1b0d82372	fff19150-f8f4-4330-a063-63d1b0d82372	{}	::1	2026-08-02 15:40:32.994292
1c8b35db-afd4-4bed-8f1b-d038c0d17c91	LOGIN	User	fff19150-f8f4-4330-a063-63d1b0d82372	fff19150-f8f4-4330-a063-63d1b0d82372	{}	::1	2026-08-02 15:41:33.531595
7ac39937-6ab7-44f4-879a-6101e342c746	LOGIN	User	fff19150-f8f4-4330-a063-63d1b0d82372	fff19150-f8f4-4330-a063-63d1b0d82372	{}	::1	2026-08-02 18:56:09.965897
\.


--
-- Data for Name: bnpl_approval_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_approval_requests (id, request_type, status, request_data, reason, rejection_reason, requested_by, reviewed_by, reviewed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bnpl_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_audit_logs (id, entity_type, entity_id, action, changes, reason, performed_by, performer_name, "ipAddress", evidence, created_at) FROM stdin;
56cd81bc-7f0e-4587-a717-e33d9bc70fea	subscription	9da03ebd-3457-4193-b286-aec580053d43	status_change	{"status": {"to": "pending_payment", "from": "created"}}	\N	2b549daf-de4d-4ea5-a7fe-596f5c699a4f	Business Manager	\N	\N	2026-07-29 18:33:06.273668
\.


--
-- Data for Name: bnpl_catalog_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_catalog_images (id, catalog_item_id, url, sort_order, created_at) FROM stdin;
c35566bc-f301-4cb0-90ab-27c516f9aec9	cb152539-2a78-4f0f-ba3c-7d7adf29b1d9	/uploads/catalog-images/macbook-pro-14.svg	0	2026-07-30 21:50:43.537501
fccee118-0ac4-40a7-ae36-39a6ac70d402	e6e1a729-30e7-4c37-a71b-a799ff5e7ed9	/uploads/catalog-images/iphone-16-pro.svg	0	2026-07-30 21:50:43.544611
3ca5b75f-1960-4e04-bb74-0a8da26ef45c	06daf883-8516-4af9-a298-337cdce1b6b2	/uploads/catalog-images/samsung-galaxy-s25.svg	0	2026-07-30 21:50:43.550147
2a42cc0d-ed2a-4fe4-b228-2187b8414a53	53caba32-38cd-4733-ae3a-3e7c407382ad	/uploads/catalog-images/sony-wh-1000xm6.svg	0	2026-07-30 21:50:43.555151
5f03594e-6a91-4601-82f0-9ee967d0b2cd	8731dda2-b57b-40e0-992d-174e745f87e6	/uploads/catalog-images/dell-xps-16.svg	0	2026-07-30 21:50:43.56025
4d0d56c4-4c80-47bc-be7a-ac8a6f63a2e7	37965f60-ee6c-443f-b22e-6765b9e883bc	/uploads/catalog-images/ipad-air-m3.svg	0	2026-07-30 21:50:43.565218
\.


--
-- Data for Name: bnpl_catalog_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_catalog_items (id, name, description, price, image_url, created_by, is_global, status, created_at, updated_at) FROM stdin;
37965f60-ee6c-443f-b22e-6765b9e883bc	iPad Air M3	Apple iPad Air 11-inch M3 chip	750000.00	/uploads/catalog-images/ipad-air-m3.svg	43f422a2-64c4-488c-aeee-7827e6d714aa	t	active	2026-07-22 21:49:17.477435	2026-07-31 13:32:54.600899
cb152539-2a78-4f0f-ba3c-7d7adf29b1d9	MacBook Pro 14"	Apple M3 Pro, 18GB RAM, 512GB SSD	2500000.00	/uploads/catalog-images/macbook-pro-14.svg	43f422a2-64c4-488c-aeee-7827e6d714aa	t	active	2026-07-22 21:49:17.402358	2026-07-31 13:32:54.610242
e6e1a729-30e7-4c37-a71b-a799ff5e7ed9	iPhone 16 Pro	Apple iPhone 16 Pro 256GB	1200000.00	/uploads/catalog-images/iphone-16-pro.svg	43f422a2-64c4-488c-aeee-7827e6d714aa	t	active	2026-07-22 21:49:17.43278	2026-07-31 13:32:54.613478
06daf883-8516-4af9-a298-337cdce1b6b2	Samsung Galaxy S25	Samsung Galaxy S25 Ultra 512GB	1100000.00	/uploads/catalog-images/samsung-galaxy-s25.svg	43f422a2-64c4-488c-aeee-7827e6d714aa	t	active	2026-07-22 21:49:17.44512	2026-07-31 13:32:54.617066
53caba32-38cd-4733-ae3a-3e7c407382ad	Sony WH-1000XM6	Wireless noise-cancelling headphones	350000.00	/uploads/catalog-images/sony-wh-1000xm6.svg	43f422a2-64c4-488c-aeee-7827e6d714aa	t	active	2026-07-22 21:49:17.456572	2026-07-31 13:32:54.619759
8731dda2-b57b-40e0-992d-174e745f87e6	Dell XPS 16	Intel Ultra 9, 32GB RAM, 1TB SSD	2800000.00	/uploads/catalog-images/dell-xps-16.svg	43f422a2-64c4-488c-aeee-7827e6d714aa	t	active	2026-07-22 21:49:17.465942	2026-07-31 13:32:54.62604
\.


--
-- Data for Name: bnpl_catalog_org_eligibility; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_catalog_org_eligibility (id, catalog_item_id, organization_id, created_at) FROM stdin;
\.


--
-- Data for Name: bnpl_collection_playbooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_collection_playbooks (id, title, description, trigger_event, recommended_actions, requires_approval, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bnpl_collection_priorities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_collection_priorities (id, entity_type, entity_id, priority, reason, assigned_by, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bnpl_collection_queues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_collection_queues (id, subscription_id, user_id, status, priority, days_overdue, total_overdue_amount, outstanding_principal, last_contacted_at, agent_note, assigned_to, assigned_by, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bnpl_exception_cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_exception_cases (id, subscription_id, reason_id, description, status, created_by, assigned_to, resolution, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bnpl_exception_reasons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_exception_reasons (id, title, description, status, created_by, created_at, updated_at, category, escalation_threshold_days, escalation_threshold_count, escalation_action) FROM stdin;
\.


--
-- Data for Name: bnpl_idempotency_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_idempotency_keys (id, idempotency_key, operation, reference_id, status, result, created_at) FROM stdin;
\.


--
-- Data for Name: bnpl_installments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_installments (id, subscription_id, due_date, amount, status, paid_at, payment_reference, created_at, updated_at, late_fee_amount, grace_period_end) FROM stdin;
b0d51976-eb23-446b-a096-c84786ee004f	9da03ebd-3457-4193-b286-aec580053d43	2026-07-27	68750.00	paid	2026-07-27 01:00:00	PR-INST-A-001	2026-07-31 13:24:12.242426	2026-07-31 13:24:12.242426	0.00	\N
ec46b54e-afd5-4257-bfaa-97b57421ba02	9da03ebd-3457-4193-b286-aec580053d43	2026-07-29	68750.00	paid	2026-07-29 01:00:00	PR-INST-A-002	2026-07-31 13:24:12.242426	2026-07-31 13:24:12.242426	0.00	\N
ce0cb12c-6835-4ad6-86c6-dff58b0f6f77	9da03ebd-3457-4193-b286-aec580053d43	2026-07-31	68750.00	paid	2026-07-31 01:00:00	PR-INST-A-003	2026-07-31 13:24:12.242426	2026-07-31 13:24:12.242426	0.00	\N
b5c93435-7214-4bec-91e6-b73550d1f2b0	9da03ebd-3457-4193-b286-aec580053d43	2026-08-02	68750.00	paid	2026-08-02 01:00:00	PR-INST-A-004	2026-07-31 13:24:12.242426	2026-07-31 13:24:12.242426	0.00	\N
55d85fd4-3e39-4500-b290-cc4215af1184	9da03ebd-3457-4193-b286-aec580053d43	2026-08-04	68750.00	paid	2026-08-04 01:00:00	PR-INST-A-005	2026-07-31 13:24:12.242426	2026-07-31 13:24:12.242426	0.00	\N
baa83726-6193-4d41-b4cf-42191e3d40ef	9da03ebd-3457-4193-b286-aec580053d43	2026-08-06	68750.00	paid	2026-08-06 01:00:00	PR-INST-A-006	2026-07-31 13:24:12.242426	2026-07-31 13:24:12.242426	0.00	\N
814075b9-4933-41ab-bb0c-7bb30dc5c7e0	9da03ebd-3457-4193-b286-aec580053d43	2026-07-28	68750.00	overdue	\N	\N	2026-07-31 13:24:12.242426	2026-07-31 13:24:12.242426	1375.00	\N
0065365c-0c4a-4891-827b-dff1e4fa2891	9da03ebd-3457-4193-b286-aec580053d43	2026-07-30	68750.00	overdue	\N	\N	2026-07-31 13:24:12.242426	2026-07-31 13:24:12.242426	1375.00	\N
f6116a9f-1ce5-4411-8d20-8aedc1a11f29	9da03ebd-3457-4193-b286-aec580053d43	2026-08-08	68750.00	pending	\N	\N	2026-07-31 13:24:12.242426	2026-07-31 13:24:12.242426	0.00	\N
e7157977-7897-4b06-9fc2-8f77d7e8f4ea	9da03ebd-3457-4193-b286-aec580053d43	2026-09-08	68750.00	pending	\N	\N	2026-07-31 13:24:12.242426	2026-07-31 13:24:12.242426	0.00	\N
5e86ff2d-b6f1-4aa4-a1b3-73467931c26c	9da03ebd-3457-4193-b286-aec580053d43	2026-10-08	68750.00	pending	\N	\N	2026-07-31 13:24:12.242426	2026-07-31 13:24:12.242426	0.00	\N
2fabab0f-599b-4889-a549-99466413b4b6	9da03ebd-3457-4193-b286-aec580053d43	2026-11-08	68750.00	pending	\N	\N	2026-07-31 13:24:12.242426	2026-07-31 13:24:12.242426	0.00	\N
30e25dbd-4fd7-46a0-a88f-a252162ca26e	500387b9-1cc9-4955-bf28-0b9a88e81792	2026-08-01	916666.67	paid	2026-08-01 01:00:00	PR-INST-B-001	2026-07-31 13:24:12.273818	2026-07-31 13:24:12.273818	0.00	\N
f81d731d-b980-4467-8604-f11cddc1e85f	500387b9-1cc9-4955-bf28-0b9a88e81792	2026-09-01	916666.67	pending	\N	\N	2026-07-31 13:24:12.273818	2026-07-31 13:24:12.273818	0.00	\N
237fcfa2-0e4a-4afa-a31f-9574132592da	500387b9-1cc9-4955-bf28-0b9a88e81792	2026-10-01	916666.67	pending	\N	\N	2026-07-31 13:24:12.273818	2026-07-31 13:24:12.273818	0.00	\N
be377f91-c9a7-49f2-a3f2-c9aa0a320a0a	f3a02d1b-e083-4cc1-9478-03fb2f28ff2a	2026-08-01	403333.33	pending	\N	\N	2026-07-31 13:24:12.273818	2026-07-31 13:24:12.273818	0.00	\N
95554d43-c833-4a89-87df-8598b3b3f8a9	f3a02d1b-e083-4cc1-9478-03fb2f28ff2a	2026-09-01	403333.33	pending	\N	\N	2026-07-31 13:24:12.273818	2026-07-31 13:24:12.273818	0.00	\N
404d1114-bf45-4039-9b98-60bb1a32eec0	f3a02d1b-e083-4cc1-9478-03fb2f28ff2a	2026-10-01	403333.33	pending	\N	\N	2026-07-31 13:24:12.273818	2026-07-31 13:24:12.273818	0.00	\N
\.


--
-- Data for Name: bnpl_plan_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_plan_configs (id, organization_id, available_tenors, interest_model, max_principal, require_membership, due_date_rule, grace_period_days, late_fee_type, late_fee_value, created_by, updated_by, created_at, updated_at) FROM stdin;
52be92e4-0e61-40a5-b428-446a9c33f456	1c604058-5564-43c5-bf9b-46cdab31b9e9	[{"label": "3 Months", "frequency": "monthly", "installmentCount": 3}, {"label": "6 Months", "frequency": "monthly", "installmentCount": 6}]	simple	500000.00	t	same_day_monthly	3	percentage	5.00	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-31 11:26:38.731969	2026-07-31 11:26:38.731969
\.


--
-- Data for Name: bnpl_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_plans (id, organization_id, catalog_item_id, down_payment_percent, installment_count, installment_frequency, "interestRate", created_by, created_at, updated_at, tenor_options, min_principal, max_principal, eligibility_bands, interest_type, monthly_fee_rate, grace_period_days, late_fee_rate, late_fee_cap_days, is_enabled, version, status) FROM stdin;
3eee6e95-8c56-4dc1-baf2-8ccb1fa0490c	1c604058-5564-43c5-bf9b-46cdab31b9e9	cb152539-2a78-4f0f-ba3c-7d7adf29b1d9	20.00	3	monthly	0.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.424167	2026-07-22 21:49:17.424167	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
33c836ec-fab1-467a-80f5-d74a004568bb	1c604058-5564-43c5-bf9b-46cdab31b9e9	cb152539-2a78-4f0f-ba3c-7d7adf29b1d9	10.00	6	monthly	5.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.428135	2026-07-22 21:49:17.428135	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
c730a49d-2d35-4143-971c-7bd6cddefe48	1c604058-5564-43c5-bf9b-46cdab31b9e9	cb152539-2a78-4f0f-ba3c-7d7adf29b1d9	0.00	12	monthly	10.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.42989	2026-07-22 21:49:17.42989	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
3379860c-4218-4762-bc10-c6bcb73e8997	1c604058-5564-43c5-bf9b-46cdab31b9e9	e6e1a729-30e7-4c37-a71b-a799ff5e7ed9	20.00	3	monthly	0.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.435037	2026-07-22 21:49:17.435037	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
cf1e7cc3-f876-466c-b126-a614549d450f	1c604058-5564-43c5-bf9b-46cdab31b9e9	e6e1a729-30e7-4c37-a71b-a799ff5e7ed9	10.00	6	monthly	5.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.438846	2026-07-22 21:49:17.438846	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
343b26d9-0879-4c2c-a1fb-c9f1c4765a58	1c604058-5564-43c5-bf9b-46cdab31b9e9	e6e1a729-30e7-4c37-a71b-a799ff5e7ed9	0.00	12	monthly	10.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.442489	2026-07-22 21:49:17.442489	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
5bc1b539-686f-4618-b13d-aa8e386c38c1	1c604058-5564-43c5-bf9b-46cdab31b9e9	06daf883-8516-4af9-a298-337cdce1b6b2	20.00	3	monthly	0.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.447074	2026-07-22 21:49:17.447074	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
a308da73-4b5b-4965-b82c-096830c41610	1c604058-5564-43c5-bf9b-46cdab31b9e9	06daf883-8516-4af9-a298-337cdce1b6b2	10.00	6	monthly	5.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.449071	2026-07-22 21:49:17.449071	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
135ca450-bceb-4152-8a99-21f917b7b885	1c604058-5564-43c5-bf9b-46cdab31b9e9	06daf883-8516-4af9-a298-337cdce1b6b2	0.00	12	monthly	10.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.451031	2026-07-22 21:49:17.451031	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
13bfd8ed-f5cc-4e3e-a3da-e4fb028758d3	1c604058-5564-43c5-bf9b-46cdab31b9e9	53caba32-38cd-4733-ae3a-3e7c407382ad	20.00	3	monthly	0.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.458872	2026-07-22 21:49:17.458872	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
233977f9-7df3-4783-abc4-4d39f7ecc856	1c604058-5564-43c5-bf9b-46cdab31b9e9	53caba32-38cd-4733-ae3a-3e7c407382ad	10.00	6	monthly	5.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.461085	2026-07-22 21:49:17.461085	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
b62f9a36-3231-4e66-880d-aed7514da6f4	1c604058-5564-43c5-bf9b-46cdab31b9e9	53caba32-38cd-4733-ae3a-3e7c407382ad	0.00	12	monthly	10.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.462876	2026-07-22 21:49:17.462876	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
abc4fc63-71cf-4a05-8b66-b49b94e0a6a3	1c604058-5564-43c5-bf9b-46cdab31b9e9	8731dda2-b57b-40e0-992d-174e745f87e6	20.00	3	monthly	0.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.467762	2026-07-22 21:49:17.467762	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
ffb5b7a9-d071-4920-b908-0a9e4c81b3f3	1c604058-5564-43c5-bf9b-46cdab31b9e9	8731dda2-b57b-40e0-992d-174e745f87e6	10.00	6	monthly	5.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.469616	2026-07-22 21:49:17.469616	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
b9670c26-fc8b-4dd3-ad50-adfd5751d395	1c604058-5564-43c5-bf9b-46cdab31b9e9	8731dda2-b57b-40e0-992d-174e745f87e6	0.00	12	monthly	10.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.474568	2026-07-22 21:49:17.474568	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
28ea7cdd-83e6-4133-8e30-a3a83017d3ff	1c604058-5564-43c5-bf9b-46cdab31b9e9	37965f60-ee6c-443f-b22e-6765b9e883bc	20.00	3	monthly	0.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.479186	2026-07-22 21:49:17.479186	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
ddff1c15-7627-454e-a8a2-c8b438118e0d	1c604058-5564-43c5-bf9b-46cdab31b9e9	37965f60-ee6c-443f-b22e-6765b9e883bc	10.00	6	monthly	5.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.481	2026-07-22 21:49:17.481	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
e09fe97b-1b30-4cd5-bad1-29afe0a5da94	1c604058-5564-43c5-bf9b-46cdab31b9e9	37965f60-ee6c-443f-b22e-6765b9e883bc	0.00	12	monthly	10.00	43f422a2-64c4-488c-aeee-7827e6d714aa	2026-07-22 21:49:17.482645	2026-07-22 21:49:17.482645	\N	\N	\N	\N	flat	\N	0	0.00	\N	t	1	active
\.


--
-- Data for Name: bnpl_processing_steps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_processing_steps (id, subscription_id, step_type, status, idempotency_key, metadata, error_message, retry_count, external_reference, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bnpl_risk_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_risk_flags (id, entity_type, entity_id, reason, description, flagged_by, status, resolved_by, resolution_note, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bnpl_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bnpl_subscriptions (id, user_id, plan_id, status, down_payment, total_amount, amount_paid, next_installment_date, provider_reference, payout_status, created_at, updated_at, disbursement_reference, disbursed_at, settled_at, approved_at) FROM stdin;
9da03ebd-3457-4193-b286-aec580053d43	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	e09fe97b-1b30-4cd5-bad1-29afe0a5da94	active_repayment	0.00	825000.00	393750.00	2026-08-08	SUB-A-0001	completed	2026-07-24 17:39:21.89977	2026-07-31 13:24:12.235966	DISB-SUB-A-0001	2026-07-25 01:00:00	\N	\N
f3a02d1b-e083-4cc1-9478-03fb2f28ff2a	dc82e50e-c01f-44e4-aac3-a84af916c3da	5bc1b539-686f-4618-b13d-aa8e386c38c1	active_repayment	220000.00	1210000.00	220000.00	2026-08-01	SUB-C-0001	completed	2026-07-31 13:24:12.270394	2026-07-31 13:24:12.270394	DISB-SUB-C-0001	2026-07-29 01:00:00	\N	\N
500387b9-1cc9-4955-bf28-0b9a88e81792	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	3eee6e95-8c56-4dc1-baf2-8ccb1fa0490c	active_repayment	500000.00	2750000.00	1416666.67	2026-09-01	SUB-B-0001	completed	2026-07-31 13:24:12.260689	2026-07-31 13:24:12.260689	DISB-SUB-B-0001	2026-07-28 01:00:00	\N	\N
\.


--
-- Data for Name: device_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_sessions (id, user_id, device_fingerprint, device_name, device_type, os, browser, ip_address, is_trusted, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: disputes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.disputes (id, type, reference_id, user_id, reason, status, resolution, resolved_by, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: distribution_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distribution_payments (id, user_id, holding_id, distribution_id, amount, units_at_record, is_paid, paid_at, created_at) FROM stdin;
\.


--
-- Data for Name: distribution_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distribution_runs (id, distribution_id, product_id, period_start, period_end, total_accrued, total_holdings, payout_count, success_count, failed_count, status, run_summary, approved_by, approved_at, executed_by, executed_at, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: distributions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distributions (id, product_id, type, amount_per_unit, total_pool, record_date, pay_date, description, is_paid, created_at, status, approved_by, approved_at, created_by) FROM stdin;
1f20ec7d-970b-4900-af63-5fc08b8d7b56	7a7a4e2d-1fc4-4ad9-9036-895961b81829	dividend	15.50	3875000.00	2026-03-31	2026-04-15	Q1 2026 dividend payment	t	2026-07-31 10:51:08.185111	executed	00000000-0000-0000-0000-000000000001	2026-04-10 10:00:00	00000000-0000-0000-0000-000000000001
adf9588c-8b25-4be0-8cb4-90203178ffde	b4d49db3-bd7d-48db-81f1-e75f6ae50654	interest	0.42	210000.00	2026-07-31	2026-08-05	July 2026 interest payout	t	2026-07-31 11:15:55.666199	executed	00000000-0000-0000-0000-000000000001	2026-08-01 10:00:00	00000000-0000-0000-0000-000000000001
80892fc8-5941-4072-bfda-1673b35108a8	9ed89d03-0586-496f-b869-4534cc80ef08	profit_share	24.50	3675000.00	2026-03-31	2026-04-20	FY2025 profit share payout	t	2026-07-31 11:15:55.686766	executed	00000000-0000-0000-0000-000000000001	2026-04-15 10:00:00	00000000-0000-0000-0000-000000000001
b7ecb634-70e6-4d26-b026-83dd1ad01dc0	98b4c240-a5c1-4e02-b12e-2dab18837efb	profit_share	0.85	357000.00	2026-06-30	2026-07-05	June 2026 monthly payout	t	2026-07-31 11:15:55.708935	executed	00000000-0000-0000-0000-000000000001	2026-07-01 10:00:00	00000000-0000-0000-0000-000000000001
4446a55c-0603-49eb-abb0-a40af688e560	7a7a4e2d-1fc4-4ad9-9036-895961b81829	dividend	12.00	3000000.00	2026-06-30	2026-07-31	Q2 2026 dividend (approved, pending payment)	f	2026-07-31 11:15:55.715568	approved	00000000-0000-0000-0000-000000000001	2026-07-25 10:00:00	00000000-0000-0000-0000-000000000001
\.


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feature_flags (id, key, name, description, status, environments, cohort_rules, rollout_percentage, created_by, updated_by, enabled_at, is_kill_switch, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fee_pots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fee_pots (id, balance, created_at, updated_at, pot_type, entity_id) FROM stdin;
d849db76-4da8-4d9f-85bd-33e099c993cf	2000.00	2026-07-31 13:24:12.290889	2026-07-31 13:24:12.290889	admin	ADMIN
9ea9189f-d59b-49ad-b411-7bfca6cb5267	5340.95	2026-07-31 13:24:12.290889	2026-07-31 13:24:12.290889	apex	c148cc61-b0ba-4d8f-be6b-39f34e1538e1
1068f1c1-5712-431c-9a77-2b152cbead41	1500.00	2026-07-31 13:24:12.290889	2026-07-31 13:24:12.290889	apex	b8ecfc27-24f1-4dd5-9668-9ba5b2d420ed
f3aadac4-c70a-427d-9da9-4e116014887b	1750.00	2026-07-31 13:24:12.290889	2026-07-31 13:24:12.290889	organization	301336e2-7728-4f40-a5f9-83755964c4df
9627d0d2-c5d5-4ab5-b04e-f1143c0f2229	1750.00	2026-07-31 13:24:12.290889	2026-07-31 13:24:12.290889	organization	3a3cf4a8-bdc6-44c3-80d3-67ac29f7b682
8f00a1eb-588a-481f-ae51-80da86ba1ccf	1500.00	2026-07-31 13:24:12.290889	2026-07-31 13:24:12.290889	apex	94fa108c-1fc3-45b1-829c-0183e2a31eb6
196fbd1f-dff3-4cf7-a9fc-5c0ad90ca6ba	1750.00	2026-07-31 13:24:12.290889	2026-07-31 13:24:12.290889	organization	90256b85-476c-4d11-8774-287c2e4c4654
0a6b8aa4-01ec-45ad-8e0a-97aea1ea565b	1750.00	2026-07-31 13:24:12.290889	2026-07-31 13:24:12.290889	organization	fbfdb1fb-f5dd-41cb-b740-3f32e275eb76
97aa70c5-0d4f-4162-b6fa-b1d1f3bf4033	750.00	2026-07-31 13:24:12.290889	2026-07-31 13:24:12.290889	apex	63bc3543-39e3-4c1c-85b4-c3f2802099c5
cb9a7398-f84f-4afe-87cb-1f5f0227d260	6121.25	2026-07-31 13:24:12.290889	2026-07-31 13:24:12.290889	business_manager	dd856b59-9087-464f-aaae-7aa764d00670
dc8db617-be27-4f7c-a990-600d43d41442	18181.90	2026-07-31 13:24:12.290889	2026-07-31 13:32:05.417843	platform	PLATFORM
4a696aac-ea02-40ad-b4df-f5b10982b42f	0.00	2026-07-31 13:24:12.290889	2026-08-01 20:28:13.394613	organization	1c604058-5564-43c5-bf9b-46cdab31b9e9
e636142e-9c88-4c16-ba98-741c22a5e876	1750.00	2026-07-31 13:24:12.290889	2026-08-01 21:36:26.229072	organization	9cc99602-80f1-4917-b42d-91c0511c6765
\.


--
-- Data for Name: fee_share_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fee_share_ledger (id, payment_id, source, total_fee, super_admin_share, super_admin_user_id, platform_share, organization_share, organization_id, apex_share, apex_org_id, created_at) FROM stdin;
edcb5fb3-ea63-4d04-b0ce-bbf86c963086	0c3ef79f-e155-4d2e-a552-4227409c72a5	registration	5000.00	1000.00	43f422a2-64c4-488c-aeee-7827e6d714aa	1500.00	1750.00	1c604058-5564-43c5-bf9b-46cdab31b9e9	750.00	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	2026-07-31 13:24:12.288142
454514da-d866-4f0b-bb03-116002d6fcc2	bf978956-74c5-4bf3-b110-ad06c8472299	registration	5000.00	1000.00	43f422a2-64c4-488c-aeee-7827e6d714aa	1500.00	1750.00	9cc99602-80f1-4917-b42d-91c0511c6765	750.00	b8ecfc27-24f1-4dd5-9668-9ba5b2d420ed	2026-07-31 13:24:12.288142
a5924f84-0836-4dcf-b3a3-e700e6e15e56	f7e26163-d45d-4642-98db-9fbd87dac169	registration	5000.00	1000.00	43f422a2-64c4-488c-aeee-7827e6d714aa	1500.00	1750.00	301336e2-7728-4f40-a5f9-83755964c4df	750.00	b8ecfc27-24f1-4dd5-9668-9ba5b2d420ed	2026-07-31 13:24:12.288142
c689b9d5-6d85-4d42-ae52-c124d02ea9a4	bb7b0f5d-3696-4afc-ae6d-15e7d40a6daf	registration	5000.00	1000.00	43f422a2-64c4-488c-aeee-7827e6d714aa	1500.00	1750.00	3a3cf4a8-bdc6-44c3-80d3-67ac29f7b682	750.00	94fa108c-1fc3-45b1-829c-0183e2a31eb6	2026-07-31 13:24:12.288142
cd12a686-d23f-4304-a6f3-2b08d04da85c	0240ee01-1ba5-46cf-9036-5af30aabf406	registration	5000.00	1000.00	43f422a2-64c4-488c-aeee-7827e6d714aa	1500.00	1750.00	90256b85-476c-4d11-8774-287c2e4c4654	750.00	94fa108c-1fc3-45b1-829c-0183e2a31eb6	2026-07-31 13:24:12.288142
1aaa3b3f-ef0b-4eb9-afb7-67d7027b0e2f	38f09838-3be1-4f81-9979-75d5fa4a88d9	registration	5000.00	1000.00	43f422a2-64c4-488c-aeee-7827e6d714aa	1500.00	1750.00	fbfdb1fb-f5dd-41cb-b740-3f32e275eb76	750.00	63bc3543-39e3-4c1c-85b4-c3f2802099c5	2026-07-31 13:24:12.288142
d400bc5c-7c37-4efe-97e4-2ea558f3d246	662be206-54f2-47ed-ad1c-10dc3db43e96	bnpl	75.00	15.00	dd856b59-9087-464f-aaae-7aa764d00670	22.50	26.25	1c604058-5564-43c5-bf9b-46cdab31b9e9	11.25	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	2026-07-31 13:24:12.288142
8e4f68b2-b46b-42da-930c-2846e10867a4	90cf9f8a-3adf-4efd-a87a-a39fd8093586	bnpl	75.00	15.00	dd856b59-9087-464f-aaae-7aa764d00670	22.50	26.25	1c604058-5564-43c5-bf9b-46cdab31b9e9	11.25	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	2026-07-31 13:24:12.288142
eddd4aa7-ce3a-4603-b745-c2eb1eab0906	003b6867-5a90-4599-b483-f5453e3e43b8	bnpl	1031.25	206.25	dd856b59-9087-464f-aaae-7aa764d00670	309.38	360.94	1c604058-5564-43c5-bf9b-46cdab31b9e9	154.69	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	2026-07-31 13:24:12.288142
89630bf2-8512-4932-8758-9d8b9aeebbc9	e907b038-9813-4bb2-9345-3cdf9f4cd1f0	bnpl	1031.25	206.25	dd856b59-9087-464f-aaae-7aa764d00670	309.38	360.94	1c604058-5564-43c5-bf9b-46cdab31b9e9	154.69	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	2026-07-31 13:24:12.288142
b4fd2e64-8ae6-4d89-b492-58adb30bb54f	f95f3f43-f4c3-4bf7-a936-6a1b352f6155	bnpl	1031.25	206.25	dd856b59-9087-464f-aaae-7aa764d00670	309.38	360.94	1c604058-5564-43c5-bf9b-46cdab31b9e9	154.69	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	2026-07-31 13:24:12.288142
42998ac3-d6e4-4918-b86e-ec87974b8b75	fb825e06-53aa-40b3-b12e-6e8a76643359	bnpl	1031.25	206.25	dd856b59-9087-464f-aaae-7aa764d00670	309.38	360.94	1c604058-5564-43c5-bf9b-46cdab31b9e9	154.69	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	2026-07-31 13:24:12.288142
ea99fa2a-2299-4455-8c43-3c8b9425bca6	3e09535b-1d3c-4270-ac93-a57389ab98b3	bnpl	1031.25	206.25	dd856b59-9087-464f-aaae-7aa764d00670	309.38	360.94	1c604058-5564-43c5-bf9b-46cdab31b9e9	154.69	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	2026-07-31 13:24:12.288142
ab7dd71f-dd69-4384-91b7-4bd52ed85b42	eb90c9a3-d863-4afa-b509-2a63ca6bbd27	bnpl	750.00	150.00	dd856b59-9087-464f-aaae-7aa764d00670	225.00	262.50	1c604058-5564-43c5-bf9b-46cdab31b9e9	112.50	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	2026-07-31 13:24:12.288142
41020f2f-ec29-49ae-9e40-9c142279b216	5c506fce-a19f-4aff-aac6-2b2d58be6177	bnpl	7500.00	1500.00	dd856b59-9087-464f-aaae-7aa764d00670	2250.00	2625.00	1c604058-5564-43c5-bf9b-46cdab31b9e9	1125.00	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	2026-07-31 13:24:12.288142
0c128556-079f-4334-a1b7-043e72013091	3e428cd3-37d7-40b5-8b30-bb7dc8848e1c	bnpl	13750.00	2750.00	dd856b59-9087-464f-aaae-7aa764d00670	4125.00	4812.50	1c604058-5564-43c5-bf9b-46cdab31b9e9	2062.50	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	2026-07-31 13:24:12.288142
feccc108-2cf9-47cb-8a4f-adc4295aa58a	da21f301-ca86-497f-9068-cc744b5d1359	bnpl	3300.00	660.00	dd856b59-9087-464f-aaae-7aa764d00670	990.00	1155.00	1c604058-5564-43c5-bf9b-46cdab31b9e9	495.00	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	2026-07-31 13:24:12.288142
\.


--
-- Data for Name: fee_withdrawal_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fee_withdrawal_requests (id, pot_type, amount, status, requested_by, approved_by, account_number, bank_code, bank_name, note, created_at, updated_at) FROM stdin;
a9e9cc15-1e79-4afd-baee-46d9117415f1	admin	4000.00	completed	43f422a2-64c4-488c-aeee-7827e6d714aa	43f422a2-64c4-488c-aeee-7827e6d714aa	0123456789	058	GTBank	Admin pot withdrawal — processed by super admin	2026-07-31 13:24:12.295027	2026-07-31 13:24:12.295027
f161305b-01a9-4483-8c12-7ef495b0727f	platform	18181.90	pending	560fb107-91f5-4df9-aa38-714c5fc0cfb6	\N	\N	\N	\N	Platform pot withdrawal request — pending super admin approval	2026-07-31 13:32:25.666564	2026-07-31 13:32:25.666564
\.


--
-- Data for Name: global_risk_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.global_risk_rules (id, "ruleKey", description, enabled, config, created_at, updated_at) FROM stdin;
ba604f35-92ec-4b1f-8b57-b26e65dea252	max_single_withdrawal	Maximum amount allowed per single withdrawal from savings	t	{"amount": 500000}	2026-07-31 00:53:40.870574	2026-07-31 00:53:40.870574
efa96614-3cc2-4065-acb2-af87e237709d	max_daily_withdrawal_total	Total withdrawal amount allowed per day per user	t	{"amount": 1000000}	2026-07-31 00:53:40.882875	2026-07-31 00:53:40.882875
eac7a8e1-52d0-4284-a13e-cf5bbed8af2c	min_savings_balance	Minimum balance that must remain in savings after a withdrawal	t	{"amount": 0}	2026-07-31 00:53:40.885124	2026-07-31 00:53:40.885124
2863f5ba-2648-45af-b4cb-948647bbed0e	max_single_deposit	Maximum amount allowed per single deposit to savings	t	{"amount": 5000000}	2026-07-31 00:53:40.887306	2026-07-31 00:53:40.887306
4a4a9f23-8395-4d81-8d52-9acc6d99a7c1	max_daily_deposit_total	Total deposit amount allowed per day per user	t	{"amount": 10000000}	2026-07-31 00:53:40.889019	2026-07-31 00:53:40.889019
8794363a-7960-4a43-934b-9e20534d6465	max_loan_amount	Maximum principal amount for any loan	t	{"amount": 5000000}	2026-07-31 00:53:40.890704	2026-07-31 00:53:40.890704
31b84850-ba1d-4d40-a382-0cd2a52126cc	min_loan_amount	Minimum principal amount for any loan	t	{"amount": 10000}	2026-07-31 00:53:40.893979	2026-07-31 00:53:40.893979
22e54b33-4f24-415f-8d3c-bcc1da63a6dd	max_loan_duration_months	Maximum repayment duration in months for a loan	t	{"months": 12}	2026-07-31 00:53:40.895888	2026-07-31 00:53:40.895888
ea46bb79-8c85-4d7b-9d80-011c27cee794	min_savings_for_loan	Minimum savings balance required before user can apply for a loan	t	{"amount": 50000}	2026-07-31 00:53:40.897649	2026-07-31 00:53:40.897649
6df0a238-79b3-4d4c-9ce8-08ac9b101568	loan_interest_rate	Default annual interest rate percentage for loans	t	{"rate": 5}	2026-07-31 00:53:40.899489	2026-07-31 00:53:40.899489
2a886a72-4ba5-4147-b08e-4e84fa592583	max_payment_amount	Maximum amount for a single payment transaction	t	{"amount": 10000000}	2026-07-31 00:53:40.901092	2026-07-31 00:53:40.901092
5b1343ab-8e99-44b3-add5-2d1c4e6fb0cc	max_subscription_amount	Maximum total amount for a BNPL subscription order	t	{"amount": 10000000}	2026-07-31 00:53:40.902671	2026-07-31 00:53:40.902671
1add23fe-98e4-46a9-935e-66cd728235f1	min_deposit_amount	Minimum amount allowed per deposit to savings	t	{"amount": 100}	2026-07-31 00:53:40.904031	2026-07-31 00:53:40.904031
5d78d9ad-21ee-4ddf-9f88-c9c473355eac	max_daily_loan_applications	Maximum number of loan applications allowed per day per user	t	{"count": 3}	2026-07-31 00:53:40.905379	2026-07-31 00:53:40.905379
\.


--
-- Data for Name: global_security_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.global_security_config (id, key, value, description, value_type, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: in_app_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.in_app_notifications (id, user_id, title, message, type, is_read, link, created_at) FROM stdin;
3ce0d252-199e-457c-a931-b0646eb6552f	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	KYC Verification Approved	Your identity has been verified successfully.	success	f	/individual/kyc	2026-07-31 13:58:26.589566
\.


--
-- Data for Name: incidents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incidents (id, title, description, severity, status, source, tenant_id, affected_systems, metrics, resolution_steps, assigned_to, reported_by, resolved_by, detected_at, resolved_at, root_cause, action_items, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: investment_corporate_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investment_corporate_actions (id, product_id, type, description, ratio_numerator, ratio_denominator, effective_date, status, execution_result, approved_by, approved_at, executed_by, executed_at, created_by, created_at, updated_at) FROM stdin;
70c1c24c-f764-4943-81d4-6a135723156b	7a7a4e2d-1fc4-4ad9-9036-895961b81829	bonus	1-for-10 bonus share issue to reward existing members	1.0000	10.0000	2026-03-15	executed	{"distributedUnits": 10000}	00000000-0000-0000-0000-000000000001	2026-03-10 10:00:00	00000000-0000-0000-0000-000000000001	2026-03-15 10:00:00	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.182096	2026-07-31 10:51:08.182096
07c108b2-6828-4148-b9ce-73bd65b711a8	9ed89d03-0586-496f-b869-4534cc80ef08	bonus	1-for-25 bonus units	1.0000	25.0000	2026-06-15	executed	{"distributedUnits": 2000}	00000000-0000-0000-0000-000000000001	2026-06-10 10:00:00	00000000-0000-0000-0000-000000000001	2026-06-15 10:00:00	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.690759	2026-07-31 11:15:55.690759
27fff886-c364-4c6b-81c6-8519baa81160	7a7a4e2d-1fc4-4ad9-9036-895961b81829	split	2-for-1 share split (pending)	2.0000	1.0000	2026-08-15	pending	\N	\N	\N	\N	\N	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.71833	2026-07-31 11:15:55.71833
\.


--
-- Data for Name: investment_eligibility_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investment_eligibility_rules (id, product_id, kyc_required_level, require_membership, allowed_geographies, accreditation_required, investor_whitelist, investor_blacklist, created_at, updated_at) FROM stdin;
39237e34-58c9-4271-8d81-e4552f6848a0	7a7a4e2d-1fc4-4ad9-9036-895961b81829	basic	t	["NG"]	f	\N	\N	2026-07-31 10:51:08.120463	2026-07-31 10:51:08.120463
e01b4a92-5453-4fbd-b109-15d8fe2ea0c9	b4d49db3-bd7d-48db-81f1-e75f6ae50654	basic	t	["NG"]	f	\N	\N	2026-07-31 10:51:08.137093	2026-07-31 10:51:08.137093
317155d5-d9cc-4b4c-a43f-090bd45d9778	9ed89d03-0586-496f-b869-4534cc80ef08	advanced	f	["NG"]	t	\N	\N	2026-07-31 10:51:08.151052	2026-07-31 10:51:08.151052
85ea3451-f015-498f-b9df-641d3b05ade3	98b4c240-a5c1-4e02-b12e-2dab18837efb	advanced	t	["NG"]	f	[]	[]	2026-07-31 10:51:08.162515	2026-07-31 11:18:07.519791
\.


--
-- Data for Name: investment_holdings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investment_holdings (id, user_id, product_id, order_id, units, cost_basis, current_value, locked_until, maturity_date, is_locked, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: investment_nav_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investment_nav_snapshots (id, product_id, nav, unit_price, snapshot_date, created_by, created_at) FROM stdin;
83d10aaa-edbd-4a3d-9644-f5e15220678f	7a7a4e2d-1fc4-4ad9-9036-895961b81829	1040.50	1040.50	2026-06-30	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.176
2fed5409-2436-431b-b08e-1b1ed7bb32c6	7a7a4e2d-1fc4-4ad9-9036-895961b81829	1020.75	1020.75	2026-06-23	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.179139
760679ed-d1c5-4578-a5bf-5a0b424788f3	7a7a4e2d-1fc4-4ad9-9036-895961b81829	1000.00	1000.00	2026-06-16	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.180702
d34fd901-f504-4929-b78b-a1dd1590adff	b4d49db3-bd7d-48db-81f1-e75f6ae50654	100.00	100.00	2026-07-30	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.65346
06111464-9164-43e3-969d-e02144c21d52	b4d49db3-bd7d-48db-81f1-e75f6ae50654	100.00	100.00	2026-07-23	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.65674
67f19796-28ac-46f6-8657-e36ec7ab3aa3	b4d49db3-bd7d-48db-81f1-e75f6ae50654	100.00	100.00	2026-07-16	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.659949
4374a02a-d5a7-4820-bde8-71c5971b2791	9ed89d03-0586-496f-b869-4534cc80ef08	512.40	512.40	2026-07-30	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.674061
d013caf3-5185-442a-9045-615a32f962ec	9ed89d03-0586-496f-b869-4534cc80ef08	506.15	506.15	2026-07-15	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.677057
cfa94904-d5a4-42c5-a7f3-fdee78bde003	9ed89d03-0586-496f-b869-4534cc80ef08	500.00	500.00	2026-06-30	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.683678
6c69d2d8-4682-42b5-9b9d-5585122317eb	98b4c240-a5c1-4e02-b12e-2dab18837efb	252.50	252.50	2026-07-30	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.701762
e49bf7bf-16d2-4788-8826-b391ca798eb5	98b4c240-a5c1-4e02-b12e-2dab18837efb	251.20	251.20	2026-07-16	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.704423
a25683ff-5c55-4cde-a09b-947b37465849	98b4c240-a5c1-4e02-b12e-2dab18837efb	250.00	250.00	2026-06-30	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.706685
\.


--
-- Data for Name: investment_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investment_orders (id, user_id, product_id, amount, units, unit_price, fee, product_version, status, payment_reference, payment_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: investment_pricing_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investment_pricing_config (id, product_id, formula_type, min_unit_price, max_unit_price, nav_schedule, allow_corporate_actions, distribution_approval_required, accrual_method, created_at, updated_at) FROM stdin;
70da367c-c36e-4c30-b7bc-4aaaf0fef886	7a7a4e2d-1fc4-4ad9-9036-895961b81829	nav_based	950.00	1200.00	weekly	t	t	compound	2026-07-31 10:51:08.12694	2026-07-31 10:51:08.12694
e6dde7de-de99-4c1c-8d48-322d2f59454c	b4d49db3-bd7d-48db-81f1-e75f6ae50654	simple	\N	\N	\N	f	t	simple	2026-07-31 10:51:08.14276	2026-07-31 10:51:08.14276
5fbd05c3-1837-42a0-89db-a4e701685755	9ed89d03-0586-496f-b869-4534cc80ef08	nav_based	450.00	700.00	daily	t	t	compound	2026-07-31 10:51:08.15286	2026-07-31 10:51:08.15286
e6bc033d-2fd1-4715-a744-3afa9a75fd86	98b4c240-a5c1-4e02-b12e-2dab18837efb	simple	\N	\N	\N	f	f	simple	2026-07-31 10:51:08.164629	2026-07-31 10:51:08.164629
\.


--
-- Data for Name: investment_product_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investment_product_versions (id, product_id, version, snapshot, change_summary, changed_by, created_at) FROM stdin;
2b08b796-e4ab-4d7c-9069-90102bcfa893	7a7a4e2d-1fc4-4ad9-9036-895961b81829	1	{"name": "Coop Growth Shares", "type": "shares", "isOpen": true, "status": "active", "riskTier": "medium", "tenorDays": null, "unitPrice": 1000, "lockInDays": 90, "totalUnits": 100000, "description": "Long-term growth shares in the cooperative investment pool, targeting capital appreciation with quarterly profit distributions.", "availableUnits": 75000, "managementFeeRate": 1.5, "maximumInvestment": 10000000, "minimumInvestment": 50000, "expectedReturnRate": 8, "profitSharingRules": "80/20 profit share after management fees", "distributionFrequency": "quarterly"}	Initial creation	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.114195
56d26f3c-4751-4df0-96e4-b122bd45b9db	b4d49db3-bd7d-48db-81f1-e75f6ae50654	1	{"name": "Fixed Income Deposit", "type": "fixed_income", "isOpen": true, "status": "active", "riskTier": "low", "tenorDays": 365, "unitPrice": null, "lockInDays": 30, "totalUnits": null, "description": "Capital-protected fixed income product with monthly interest payouts at a guaranteed rate.", "availableUnits": null, "managementFeeRate": 0.75, "maximumInvestment": 50000000, "minimumInvestment": 100000, "expectedReturnRate": 5, "profitSharingRules": null, "distributionFrequency": "monthly"}	Initial creation	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.13494
75938b91-688e-4158-85e1-d274323953cb	9ed89d03-0586-496f-b869-4534cc80ef08	1	{"name": "Pooled Micro-Investment", "type": "pooled", "isOpen": true, "status": "active", "riskTier": "high", "tenorDays": 180, "unitPrice": 500, "lockInDays": 180, "totalUnits": 200000, "description": "Pooled fund investing in high-yield cooperative ventures. Suitable for investors seeking higher returns with higher risk.", "availableUnits": 150000, "managementFeeRate": 2, "maximumInvestment": 5000000, "minimumInvestment": 10000, "expectedReturnRate": 12, "profitSharingRules": "70/30 profit share after management fees", "distributionFrequency": "annually"}	Initial creation	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.148901
a1d756f7-5edb-44c8-93d9-64b27bc82e33	98b4c240-a5c1-4e02-b12e-2dab18837efb	1	{"name": "Youth Investment Plan", "type": "shares", "isOpen": true, "status": "active", "riskTier": "low", "tenorDays": null, "unitPrice": 250, "lockInDays": 30, "totalUnits": 500000, "description": "Low-barrier entry product for young cooperators to build a savings-and-investment habit early.", "availableUnits": 420000, "managementFeeRate": 0.5, "maximumInvestment": 500000, "minimumInvestment": 5000, "expectedReturnRate": 4, "profitSharingRules": "90/10 profit share after management fees", "distributionFrequency": "monthly"}	Initial creation	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.160225
\.


--
-- Data for Name: investment_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investment_products (id, name, description, type, "riskTier", minimum_investment, maximum_investment, total_capacity, current_capacity, per_investor_caps, unit_price, lock_in_days, tenor_days, management_fee_rate, expected_return_rate, profit_sharing_rules, "distributionFrequency", total_units, available_units, is_open, status, version, organization_id, created_by, created_at, updated_at) FROM stdin;
7a7a4e2d-1fc4-4ad9-9036-895961b81829	Coop Growth Shares	Long-term growth shares in the cooperative investment pool targeting capital appreciation with quarterly profit distributions. Members invest at a fixed unit price of ₦1,000 per unit and earn an expected annual return of 8% before a 1.5% management fee. Profits are shared 80/20 (80% to investors, 20% to the cooperative) after fees. A 90-day lock-in applies from purchase; shares redeemed before the lock-in ends incur an early-withdrawal penalty of 5% of principal plus forfeiture of any accrued but unpaid distributions. After lock-in, redemptions are processed at the current NAV.	shares	medium	50000.00	10000000.00	100000000.00	0.00	{"max": 10000000, "min": 50000}	1000.00	90	\N	1.50	8.00	80/20 profit share after management fees	quarterly	100000	75000	t	active	1	\N	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.093992	2026-07-31 11:05:43.581908
b4d49db3-bd7d-48db-81f1-e75f6ae50654	Fixed Income Deposit	Capital-protected fixed income deposit paying monthly interest at a guaranteed annual rate of 5% (0.75% annual management fee). Principal is guaranteed at maturity (365 days). Early withdrawal before maturity is penalised: within the first 30 days, no interest is paid and a 1% penalty on principal applies; after 30 days, interest is recalculated at 50% of the stated rate and a 2% penalty on principal applies. Minimum deposit ₦100,000; maximum ₦50,000,000 per investor.	fixed_income	low	100000.00	50000000.00	500000000.00	0.00	{"max": 50000000, "min": 100000}	\N	30	365	0.75	5.00	\N	monthly	\N	\N	t	active	1	\N	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.132542	2026-07-31 11:05:43.600087
9ed89d03-0586-496f-b869-4534cc80ef08	Pooled Micro-Investment	High-yield pooled fund investing across cooperative ventures such as asset financing, trade and working capital. Expected annual return of 12% with a 2% management fee and 70/30 profit share (70% to investors, 30% to the cooperative). Requires advanced KYC and accredited-investor status. Units are priced at ₦500 with daily NAV updates. A 180-day lock-in and tenor applies; redeeming before maturity incurs a 10% penalty on principal plus forfeiture of any accrued profit share.	pooled	high	10000.00	5000000.00	100000000.00	0.00	{"max": 5000000, "min": 10000}	500.00	180	180	2.00	12.00	70/30 profit share after management fees	annually	200000	150000	t	active	1	\N	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.14542	2026-07-31 11:05:43.605538
98b4c240-a5c1-4e02-b12e-2dab18837efb	Youth Investment Plan	Low-barrier entry product designed for young cooperators to build a savings-and-investment habit early. Minimum investment of just ₦5,000 with a 4% expected annual return, 0.5% management fee and monthly distributions on a 90/10 profit-share basis (90% to investors, 10% to the cooperative). No KYC level required. A short 30-day lock-in applies; early withdrawal within the lock-in period incurs a 3% penalty on principal.	shares	low	5000.00	500000.00	125000000.00	0.00	{"max": 1000000, "min": 50000}	250.00	30	\N	0.50	4.00	90/10 profit share after management fees	monthly	500000	420000	t	active	1	\N	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.156504	2026-07-31 11:19:54.411219
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_entries (id, description, entry_date, status, posted_by, created_at, posted_at) FROM stdin;
5a78efa9-0da9-44d1-a07f-97e37b9b9745	deposit	2026-07-31	posted	560fb107-91f5-4df9-aa38-714c5fc0cfb6	2026-07-31 12:58:30.020899	2026-07-31 12:58:30.019
3a9b2b7a-250b-4029-acc6-9ce39ae79591	Registration fee received from new member	2026-07-02	posted	560fb107-91f5-4df9-aa38-714c5fc0cfb6	2026-07-31 13:01:42.559343	2026-07-31 13:01:42.558
9d7e3f82-802a-4a86-bf03-733243e236a2	BNPL fee earned recognised for June disbursements	2026-07-03	posted	560fb107-91f5-4df9-aa38-714c5fc0cfb6	2026-07-31 13:01:42.611501	2026-07-31 13:01:42.611
a0189118-bdfc-4c81-a3c6-6eb57dd60d5c	Payment gateway fees for July settlements	2026-07-05	posted	560fb107-91f5-4df9-aa38-714c5fc0cfb6	2026-07-31 13:01:42.653354	2026-07-31 13:01:42.652
bb319831-2cb3-496e-9609-43b2439080ae	Member deposit received via Paystack settlement	2026-07-08	posted	560fb107-91f5-4df9-aa38-714c5fc0cfb6	2026-07-31 13:01:42.690087	2026-07-31 13:01:42.689
a1657ddc-a670-4e9b-83d7-4c5c27bb5d4f	Monthly salaries disbursed	2026-07-25	posted	560fb107-91f5-4df9-aa38-714c5fc0cfb6	2026-07-31 13:01:42.728131	2026-07-31 13:01:42.727
7a19702d-f804-44f2-9df1-1840b6f3fe12	Investment income credited to investment sweep account	2026-07-28	posted	560fb107-91f5-4df9-aa38-714c5fc0cfb6	2026-07-31 13:01:42.76677	2026-07-31 13:01:42.765
b86d7c7b-3177-45fb-9db2-02ee44e798b1	Accrued rent expense for July	2026-07-29	posted	560fb107-91f5-4df9-aa38-714c5fc0cfb6	2026-07-31 13:01:42.804453	2026-07-31 13:01:42.804
cd490b8f-2679-4ca1-9fa2-1914b32e31ce	Payout processing expense for merchant settlement	2026-07-30	posted	560fb107-91f5-4df9-aa38-714c5fc0cfb6	2026-07-31 13:01:42.84226	2026-07-31 13:01:42.842
9e6239c9-6e8b-4038-b957-efa23ccbe0db	Provision for expected credit losses	2026-07-31	posted	560fb107-91f5-4df9-aa38-714c5fc0cfb6	2026-07-31 13:01:42.885886	2026-07-31 13:01:42.885
574080fd-eab3-4d71-b3d9-bf5250a91692	Interest earned on BNPL principal recognised	2026-07-31	posted	560fb107-91f5-4df9-aa38-714c5fc0cfb6	2026-07-31 13:01:42.922154	2026-07-31 13:01:42.921
\.


--
-- Data for Name: journal_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_lines (id, journal_entry_id, account_id, debit, credit, organization_id, created_at) FROM stdin;
d92dc6f7-7cea-47fb-a16a-b2356430a25b	5a78efa9-0da9-44d1-a07f-97e37b9b9745	ca16d2c9-a58f-41c3-bb4a-d0e2dfb1ad4c	0.00	0.00	\N	2026-07-31 12:58:30.02686
43210604-2346-4eaf-af45-808df868589e	3a9b2b7a-250b-4029-acc6-9ce39ae79591	ca16d2c9-a58f-41c3-bb4a-d0e2dfb1ad4c	50000.00	0.00	\N	2026-07-31 13:01:42.562489
8a353f35-4c83-4c5d-a76c-00f85e35d04e	3a9b2b7a-250b-4029-acc6-9ce39ae79591	eafb37b3-c508-4931-8f02-3fbaa68968f3	0.00	50000.00	\N	2026-07-31 13:01:42.562489
31f12aa2-e72d-4dee-a582-53a976f07030	9d7e3f82-802a-4a86-bf03-733243e236a2	7a176c94-1003-4d61-a11a-e40d72882ad8	250000.00	0.00	\N	2026-07-31 13:01:42.613464
e0197091-5b8b-40db-91cf-31c2e8d595d7	9d7e3f82-802a-4a86-bf03-733243e236a2	8f7e3e29-fa3e-4760-acbd-716cbca21540	0.00	250000.00	\N	2026-07-31 13:01:42.613464
cd1ebc8a-f57d-4011-8ca5-00e8d04d1009	a0189118-bdfc-4c81-a3c6-6eb57dd60d5c	2b662494-3af9-4aac-b44e-473686e358d1	12500.00	0.00	\N	2026-07-31 13:01:42.655515
2b20b1e6-2de5-44db-9448-dcafb6337679	a0189118-bdfc-4c81-a3c6-6eb57dd60d5c	ca16d2c9-a58f-41c3-bb4a-d0e2dfb1ad4c	0.00	12500.00	\N	2026-07-31 13:01:42.655515
cd670808-0952-4250-9b0a-6ee8405ec985	bb319831-2cb3-496e-9609-43b2439080ae	15321ab9-18c7-4a22-bc3b-92b06aff90f8	750000.00	0.00	\N	2026-07-31 13:01:42.692068
8d8adc46-b5c2-4623-945b-8bef061a2315	bb319831-2cb3-496e-9609-43b2439080ae	6ae3e537-1b17-4376-8914-14547aa51c4b	0.00	750000.00	\N	2026-07-31 13:01:42.692068
826e5a2b-7ebd-4b92-a47c-7f89972f80e6	a1657ddc-a670-4e9b-83d7-4c5c27bb5d4f	a5f45e96-894d-47d8-b91f-192a4aa1b870	1200000.00	0.00	\N	2026-07-31 13:01:42.729829
ccfcee00-5596-4097-984c-36d899dc8f20	a1657ddc-a670-4e9b-83d7-4c5c27bb5d4f	ca16d2c9-a58f-41c3-bb4a-d0e2dfb1ad4c	0.00	1200000.00	\N	2026-07-31 13:01:42.729829
3a2140d1-33d5-447e-8793-8540be100914	7a19702d-f804-44f2-9df1-1840b6f3fe12	477bcce5-2a57-4949-8192-116ef049f624	85000.00	0.00	\N	2026-07-31 13:01:42.769613
efa3d63d-f2d4-4f32-b733-ad2286c2d269	7a19702d-f804-44f2-9df1-1840b6f3fe12	c6fadcef-4199-4690-b18e-b6bca25f9304	0.00	85000.00	\N	2026-07-31 13:01:42.769613
180fd2b7-99cb-405c-9325-75eeb08777e7	b86d7c7b-3177-45fb-9db2-02ee44e798b1	8c894d58-b937-44de-a430-61a87ff83741	400000.00	0.00	\N	2026-07-31 13:01:42.806027
96462b65-c0f2-447c-99e9-e7eaa1d603ad	b86d7c7b-3177-45fb-9db2-02ee44e798b1	9f455e85-bd9b-4be7-a9a3-5449a9f0a07c	0.00	400000.00	\N	2026-07-31 13:01:42.806027
f545698f-863a-4247-84ed-c6cd7fe039fa	cd490b8f-2679-4ca1-9fa2-1914b32e31ce	e80aa85a-ebf6-43f1-ab8c-6c3af33d8525	95000.00	0.00	\N	2026-07-31 13:01:42.844116
8997299c-b61d-40a8-8366-e53266f8d87d	cd490b8f-2679-4ca1-9fa2-1914b32e31ce	ca16d2c9-a58f-41c3-bb4a-d0e2dfb1ad4c	0.00	95000.00	\N	2026-07-31 13:01:42.844116
c182c355-7310-4a81-be46-c73930eac407	9e6239c9-6e8b-4038-b957-efa23ccbe0db	15c6507d-c461-4e6a-985d-65abc8f6f12d	180000.00	0.00	\N	2026-07-31 13:01:42.887823
c669bab9-b6af-4c61-93c7-d0e803212463	9e6239c9-6e8b-4038-b957-efa23ccbe0db	6ca8bbb9-5cfb-439a-8c69-e644c10c1997	0.00	180000.00	\N	2026-07-31 13:01:42.887823
21e0870e-3ceb-420c-9f9e-f4a63866604b	574080fd-eab3-4d71-b3d9-bf5250a91692	6ca8bbb9-5cfb-439a-8c69-e644c10c1997	62000.00	0.00	\N	2026-07-31 13:01:42.923847
544290fd-c273-4521-81ef-5a0a250a50dd	574080fd-eab3-4d71-b3d9-bf5250a91692	a096076b-6116-4c5d-8bad-a61ee829d606	0.00	62000.00	\N	2026-07-31 13:01:42.923847
\.


--
-- Data for Name: kyc_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kyc_submissions (id, user_id, provider, reference, status, provider_response, submitted_at, processed_at, created_at, updated_at, rejection_reason, "identityType") FROM stdin;
615883d0-af9f-47fd-acac-fbb5eb04679e	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	korapay	KYC-1785449176946-5w7io1	rejected	\N	2026-07-30 23:06:16.946	2026-07-30 23:13:56.493	2026-07-30 23:06:16.949153	2026-07-30 23:13:56.495519	\N	bvn
5a8e5179-fca8-44ee-ac9e-89cbbb675fa7	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	korapay	KYC-1785448991504-zyj5xl	rejected	\N	2026-07-30 23:03:11.504	2026-07-30 23:14:01.833	2026-07-30 23:03:11.508224	2026-07-30 23:14:01.83533	\N	bvn
9c4c764f-70e2-4903-b57e-cea16fda25b0	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	korapay	KYC-1784753892523-zgwfdy	approved	\N	2026-07-22 21:58:12.524	2026-07-31 13:58:26.572	2026-07-22 21:58:12.526242	2026-07-31 13:58:26.574755	\N	bvn
\.


--
-- Data for Name: loan_repayments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loan_repayments (id, loan_id, due_date, amount, paid_at, payment_reference, status, created_at) FROM stdin;
1f0d7777-0f62-4357-b5d1-83c80d31ddb1	c10585b5-f291-4b0b-bbbb-d99d3b77abb9	2026-08-22	35000.00	2026-07-22 23:15:18.693	\N	paid	2026-07-22 23:15:18.694484
81085d85-b8af-4928-9221-3c9a2e3da006	c10585b5-f291-4b0b-bbbb-d99d3b77abb9	2026-09-22	35000.00	\N	\N	pending	2026-07-22 23:15:18.694484
09bab5ef-2d99-42a8-a968-d0d7a6b97dde	c10585b5-f291-4b0b-bbbb-d99d3b77abb9	2026-10-22	35000.00	\N	\N	pending	2026-07-22 23:15:18.694484
ff68fc7c-314d-4fc6-8e1d-d9b7452fa0e5	c10585b5-f291-4b0b-bbbb-d99d3b77abb9	2026-11-22	35000.00	\N	\N	pending	2026-07-22 23:15:18.694484
c42b7ec8-3bbc-451b-b648-40480fd19eec	c10585b5-f291-4b0b-bbbb-d99d3b77abb9	2026-12-22	35000.00	\N	\N	pending	2026-07-22 23:15:18.694484
162179b1-4dd7-40e9-8082-852e9415e30a	c10585b5-f291-4b0b-bbbb-d99d3b77abb9	2027-01-22	35000.00	\N	\N	pending	2026-07-22 23:15:18.694484
ad9ca8f9-87bf-4052-a9cf-ef0ea4c3136f	4d510cfc-2984-41de-97c8-c91cbe25b3f2	2026-08-22	35000.00	2026-07-22 23:15:18.703	\N	paid	2026-07-22 23:15:18.704035
a7b485ab-fd80-48c3-89c7-28d54216fd0b	4d510cfc-2984-41de-97c8-c91cbe25b3f2	2026-09-22	35000.00	\N	\N	pending	2026-07-22 23:15:18.704035
ff6b3152-e4c2-4829-8483-434886da691f	4d510cfc-2984-41de-97c8-c91cbe25b3f2	2026-10-22	35000.00	\N	\N	pending	2026-07-22 23:15:18.704035
af4f75cd-bdf8-4b60-adeb-e5e805f2f46d	4d510cfc-2984-41de-97c8-c91cbe25b3f2	2026-11-22	35000.00	\N	\N	pending	2026-07-22 23:15:18.704035
76b37240-0e9a-462f-b9f4-489c04b6a095	4d510cfc-2984-41de-97c8-c91cbe25b3f2	2026-12-22	35000.00	\N	\N	pending	2026-07-22 23:15:18.704035
30bd780d-a648-4b4c-b57b-caceeebaaca9	4d510cfc-2984-41de-97c8-c91cbe25b3f2	2027-01-22	35000.00	\N	\N	pending	2026-07-22 23:15:18.704035
98c8e55c-1389-4529-80a1-ad6782720fc3	7f1051ee-8bcf-47a9-9586-1574eea67651	2026-10-23	101110.80	\N	\N	pending	2026-07-23 00:08:17.377153
54773a9a-a566-4d3f-94ac-cda6b87dda80	7f1051ee-8bcf-47a9-9586-1574eea67651	2026-08-23	101110.80	2026-07-23 12:46:29.847	\N	paid	2026-07-23 00:08:17.377153
25688990-d5b5-4686-93d1-ff90c4d8cc2f	7f1051ee-8bcf-47a9-9586-1574eea67651	2026-09-23	101110.80	2026-07-25 01:34:12.024	\N	paid	2026-07-23 00:08:17.377153
257b49d1-415c-4819-814c-95541a5fa13a	7067eb78-140c-4bde-8a7d-e80dac9aee83	2026-09-30	105000.00	\N	\N	pending	2026-07-30 21:50:43.507247
8298e215-ba9c-4921-8dc7-aee98b9bc93d	7067eb78-140c-4bde-8a7d-e80dac9aee83	2026-10-30	105000.00	\N	\N	pending	2026-07-30 21:50:43.507247
05aa4839-8ae0-4d53-aca4-2d0b955d32ff	7067eb78-140c-4bde-8a7d-e80dac9aee83	2026-08-30	105000.00	2026-08-02 14:46:20.269	\N	paid	2026-07-30 21:50:43.507247
\.


--
-- Data for Name: loans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loans (id, user_id, amount, interest_rate, duration, monthly_payment, total_repayment, amount_paid, purpose, status, created_at, updated_at, service_fee, service_fee_paid, service_fee_paid_at, service_fee_tx_id) FROM stdin;
c10585b5-f291-4b0b-bbbb-d99d3b77abb9	dc82e50e-c01f-44e4-aac3-a84af916c3da	200000.00	5.00	6	35000.00	210000.00	35000.00	Home improvement	active	2026-07-22 23:15:18.685131	2026-07-22 23:15:18.685131	0.00	f	\N	\N
4d510cfc-2984-41de-97c8-c91cbe25b3f2	8bd25825-c8f4-4673-a50f-d268ba49c156	200000.00	5.00	6	35000.00	210000.00	35000.00	Home improvement	active	2026-07-22 23:15:18.70279	2026-07-22 23:15:18.70279	0.00	f	\N	\N
7f1051ee-8bcf-47a9-9586-1574eea67651	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	300000.00	5.00	3	105000.00	315000.00	202221.60		active	2026-07-23 00:08:17.367451	2026-07-25 01:34:12.032191	0.00	f	\N	\N
7067eb78-140c-4bde-8a7d-e80dac9aee83	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	300000.00	5.00	3	105000.00	315000.00	105000.00	Business expansion	active	2026-07-30 21:50:43.503844	2026-08-02 14:46:20.282068	0.00	f	\N	\N
\.


--
-- Data for Name: login_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_history (id, user_id, ip_address, user_agent, device, location, success, reason, created_at) FROM stdin;
293da5fe-e54a-47f5-b3d5-37c943221637	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-25 00:32:54.802081
53b180e5-00d5-49b9-9b03-1c7e92aefc03	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-25 00:43:43.54762
dbd59b1d-3443-4b4d-b53e-0f2a9ab8785f	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-25 00:44:41.930574
28b6e5e5-62c1-456c-99c3-db5a8e79f68a	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-25 00:50:45.104063
cca917c8-9468-4cea-877e-678c373198e4	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-25 00:51:45.6024
d8be85ae-8b55-4f25-a78a-24ea15cf738b	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-25 00:59:18.411255
e4da7967-2688-4285-b385-a72050eda07e	unknown	::1	curl/8.7.1	\N	\N	f	Invalid credentials	2026-07-25 01:04:31.957052
733396de-4544-429e-92b4-922c62ff4e39	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-25 01:09:13.696961
026e7871-d5e8-4cd3-8817-a6e35c71a4d3	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-25 01:11:15.439629
ce10652b-b4b9-48bc-a3c7-74b6835d7cb7	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-25 01:17:15.515616
0a297331-518b-468b-9f61-646883e25807	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-25 01:20:37.969739
10d27090-7d18-427e-9d7b-27b0d185d6a6	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-25 01:26:06.389841
ab816ca6-2856-4fe2-ad8c-86f6729917f8	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-25 01:26:44.584699
7ae8f000-bc8e-4ceb-89b8-b6c09278bdba	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::ffff:127.0.0.1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	\N	\N	t	\N	2026-07-29 17:50:56.357878
2b8c2ca6-d356-4ffe-b583-327baaff3ac6	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36	\N	\N	t	\N	2026-07-29 18:07:47.515945
3a4ad3c0-3554-4e47-b497-75225373a99a	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 15:10:59.988396
615d784d-8578-45f6-adf1-fe0db7e5e9a6	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 16:12:13.769
b1097789-ec5e-4a65-a83b-96d0c3bd0b14	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 16:14:23.615273
0bd48b80-e2ab-463a-93f9-2878ba8e731e	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 16:48:48.7881
1133735e-43a2-4821-bea0-fb4c06d8ce42	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 17:15:51.311659
bf6ba270-8993-4b8d-b2e9-e6f407ad2933	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 17:29:46.282251
597a0aff-b001-4dfd-bce3-7ade524702bf	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 17:34:26.939124
9efe26e8-e174-46dd-917c-5be6f208d030	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 19:51:10.779147
9f4a1282-06dd-4b8c-bfb9-e97e64b64ea3	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 20:35:12.175768
d0a91575-ff96-4461-b10a-6b8150d90f7a	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 21:43:41.666872
39cd6389-225d-4973-a732-0c9a171ceef1	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 21:53:41.280049
a4de8347-3695-4ea0-8fee-5afdacfd201a	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 22:29:59.520578
6cf4957b-2305-4e51-b622-9ddfcb91c1dd	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 22:42:04.340894
31449195-e7cb-4bba-a324-4bc0fe8c9863	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 23:00:24.838999
3383a281-20da-4e12-bac9-3e03ff7d2df7	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 23:13:17.837837
11e3e3a4-4006-4396-a3f6-27819950fcbf	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 23:14:19.120908
804395cd-1fad-462b-b1d6-506d25a1841c	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 23:37:08.564961
8caa46b9-1778-455a-b1e8-2c5d28ad9589	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 23:52:37.740161
add5f54a-53d2-4491-aa96-39fe1b0670eb	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 23:13:38.28931
0b42fa8a-01ce-4744-85d6-9c3054e0cd66	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 22:52:51.350259
54d2b3bd-b639-4054-a659-43f5ba181afb	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:26:29.067376
88a1584f-63ad-4e21-b8c7-f8d04e8e0b1b	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 00:03:55.905323
c11d5656-ea6e-4a47-8f1b-9e0b59aa44ac	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 00:20:06.072167
f9a3dc79-d067-43e3-8601-55357d0d2551	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 00:34:26.08975
8eb4939d-7d31-4229-bddc-a52ad5f4f821	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 00:51:39.581973
cd28cedb-4a76-45d5-8947-42538934ee7d	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 10:37:59.520765
55dbbde1-8eae-400d-8880-6b45e1108485	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 10:53:41.745086
b29c3e99-18c5-4ef1-8346-ff4928e58955	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 10:53:59.892449
a818ad33-36ba-4fea-9cde-6f6174a0a7fb	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 10:54:39.106263
2e96b996-7d5c-42ae-8f78-a27c26e475d1	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 10:54:47.079222
6aefabe0-3a39-4f00-b785-a24cfbf352e6	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 10:54:55.401172
482827a9-9d2e-41d1-afa7-2b3e6c994125	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 11:06:17.07728
f70f185e-8c74-4135-9842-d2eda8f2dcfa	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 11:09:19.724924
7c7012cb-931a-4838-ae55-7b49e4505e80	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 11:16:03.381955
f7c2b648-a779-4782-9c57-7608d08e12ce	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 11:16:10.770465
3179367e-30f0-4c11-aa8c-82ea8d55eaa8	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 11:25:58.879055
335250f1-c1de-4190-9dfd-4b3e263868e3	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 11:26:27.111404
a599a13a-d060-4f1d-a658-bb6a4ec2072c	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 11:26:32.454868
90998d1d-22e4-4c99-ad10-89503019547e	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 11:26:38.466269
aebbc471-4f6e-4e6b-88fd-9ef9eca36131	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 11:46:21.00726
69113fcf-acf9-4c3a-ba59-36b6cc4738e1	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 11:46:43.207702
bcb79228-952f-4b4a-8757-1e040ae09ab6	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 12:05:49.37208
33649bf1-2772-4152-a852-fb27612f0d2b	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 12:28:49.185667
0eb2f162-3e57-4be6-b4b0-6318a347aeba	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 12:42:24.666629
b30a615f-70b5-4677-919f-d3af5c7912cb	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 13:32:05.023473
083f0198-3451-4ad7-9df0-cbd8e712eb58	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 19:26:03.797695
25d34f7f-5cd2-4fbf-885c-f07864fa475a	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:32:31.175677
6f5624a3-b63f-4734-b41f-a3d20743d5c6	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:34:18.095525
9222fa62-0a2d-4a58-916e-43b9285ba85a	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:35:11.941496
4beb7d10-d56b-4e2d-80c6-c841e353b6c3	27626449-01e5-4a80-aeaf-3243caf42466	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:35:33.825319
6fceb524-86fd-45da-867c-5d5766b5945a	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:35:44.652504
6bf1f9e1-12b3-4e9b-83e3-38f3af6fd9cf	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:36:15.823187
d16c3bee-61e1-470e-9ee3-dd09adeca3a6	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:36:45.053526
51d39773-0dc4-4283-8d89-dd2148fe5f32	0158c520-82d2-42ec-86b9-23165db8602e	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:36:46.290152
d79a528e-09b6-4e19-991d-f5abf7432851	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 19:42:38.981454
7ffec6fd-04ee-4500-8057-5f5fe72b17c0	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:50:46.143457
032238de-4be9-4965-96e6-782c8f6303ef	e04cbdc4-0926-4d69-90ae-4e91ea617ed5	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:51:09.625322
ca41bd66-50e0-42ee-bb2e-6cb989ac0355	e04cbdc4-0926-4d69-90ae-4e91ea617ed5	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:51:10.197837
6e4c1b8c-2f2b-46ed-89ec-8abc9e5a598f	e04cbdc4-0926-4d69-90ae-4e91ea617ed5	::1	curl/8.7.1	\N	\N	f	Invalid password	2026-08-01 19:51:10.42077
6fdc9cba-8670-4514-871c-230c45799c15	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:52:39.501507
12acb07c-7bf3-45b1-b0fb-a50fc9b8bc08	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:28:27.795639
16b1e2dd-c78b-4bcd-8a5c-a1341af6947d	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:30:13.033245
13fe7b35-16c8-4dce-b676-d20630dfbca9	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 12:38:24.956111
38408f9a-d580-40b1-95f0-41102f1d5d5b	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 12:54:32.889931
541e389c-230e-4bab-abb0-26f1f50dddf3	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 19:57:22.031354
9c92073f-3776-49eb-9d3e-ed1343957912	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 19:59:29.225062
690283e5-f440-4fa9-b80b-765a600252af	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 20:06:13.648969
db388965-7259-450d-8630-4d5baaad42a9	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 20:08:44.290027
c5e30e19-77ac-4cb7-ba20-9e66ac07261f	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 20:08:56.242561
fc0524f8-af13-4b78-9c90-63d516d64822	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 20:11:32.981346
7e66641f-c1f7-42df-979e-3cac3d4c9f3e	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 20:13:09.711984
efd1aa63-fe01-4324-9627-acfedc0d11c9	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 20:16:58.336699
41d7d50b-3e93-418a-9e80-d5686d27be42	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 20:21:27.740855
8cea7656-8ee3-4e6c-8b98-dc117493bfb9	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 20:21:33.30392
d9fac498-fe8e-4aca-9cc5-6639059cc78a	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 20:21:42.456723
2f7099b1-3b44-4760-a112-e32520f6477b	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 20:27:13.374216
94a4e1df-cf47-4bb5-8bc9-db3c19c71b84	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 20:27:41.292052
bbf6a7e1-8b9b-4193-a30f-fc657afeda05	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 20:27:48.413019
3730771f-234d-4e00-83c7-e0a4e1b7275e	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 20:28:13.179171
7849f7e3-d95c-4427-aeea-1c350820dc25	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 20:44:59.478499
9545e84e-5256-4981-9f63-a6760a9a5d6c	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 20:48:34.458041
1cab47d0-585b-4ce9-831e-6696f33a7edf	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 20:49:40.99049
ac7e9fb0-04c0-49e7-8e47-cc350e2ffa4b	unknown	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	f	Invalid credentials	2026-08-01 21:06:03.089688
d9addf5e-f6d1-4fe2-809c-2654182b9c36	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 21:06:16.310726
5562db41-4c81-49e3-a3ac-b5b9f1a665d7	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 21:07:40.739876
a58e0827-6501-43bc-886b-c27f29c7f141	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 21:08:16.187355
41315484-d4aa-44ea-844c-255691acd488	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 21:13:57.176494
8e06b7f4-bb36-424e-935f-11f38083b936	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 21:14:09.472926
4ed95c10-9d3d-4a24-9b1f-0c548040ae08	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 21:14:16.979972
afa053d1-c82c-41ad-a174-566ce58ee476	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 21:21:55.844163
749a80cc-eb46-43d9-8927-2b8daa236cdb	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 21:23:20.642694
de5b2c28-1ebd-45c8-ba5c-cc323570fed1	6ccb2ee7-4961-4316-b230-04598845ef6c	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 21:36:18.122098
2c589f98-ce34-41b2-a490-a8bd93b59e74	6ccb2ee7-4961-4316-b230-04598845ef6c	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 21:36:26.042937
bf6785db-c3c5-4be2-990b-2cb45dcf49cc	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 21:56:42.331806
297c0616-cc27-4cc7-8ad6-ba7c9c27b641	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 22:00:01.633015
1369bd52-dd70-4780-8074-68b37ba57285	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 22:05:57.504054
1a0695be-433e-431a-9da6-c14403ebc661	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 10:28:41.980212
a1750925-3da8-4339-8105-0cf348eae96d	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 10:32:33.560527
a46ddd01-a50c-44b1-b248-3988c0a6ab86	dd856b59-9087-464f-aaae-7aa764d00670	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 10:45:45.953633
5f16e40f-4d96-4b61-a391-36c6f67a7746	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 10:46:56.268738
f214b1c6-1e62-4e3c-b129-12f58990a49e	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 10:48:29.232702
e9860214-ed05-4f95-90a1-3d2705936106	unknown	::1	curl/8.7.1	\N	\N	f	Invalid credentials	2026-08-02 10:54:17.678933
732c336b-0c7c-4a4d-8c0c-a7eafdb757f7	unknown	::1	curl/8.7.1	\N	\N	f	Invalid credentials	2026-08-02 10:54:31.986234
6a1b7f4e-f7c8-4e6c-bfdf-1abe397f39ab	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 10:54:43.823724
bc732ddc-7847-47db-b08b-075b529b76d9	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 11:02:02.171024
b20870c9-4f67-4e37-8487-16913b267387	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 11:07:52.188354
d70b335b-3ab0-4e10-be0d-2f43f241c893	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 11:15:40.026527
7d19ae4f-0026-4ac0-a797-9d0592ce462b	dd856b59-9087-464f-aaae-7aa764d00670	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 11:20:20.311583
17c459c1-1a88-4de1-8eb6-5f609edcc83e	a990ffb2-bfb9-466c-943a-fb19be731cae	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 19:56:55.689603
00a0dc9a-e329-4a14-a72e-96d4390844ac	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 11:22:13.683739
bfa87e69-3015-4158-9c3d-778482024a12	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 19:55:34.939222
bd3a9608-1e81-44f1-abc2-7d645ec452d6	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 12:54:37.349881
13732768-e586-42f6-93a8-75d3145c9d10	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 12:54:41.901145
a9669fa0-60d0-47ad-bc8b-8dae36162bab	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 12:54:47.06267
cd4d6d75-f700-4670-9eef-9714ff11f2c1	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 12:54:52.344719
4b17180b-f3e5-4638-af34-acf0721e80f7	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 12:54:58.399704
de425ba5-0558-4a68-ba12-b6234829af5f	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 12:56:33.02496
b4b9f8b4-b81b-4a0d-8449-be65ccdbfc49	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 12:56:49.123892
9d15d1c2-5190-4104-90b2-49b618292016	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 12:57:52.457174
8efb5829-b178-4d4f-bb74-34efe81657c9	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 12:57:57.542561
1ebf5b27-5aaf-420f-941d-c76b76e394de	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 13:09:26.758136
c0602258-982a-4490-83c5-049fcf5d2f41	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:17:02.944376
afc3686e-a80c-41ea-a2b4-3d5f4693bdee	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:17:10.577681
91973f74-010b-44e9-a985-0fa7cc638133	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:17:26.289973
53f77d29-fc22-4904-af98-f2063f191338	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:17:34.12891
7a5c1a20-4931-4bd1-b906-bb9a04886035	aa38f00e-7fbd-4d31-890f-d63c6ef2b452	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:17:40.910405
e5a27b9b-3f0b-4e8e-9072-3f7fc7eecf68	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:18:13.42213
725e7a56-dd32-492a-b322-fc46ec421085	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:18:20.520546
bd39b7db-129b-48c2-a4d0-947d04529696	unknown	::1	curl/8.7.1	\N	\N	f	Invalid credentials	2026-08-02 13:26:13.095445
9580945c-b650-43a9-b639-516f428486d4	unknown	::1	curl/8.7.1	\N	\N	f	Invalid credentials	2026-08-02 13:26:13.191877
fcb4be9b-0a2a-48cd-865c-419b9821bd84	unknown	::1	curl/8.7.1	\N	\N	f	Invalid credentials	2026-08-02 13:26:13.296898
683e4f61-dd8e-46ea-b63c-e205bd697754	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:26:20.667138
16fb57d8-03de-4d0d-84b7-1d3e0fa90d6e	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 13:28:00.336096
d177aa80-939a-4d20-aedc-be3c422771b1	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	::1	curl/8.7.1	\N	\N	f	Invalid password	2026-08-02 13:28:40.799459
132a43d3-e17e-4309-9a7c-c01e2fe48e54	unknown	::1	curl/8.7.1	\N	\N	f	Invalid credentials	2026-08-02 13:28:41.051153
ffe77084-ab9d-46ef-89e2-d7eda68e1711	unknown	::1	curl/8.7.1	\N	\N	f	Invalid credentials	2026-08-02 13:28:41.111127
81a4eaec-f8ac-4515-b6d8-a9ebb973b906	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:30:21.871295
c56fc5b2-475d-490a-ad7c-49daf951cef6	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:42:24.093784
2265a58e-02b4-43ac-a5cd-e2f021f73b5a	43f422a2-64c4-488c-aeee-7827e6d714aa	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:42:46.165616
08154605-b24b-426c-98cc-4ba40b52ee93	fff19150-f8f4-4330-a063-63d1b0d82372	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 13:50:36.626367
3a94d47d-1ef2-4c62-8d5e-bf9c2b833a53	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 13:55:50.920541
b724a77a-4972-4b51-a3ad-e6b7f97f8028	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 19:25:21.370276
455494b6-f9a7-4c3b-b3a4-873d09356d0c	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 20:08:26.478182
164b79d8-2a92-4fc5-a989-dd7fcb143266	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-01 21:07:13.632691
61c93b3f-7985-4bcd-833b-e35e4c1ed942	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 12:44:06.006426
4b44dd67-d57e-4b93-9286-201ceb94bbe3	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 13:04:04.936488
24541a12-6eb0-4328-87d4-f649666bb101	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-30 22:59:20.918175
448a1c84-53d6-4079-a6ab-f9dbc8f487a6	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 11:40:10.04129
ad906443-75cf-4168-8ec7-4815b22058c3	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 11:55:15.583502
c516b9f4-0611-4002-b9ec-2b8146f56087	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 12:07:45.577233
678be065-98ce-498a-8599-d48291c1754b	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 12:11:22.143096
40280b46-d748-4399-b1c5-2ec7e2afddea	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 12:35:47.957207
5b2d858b-a581-493b-a9d8-4f7fbc692030	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 12:40:27.638396
75c82411-ea97-46ea-9e7b-64fa2b13b164	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 12:54:57.694884
615e77c9-cca9-4f34-bb70-8a5e5fca63c6	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 12:55:59.583738
10058790-843c-448b-91d0-072be842045d	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 13:01:34.891754
a2e153ee-4b29-496b-87b6-165de1930a16	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 13:25:57.288561
5b905e99-286e-4e02-8c7d-8ee2f6b6d1cc	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 13:26:05.242889
77c36d52-c40c-4ab5-ae25-268a4c531927	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	curl/8.7.1	\N	\N	t	\N	2026-07-31 13:34:57.341982
e3f8342a-e211-4034-9deb-3e3e893368ae	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 13:37:51.694506
6256db72-4c66-4340-a82a-eba4717c3444	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-07-31 13:53:31.472941
f1a13cea-5ff2-474f-b12d-ab47b0a86f81	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	::1	curl/8.7.1	\N	\N	t	\N	2026-08-01 19:51:19.392188
63949b7b-f7ea-4265-8d54-a741df0d4edf	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	curl/8.7.1	\N	\N	f	Invalid password	2026-08-02 14:00:38.774099
d40bd200-1812-4766-bfb7-3ac1f313406e	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 14:00:51.022288
a725e43d-8083-4d7e-ba01-52d23dfb9fd2	fff19150-f8f4-4330-a063-63d1b0d82372	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 14:00:52.071387
5ce840a4-97a8-4033-baba-2f0cb1f43c56	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 14:01:47.010852
bab35fb7-bee9-411c-87e2-2f93c52c5a68	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 14:28:12.702921
dcd9186a-81de-4820-bac9-5d9ea65dc036	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 14:43:29.843467
f720bcec-c299-4e65-b178-18f4016dd6ac	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 14:58:52.477545
f8c2a526-c907-43ea-abb6-b1ca98bdb785	fff19150-f8f4-4330-a063-63d1b0d82372	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 15:16:45.36661
1a831d65-2a63-4bc7-9686-54abeb65c8b8	fff19150-f8f4-4330-a063-63d1b0d82372	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 15:34:58.85211
da015d2a-7a74-49e0-a608-d4a1fbda772a	fff19150-f8f4-4330-a063-63d1b0d82372	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 15:36:24.539559
a784eb85-691b-469c-b99d-f5174f94a055	fff19150-f8f4-4330-a063-63d1b0d82372	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 15:39:45.088553
d9254405-40cc-4b0d-9539-b6c8a263f02a	fff19150-f8f4-4330-a063-63d1b0d82372	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 15:40:32.986337
0210669c-f48b-4433-a2c2-98951aaef2de	fff19150-f8f4-4330-a063-63d1b0d82372	::1	curl/8.7.1	\N	\N	t	\N	2026-08-02 15:41:33.52708
231d2ae5-57b3-4e37-a43f-40c9003a98ac	fff19150-f8f4-4330-a063-63d1b0d82372	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0 Safari/605.1.15	\N	\N	t	\N	2026-08-02 18:56:09.941046
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_templates (id, key, type, subject, body, variables, created_at, updated_at) FROM stdin;
0cf2b7d9-39d5-45dc-b8ea-3ade8918c6ec	welcome_email	email	Welcome to {{platform_name}}	Hi {{name}},\n\nWelcome to {{platform_name}}! Your account has been successfully created.\n\nYou can now:\n- Save and invest for your goals\n- Apply for BNPL financing\n- Track your portfolio and earnings\n\nGet started by visiting your dashboard:\n{{dashboard_url}}\n\nBest,\nThe {{platform_name}} Team	["name", "platform_name", "dashboard_url"]	2026-07-31 00:55:56.953988	2026-07-31 00:55:56.953988
db5c306f-b709-450b-b1dc-a8d82ecab3f1	kyc_approved	email	KYC Verification Approved	Hi {{name}},\n\nYour KYC verification has been approved. You now have full access to all platform features including withdrawals and loan applications.\n\nThank you for your cooperation.\n\nBest,\nThe {{platform_name}} Team	["name", "platform_name"]	2026-07-31 00:55:56.966731	2026-07-31 00:55:56.966731
4d7a7655-b444-4ac1-81fd-3f7ad1689b6e	kyc_rejected	email	KYC Verification Requires Attention	Hi {{name}},\n\nYour KYC verification was not approved.\n\nReason: {{reason}}\n\nPlease submit a new KYC application with the correct information.\n\nBest,\nThe {{platform_name}} Team	["name", "reason", "platform_name"]	2026-07-31 00:55:56.96905	2026-07-31 00:55:56.96905
5e94a380-1ecd-4d77-b822-555ea6ffe0db	deposit_confirmation	email	Deposit Confirmed - {{amount}}	Hi {{name}},\n\nYour deposit of {{amount}} has been confirmed.\n\nNew balance: {{balance}}\nDate: {{date}}\n\nThank you for saving with {{platform_name}}.\n\nBest,\nThe {{platform_name}} Team	["name", "amount", "balance", "date", "platform_name"]	2026-07-31 00:55:56.970896	2026-07-31 00:55:56.970896
011e3a67-422b-4559-a8b4-b45ae64278bd	withdrawal_confirmation	email	Withdrawal Processed - {{amount}}	Hi {{name}},\n\nYour withdrawal of {{amount}} has been processed successfully.\n\nNew balance: {{balance}}\nDate: {{date}}\n\nBest,\nThe {{platform_name}} Team	["name", "amount", "balance", "date", "platform_name"]	2026-07-31 00:55:56.972784	2026-07-31 00:55:56.972784
35a4db17-96a9-48c8-b49f-430533ff4468	loan_approved	email	Loan Approved - {{amount}}	Hi {{name}},\n\nCongratulations! Your loan application for {{amount}} has been approved.\n\nLoan Details:\n- Amount: {{amount}}\n- Duration: {{duration}} months\n- Monthly Payment: {{monthly_payment}}\n- Total Repayment: {{total_repayment}}\n\nFunds will be disbursed to your account shortly.\n\nBest,\nThe {{platform_name}} Team	["name", "amount", "duration", "monthly_payment", "total_repayment", "platform_name"]	2026-07-31 00:55:56.974613	2026-07-31 00:55:56.974613
44c9bbc5-6d6d-466b-a150-cdf459696d84	payment_due_reminder	email	Payment Due Reminder	Hi {{name}},\n\nThis is a reminder that your payment of {{amount}} is due on {{due_date}}.\n\nPlease ensure your account has sufficient funds to avoid late fees.\n\nBest,\nThe {{platform_name}} Team	["name", "amount", "due_date", "platform_name"]	2026-07-31 00:55:56.977207	2026-07-31 00:55:56.977207
fda9f1f4-9168-40d8-80b5-5209e4f536a7	payment_received	email	Payment Received - {{amount}}	Hi {{name}},\n\nYour payment of {{amount}} has been received successfully.\n\nReference: {{reference}}\nDate: {{date}}\n\nThank you for your prompt payment.\n\nBest,\nThe {{platform_name}} Team	["name", "amount", "reference", "date", "platform_name"]	2026-07-31 00:55:56.979817	2026-07-31 00:55:56.979817
f55ffbe7-9b24-4ae7-adc6-13320b817ca6	subscription_settled	email	BNPL Order Settled - {{item_name}}	Hi {{name}},\n\nCongratulations! Your BNPL order for {{item_name}} has been fully paid off.\n\nTotal paid: {{total_paid}}\nSettled on: {{date}}\n\nThank you for choosing {{platform_name}}.\n\nBest,\nThe {{platform_name}} Team	["name", "item_name", "total_paid", "date", "platform_name"]	2026-07-31 00:55:56.981744	2026-07-31 00:55:56.981744
ac42ec35-c12a-4fd5-b72e-45fa7b31be4f	password_reset	email	Reset Your Password	Hi {{name}},\n\nYou recently requested to reset your password. Click the link below to set a new password:\n\n{{reset_link}}\n\nThis link expires in 1 hour. If you did not request this, please ignore this email.\n\nBest,\nThe {{platform_name}} Team	["name", "reset_link", "platform_name"]	2026-07-31 00:55:56.983475	2026-07-31 00:55:56.983475
30096103-7f05-441f-abe7-83e7661ceffc	login_alert	email	New Login to Your Account	Hi {{name}},\n\nA new login was detected on your account.\n\nTime: {{time}}\nDevice: {{device}}\nLocation: {{location}}\n\nIf this was you, no action is needed. If not, please secure your account immediately.\n\nBest,\nThe {{platform_name}} Team	["name", "time", "device", "location", "platform_name"]	2026-07-31 00:55:56.984982	2026-07-31 00:55:56.984982
17c44b21-d243-4048-b8b6-1622b54687c6	investment_matured	email	Investment Matured - {{product_name}}	Hi {{name}},\n\nYour investment in {{product_name}} has matured.\n\nInvested Amount: {{invested_amount}}\nReturns: {{returns}}\nTotal Payout: {{total_payout}}\n\nFunds have been credited to your wallet.\n\nBest,\nThe {{platform_name}} Team	["name", "product_name", "invested_amount", "returns", "total_payout", "platform_name"]	2026-07-31 00:55:56.986361	2026-07-31 00:55:56.986361
7af83935-1f5f-4844-b738-7fd5d1314e3a	referral_bonus	email	Referral Bonus Earned!	Hi {{name}},\n\nGreat news! You earned a referral bonus of {{bonus_amount}} because {{referred_name}} just joined {{platform_name}}.\n\nKeep sharing your referral link to earn more:\n{{referral_link}}\n\nBest,\nThe {{platform_name}} Team	["name", "bonus_amount", "referred_name", "referral_link", "platform_name"]	2026-07-31 00:55:56.987733	2026-07-31 00:55:56.987733
ed6e5d59-5d86-4de9-bd39-5aacdb0a1083	welcome_sms	sms	\N	Welcome to {{platform_name}}, {{name}}! Your account is ready. Start saving and investing today.	["name", "platform_name"]	2026-07-31 00:55:56.989001	2026-07-31 00:55:56.989001
8830dd01-d45b-464e-bd6b-f6d249d7570d	deposit_sms	sms	\N	{{platform_name}}: Deposit of {{amount}} confirmed. New balance: {{balance}}.	["amount", "balance", "platform_name"]	2026-07-31 00:55:56.990435	2026-07-31 00:55:56.990435
8a0e8669-8848-44f0-be9f-b298b62c6b40	otp_sms	sms	\N	{{platform_name}}: Your OTP is {{otp}}. Valid for 5 minutes.	["otp", "platform_name"]	2026-07-31 00:55:56.99403	2026-07-31 00:55:56.99403
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organizations (id, name, code, apex_org_id, status, created_by, created_at, updated_at, address, contact_email, contact_phone, contact_person_name, contact_person_phone, contact_person_email, bank_name, account_name, account_number, sort_code, bank_code) FROM stdin;
301336e2-7728-4f40-a5f9-83755964c4df	Mainland Chapter	ORG003	b8ecfc27-24f1-4dd5-9668-9ba5b2d420ed	active	\N	2026-07-22 21:29:28.517452	2026-07-24 22:05:35.307904	7 Agege Motor Road, Mainland, Lagos	info@mainlandchapter.ng	+2348010000003	Chukwudi Okafor	+2348020000003	chukwudi@mainlandchapter.ng	\N	\N	\N	\N	\N
3a3cf4a8-bdc6-44c3-80d3-67ac29f7b682	Civil Service Credit Union	ORG004	94fa108c-1fc3-45b1-829c-0183e2a31eb6	active	\N	2026-07-22 21:29:28.521503	2026-07-24 22:05:35.309331	23 Abuja Federal Secretariat, Abuja	info@civilservicecu.ng	+2348010000004	Grace Okonkwo	+2348020000004	grace@civilservicecu.ng	\N	\N	\N	\N	\N
90256b85-476c-4d11-8774-287c2e4c4654	Startup Innovators Network	ORG005	63bc3543-39e3-4c1c-85b4-c3f2802099c5	active	\N	2026-07-22 21:29:28.529031	2026-07-24 22:05:35.311749	10 Yaba Tech Hub, Yaba, Lagos	hello@startupinnovators.ng	+2348010000005	Segun Adeyemi	+2348020000005	segun@startupinnovators.ng	\N	\N	\N	\N	\N
fbfdb1fb-f5dd-41cb-b740-3f32e275eb76	Remote Workers Guild	ORG006	63bc3543-39e3-4c1c-85b4-c3f2802099c5	active	\N	2026-07-22 21:29:28.531117	2026-07-24 22:05:35.31557	88 Banana Island Road, Ikoyi, Lagos	admin@remoteworkers.ng	+2348010000006	Ngozi Eze	+2348020000006	ngozi@remoteworkers.ng	\N	\N	\N	\N	\N
1c604058-5564-43c5-bf9b-46cdab31b9e9	Demo Organization	ORG001	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	active	\N	2026-07-22 19:32:13.396605	2026-08-01 21:14:17.027092	42 Awolowo Road, Ikoyi, Lagos	demo@org001.ng	+2348010000001	Tunde Bakare	+2348020000001	tunde@org001.ng	\N	\N	\N	\N	\N
9cc99602-80f1-4917-b42d-91c0511c6765	Lagos Island Primary	ORG002	b8ecfc27-24f1-4dd5-9668-9ba5b2d420ed	active	\N	2026-07-22 21:29:28.512438	2026-08-01 21:36:26.082148	15 Marina Street, Lagos Island, Lagos	info@lagosisland.ng	+2348010000002	Funke Adewale	+2348020000002	funke@lagosisland.ng	\N	\N	\N	\N	\N
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, user_id, subscription_id, amount, fee, provider, provider_reference, status, metadata, payout_status, payout_reference, created_at, updated_at) FROM stdin;
662be206-54f2-47ed-ad1c-10dc3db43e96	8bd25825-c8f4-4673-a50f-d268ba49c156	\N	5000.00	75.00	paystack	PAY-1784749866722-ji80bf	pending	{"purpose": "registration"}	pending	\N	2026-07-22 20:51:06.723914	2026-07-22 20:51:06.723914
90cf9f8a-3adf-4efd-a87a-a39fd8093586	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	\N	5000.00	75.00	paystack	PAY-1784809183747-b473af	success	{"fees": 0, "amount": 0, "status": "success", "channel": "card", "paid_at": "2026-07-23T12:19:43.924Z", "customer": {"email": ""}, "reference": "PAY-1784809183747-b473af"}	pending	\N	2026-07-23 13:19:43.751102	2026-07-23 13:19:43.92625
da21f301-ca86-497f-9068-cc744b5d1359	dc82e50e-c01f-44e4-aac3-a84af916c3da	f3a02d1b-e083-4cc1-9478-03fb2f28ff2a	220000.00	3300.00	paystack	PAY-DOWN-C-0001	success	\N	completed	POOL-DOWN-C-0001	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
0c3ef79f-e155-4d2e-a552-4227409c72a5	dd856b59-9087-464f-aaae-7aa764d00670	\N	5000.00	0.00	paystack	REG-ORG001-001	success	{"purpose": "registration"}	completed	POOL-REG-ORG001-001	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
bf978956-74c5-4bf3-b110-ad06c8472299	6ccb2ee7-4961-4316-b230-04598845ef6c	\N	5000.00	0.00	paystack	REG-ORG002-001	success	{"purpose": "registration"}	completed	POOL-REG-ORG002-001	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
f7e26163-d45d-4642-98db-9fbd87dac169	eb143f32-c121-43ff-a8f3-278fe9e3c452	\N	5000.00	0.00	paystack	REG-ORG003-001	success	{"purpose": "registration"}	completed	POOL-REG-ORG003-001	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
bb7b0f5d-3696-4afc-ae6d-15e7d40a6daf	f008c2ac-5ec5-40c9-a613-f47ddfa7fdc3	\N	5000.00	0.00	paystack	REG-ORG004-001	success	{"purpose": "registration"}	completed	POOL-REG-ORG004-001	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
0240ee01-1ba5-46cf-9036-5af30aabf406	dd4a3942-fde5-4b0f-ba17-5c95e50c3164	\N	5000.00	0.00	paystack	REG-ORG005-001	success	{"purpose": "registration"}	completed	POOL-REG-ORG005-001	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
38f09838-3be1-4f81-9979-75d5fa4a88d9	2b02ed70-c5f2-4632-9eea-5d6818a66aca	\N	5000.00	0.00	paystack	REG-ORG006-001	success	{"purpose": "registration"}	completed	POOL-REG-ORG006-001	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
003b6867-5a90-4599-b483-f5453e3e43b8	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	9da03ebd-3457-4193-b286-aec580053d43	68750.00	1031.25	paystack	PAY-INST-A-001	success	\N	completed	POOL-INST-A-001	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
e907b038-9813-4bb2-9345-3cdf9f4cd1f0	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	9da03ebd-3457-4193-b286-aec580053d43	68750.00	1031.25	paystack	PAY-INST-A-002	success	\N	completed	POOL-INST-A-002	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
f95f3f43-f4c3-4bf7-a936-6a1b352f6155	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	9da03ebd-3457-4193-b286-aec580053d43	68750.00	1031.25	paystack	PAY-INST-A-003	success	\N	completed	POOL-INST-A-003	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
fb825e06-53aa-40b3-b12e-6e8a76643359	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	9da03ebd-3457-4193-b286-aec580053d43	68750.00	1031.25	paystack	PAY-INST-A-004	success	\N	completed	POOL-INST-A-004	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
3e09535b-1d3c-4270-ac93-a57389ab98b3	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	9da03ebd-3457-4193-b286-aec580053d43	68750.00	1031.25	paystack	PAY-INST-A-005	success	\N	completed	POOL-INST-A-005	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
eb90c9a3-d863-4afa-b509-2a63ca6bbd27	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	9da03ebd-3457-4193-b286-aec580053d43	50000.00	750.00	paystack	PAY-INST-A-006	success	\N	completed	POOL-INST-A-006	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
5c506fce-a19f-4aff-aac6-2b2d58be6177	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	500387b9-1cc9-4955-bf28-0b9a88e81792	500000.00	7500.00	paystack	PAY-DOWN-B-0001	success	\N	completed	POOL-DOWN-B-0001	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
3e428cd3-37d7-40b5-8b30-bb7dc8848e1c	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	500387b9-1cc9-4955-bf28-0b9a88e81792	916666.67	13750.00	paystack	PAY-INST-B-001	success	\N	completed	POOL-INST-B-001	2026-07-31 13:24:12.278268	2026-07-31 13:24:12.278268
\.


--
-- Data for Name: policy_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_templates (id, name, description, template_type, version, status, rules, metadata, created_by, approved_by, approved_at, change_summary, superseded_by, parent_template_id, is_applicable_to_all_tenants, applicable_tenant_ids, created_at, updated_at) FROM stdin;
6752598f-ff9a-4c05-94c7-10233f5a89c7	Standard BNPL Product Approval Policy	Governs the creation, configuration and launch of BNPL products across all tenants. Any new product or material change to tenor, pricing or limits requires a reviewed template before going live.	bnpl_product	1	active	{"maxTenorDays": 365, "minTenorDays": 14, "maxLoanAmount": 500000, "refundsWithinDays": 7, "minDownPaymentRate": 0.05, "maxProductsPerTenant": 25, "changeWindowFreezeDays": 3, "productApprovalRequired": true}	{"effectiveDate": "2026-01-10", "regulatoryRef": "CBN-GLC-2026/07", "ownerDepartment": "Product Governance", "reviewCadenceMonths": 6}	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	2026-06-15 10:30:00	\N	\N	\N	t		2026-07-31 12:42:09.333054	2026-07-31 12:42:09.333054
161d7bb4-1a2b-41f2-b40e-21c40ed26bb0	BNPL Product Sunset & Delisting Policy	Defines the controlled deactivation of BNPL products, including customer notification windows, pending-order handling and re-activation criteria.	bnpl_product	1	draft	{"delistingNoticeDays": 30, "autoPauseOnRiskScore": 700, "pendingOrdersWindowDays": 7, "customerNotificationChannels": ["sms", "email", "in-app"], "reactivationRequiresApproval": true}	{"effectiveDate": null, "ownerDepartment": "Product Governance", "reviewCadenceMonths": 6}	00000000-0000-0000-0000-000000000001	\N	\N	\N	\N	\N	t		2026-07-31 12:42:09.34583	2026-07-31 12:42:09.34583
19850b25-a7f2-405c-8c58-de0e12940305	Supplement Lending Exposure Cap Policy	Legacy draft setting hard exposure caps for secondary/supplement lending. Rejected during review due to insufficient risk controls and missing board sign-off.	bnpl_product	1	rejected	{"supplementLoanCap": 150000, "maxConcurrentLoans": 2, "combinedUtilisationCap": 0.6}	{"effectiveDate": null, "ownerDepartment": "Risk"}	00000000-0000-0000-0000-000000000001	\N	\N	Rejected: insufficient risk controls and missing board sign-off.	\N	\N	t		2026-07-31 12:42:09.348213	2026-07-31 12:42:09.348213
87b3ad44-ca8d-4074-b74e-5e1ac8e5cfb8	Tier-2 Standard KYC Policy	Standard verification tier for mid-value onboarding, requiring government-issued photo ID, liveness check and physical address confirmation.	kyc_requirement	1	active	{"idTypes": ["NIN", "BVN", "PASSPORT", "DRIVERS_LICENSE"], "kycLevel": "standard", "livenessCheck": true, "addressVerification": true, "maxCumulativeBalance": 5000000, "reVerificationMonths": 24, "maxMonthlyTransactions": 50}	{"effectiveDate": "2026-02-15", "ownerDepartment": "Compliance", "reviewCadenceMonths": 12}	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	2026-06-15 10:30:00	\N	\N	\N	t		2026-07-31 12:42:09.362226	2026-07-31 12:42:09.362226
186a1c3c-a6b9-439d-b855-0876c9c3f931	Enhanced Due Diligence (EDD) Policy	Heightened scrutiny for high-value or flagged customers, defining the triggers and documentation required before elevated limits are granted.	kyc_requirement	1	active	{"kycLevel": "enhanced", "triggers": {"sanctionedFlag": true, "singleTransactionAbove": 5000000, "politicallyExposedPerson": true, "thirdPartyTransfersWithin30Days": 2}, "reVerificationMonths": 6, "requiredDocumentation": ["utility-bill", "bank-statement-6months", "proof-of-business"], "requiresComplianceOfficerApproval": true}	{"effectiveDate": "2026-03-01", "ownerDepartment": "Compliance", "reviewCadenceMonths": 6}	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	2026-06-15 10:30:00	\N	\N	\N	t		2026-07-31 12:42:09.365137	2026-07-31 12:42:09.365137
807b21d2-a4e9-4a9a-aadc-3fc46fccc735	Loan Disbursement Approval Policy	Defines approval thresholds and dual-control requirements for loan disbursements, ensuring larger advances receive commensurate review.	manager_action	1	active	{"maxApprovalTier": 1, "dualApprovalAbove": 1000000, "approvalRequiredAbove": 200000, "disbursementWindowHours": 24, "approverRotationRequired": true, "sameDayDisbursementBelow": 50000}	{"effectiveDate": "2026-01-20", "ownerDepartment": "Operations", "reviewCadenceMonths": 6}	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	2026-06-15 10:30:00	\N	\N	\N	t		2026-07-31 12:42:09.367767	2026-07-31 12:42:09.367767
cecc7126-84ee-4e9e-8e8a-779a54a328a8	Charge-Off & Write-Off Policy	Sets the aging thresholds and approval chain for charging off and writing off delinquent loans, including board-level sign-off requirements.	manager_action	1	pending_approval	{"writeOffAfterDays": 365, "chargeOffAfterDays": 120, "partialChargeOffRate": 0.3, "boardApprovalRequired": true, "recoveryTrackingAfterWriteOff": true, "quarterlyReconciliationRequired": true}	{"effectiveDate": null, "ownerDepartment": "Credit & Collections", "reviewCadenceMonths": 12}	00000000-0000-0000-0000-000000000001	\N	\N	\N	\N	\N	t		2026-07-31 12:42:09.370238	2026-07-31 12:42:09.370238
64b75660-14a6-4294-a086-4e8eb96118b3	Risk-Based Interest Rate Pricing Policy	Bounds the annual interest rates chargeable on BNPL facilities and ties the maximum allowed rate to the customer risk score band.	interest_rate	1	active	{"rateTiers": [{"maxAnnualRate": 0.24, "riskScoreAbove": 700}, {"maxAnnualRate": 0.3, "riskScoreAbove": 600}, {"maxAnnualRate": 0.36, "riskScoreAbove": 0}], "lateFeeRate": 0.05, "annualRateMax": 0.36, "annualRateMin": 0.05, "maxLateFeeCap": 20000, "riskBasedPricing": true, "rateChangeNoticeDays": 14}	{"effectiveDate": "2026-02-01", "ownerDepartment": "Pricing & Analytics", "reviewCadenceMonths": 6}	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	2026-06-15 10:30:00	\N	\N	\N	t		2026-07-31 12:42:09.372548	2026-07-31 12:42:09.372548
ac00740b-7505-4fa1-b100-99bfb41bb1fb	Promotional Rate Policy	Governs discounted promotional interest rates, limiting their duration, depth and customer eligibility to keep campaigns within budget.	interest_rate	1	active	{"promoRateMax": 0.05, "promoRateMin": 0, "budgetPerPromo": 5000000, "maxPromoDurationDays": 90, "appliesToNewCustomersOnly": true, "noStackingWithOtherPromos": true, "requiresMarketingApproval": true}	{"effectiveDate": "2026-04-01", "ownerDepartment": "Growth & Marketing", "reviewCadenceMonths": 6}	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	2026-06-15 10:30:00	\N	\N	\N	t		2026-07-31 12:42:09.379448	2026-07-31 12:42:09.379448
05f40f7d-0d50-4646-8915-cf65d8e8ba09	Default Rate & Penalty Interest Policy	Defines the premium applied once an account enters default and the maximum allowable penalty rate, including compounding behaviour.	interest_rate	1	active	{"maxDefaultRate": 0.6, "defaultRatePremium": 0.1, "compoundingInterval": "monthly", "penaltyAppliesAfterDays": 30, "penaltyCapAsMultipleOfPrincipal": 1.5}	{"effectiveDate": "2026-01-15", "ownerDepartment": "Credit & Collections", "reviewCadenceMonths": 12}	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	2026-06-15 10:30:00	\N	\N	\N	t		2026-07-31 12:42:09.381388	2026-07-31 12:42:09.381388
ff5af5a8-063d-4405-8c0c-a102ffe8566e	Tier-1 Basic KYC Policy	Baseline identity verification for low-value onboarding. Establishes the minimum identity documents and transaction limits for basic accounts.	kyc_requirement	1	superseded	{"idTypes": ["BVN"], "kycLevel": "basic", "livenessCheck": false, "addressVerification": false, "maxCumulativeBalance": 500000, "maxSingleTransaction": 50000, "maxMonthlyTransactions": 10}	{"effectiveDate": "2025-09-01", "ownerDepartment": "Compliance", "reviewCadenceMonths": 12}	00000000-0000-0000-0000-000000000001	\N	\N	\N	6a8e1984-2574-4a7c-af37-cf5007820746	\N	t		2026-07-31 12:42:09.350459	2026-07-31 12:42:09.39743
79146310-4d48-4015-962f-d211b5e43b60	First-Party Collection Policy	Sets the outreach cadence, channels and escalation timeline for recovering overdue balances in-house before any external action.	collection	1	active	{"fieldVisitDay": 45, "allowedChannels": ["sms", "email", "phone", "in-app"], "collectionHours": {"end": "20:00", "start": "08:00"}, "contactAttempts": {"sms": 5, "email": 3, "phone": 7}, "firstContactDay": 1, "earlyReminderDay": 5, "forbearanceAllowedAfter": 60}	{"effectiveDate": "2026-03-10", "ownerDepartment": "Collections", "reviewCadenceMonths": 6}	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	2026-06-15 10:30:00	\N	\N	\N	t		2026-07-31 12:42:09.383304	2026-07-31 12:42:09.383304
6a8e1984-2574-4a7c-af37-cf5007820746	Tier-1 Basic KYC Policy (v2)	Updated Tier-1 baseline requiring NIN alongside BVN and adding liveness verification, reflecting the enhanced verification framework rolled out this year.	kyc_requirement	2	active	{"idTypes": ["BVN", "NIN"], "kycLevel": "basic", "livenessCheck": true, "addressVerification": false, "maxCumulativeBalance": 1000000, "maxSingleTransaction": 100000, "maxMonthlyTransactions": 20}	{"effectiveDate": "2026-05-01", "ownerDepartment": "Compliance", "reviewCadenceMonths": 12}	00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	2026-06-15 10:30:00	Added NIN as a mandatory ID type and enabled liveness verification.	\N	ff5af5a8-063d-4405-8c0c-a102ffe8566e	t		2026-07-31 12:42:09.352567	2026-07-31 12:42:09.393458
7017e7ba-c2fd-404d-9b70-4b694a34f964	Collections Outsourcing Policy	Authorises and constrains the use of licensed third-party collection agencies for aged debt, including data-sharing and escalation rules.	collection	1	active	{"agencyFeeCap": 0.1, "dataShareMasked": true, "requiresLicensedAgency": true, "complaintEscalationDays": 5, "outsourcingThresholdDays": 90, "annualAgencyAuditRequired": true}	{"effectiveDate": null, "ownerDepartment": "Collections", "reviewCadenceMonths": 12}	00000000-0000-0000-0000-000000000001	fff19150-f8f4-4330-a063-63d1b0d82372	2026-08-02 15:45:22.197	\N	\N	\N	t		2026-07-31 12:42:09.385995	2026-08-02 15:45:22.199938
\.


--
-- Data for Name: reconciliation_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reconciliation_results (id, run_id, subscription_id, installment_id, expected_amount, actual_amount, discrepancy, expected_date, actual_date, status, notes, flags, organization_id, created_at) FROM stdin;
2f10c1c9-f0b0-4087-a546-c35360856122	308f109c-6a68-418e-ba38-35001b0ab0a0	9da03ebd-3457-4193-b286-aec580053d43	ec46b54e-afd5-4257-bfaa-97b57421ba02	68750.00	68750.00	0.00	2026-07-29	2026-07-29	matched	\N		1c604058-5564-43c5-bf9b-46cdab31b9e9	2026-07-31 13:24:12.309902
c61e6185-cc6f-4dbc-9a5b-c226ba4c7e56	308f109c-6a68-418e-ba38-35001b0ab0a0	9da03ebd-3457-4193-b286-aec580053d43	ce0cb12c-6835-4ad6-86c6-dff58b0f6f77	68750.00	68750.00	0.00	2026-07-31	2026-07-31	matched	\N		1c604058-5564-43c5-bf9b-46cdab31b9e9	2026-07-31 13:24:12.309902
ba2635f3-46e3-43a6-aa36-085256ad1e56	308f109c-6a68-418e-ba38-35001b0ab0a0	9da03ebd-3457-4193-b286-aec580053d43	b5c93435-7214-4bec-91e6-b73550d1f2b0	68750.00	68750.00	0.00	2026-08-02	2026-08-02	matched	\N		1c604058-5564-43c5-bf9b-46cdab31b9e9	2026-07-31 13:24:12.309902
b9aa5da7-d594-47bb-9c66-cac3f901602e	308f109c-6a68-418e-ba38-35001b0ab0a0	9da03ebd-3457-4193-b286-aec580053d43	55d85fd4-3e39-4500-b290-cc4215af1184	68750.00	68750.00	0.00	2026-08-04	2026-08-04	matched	\N		1c604058-5564-43c5-bf9b-46cdab31b9e9	2026-07-31 13:24:12.309902
956af9ce-4925-4773-8898-003538f48c5f	308f109c-6a68-418e-ba38-35001b0ab0a0	9da03ebd-3457-4193-b286-aec580053d43	baa83726-6193-4d41-b4cf-42191e3d40ef	68750.00	50000.00	18750.00	2026-08-06	2026-08-06	needs_review	\N	amount_mismatch	1c604058-5564-43c5-bf9b-46cdab31b9e9	2026-07-31 13:24:12.309902
1383b17e-badb-4a44-bca5-c691fb2d0ec5	308f109c-6a68-418e-ba38-35001b0ab0a0	9da03ebd-3457-4193-b286-aec580053d43	814075b9-4933-41ab-bb0c-7bb30dc5c7e0	70125.00	0.00	70125.00	2026-07-28	\N	unmatched	\N	missing_payment	1c604058-5564-43c5-bf9b-46cdab31b9e9	2026-07-31 13:24:12.309902
d69f50a4-8a97-4872-81ab-628214f4e29d	308f109c-6a68-418e-ba38-35001b0ab0a0	9da03ebd-3457-4193-b286-aec580053d43	0065365c-0c4a-4891-827b-dff1e4fa2891	70125.00	0.00	70125.00	2026-07-30	\N	unmatched	\N	missing_payment	1c604058-5564-43c5-bf9b-46cdab31b9e9	2026-07-31 13:24:12.309902
9b5adc6d-14f1-4deb-a334-c9c3d08dc0c3	308f109c-6a68-418e-ba38-35001b0ab0a0	9da03ebd-3457-4193-b286-aec580053d43	b0d51976-eb23-446b-a096-c84786ee004f	68750.00	68750.00	0.00	2026-07-27	2026-07-27	matched	spot check		1c604058-5564-43c5-bf9b-46cdab31b9e9	2026-07-31 13:24:12.309902
\.


--
-- Data for Name: reconciliation_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reconciliation_runs (id, range_start, range_end, status, total_expected, total_actual, match_count, mismatch_count, expected_amount, actual_amount, discrepancy, organization_id, run_by, completed_at, created_at, updated_at) FROM stdin;
308f109c-6a68-418e-ba38-35001b0ab0a0	2026-07-27	2026-08-06	completed	8	8	5	3	550000.00	393750.00	156250.00	1c604058-5564-43c5-bf9b-46cdab31b9e9	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	2026-07-31 13:24:12.304	2026-07-31 13:24:12.305007	2026-07-31 13:24:12.305007
\.


--
-- Data for Name: redemption_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.redemption_requests (id, user_id, holding_id, units, amount, status, reason, rejection_reason, processed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: referrals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.referrals (id, referrer_id, referee_id, referee_email, referral_code, status, reward_amount, reward_paid, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: saved_payment_methods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_payment_methods (id, user_id, type, provider, provider_token, last4, card_brand, expiry_month, expiry_year, bank_name, account_number, account_name, is_default, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: savings_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.savings_accounts (id, user_id, balance, target_amount, status, created_at, updated_at, goal_balance) FROM stdin;
31945a72-12d1-4b83-964e-19685dac8ea7	dc82e50e-c01f-44e4-aac3-a84af916c3da	95000.00	\N	active	2026-07-22 22:56:42.448048	2026-07-22 22:56:42.474571	0.00
4583fb67-a8e9-4f55-9f5f-8105b996753d	8bd25825-c8f4-4673-a50f-d268ba49c156	95000.00	\N	active	2026-07-22 22:56:42.482272	2026-07-22 22:56:42.489284	0.00
6aa18c1f-4c0b-49dd-abaf-3079f71c07e2	4e84964f-4cb3-4bc3-9d37-fb081ae2be51	95000.00	\N	active	2026-07-22 22:56:42.498172	2026-07-22 22:56:42.504404	0.00
7bbc104e-e7a5-4fe4-a4ef-e60e99da1ae9	6c534230-4307-4216-99e3-6852b9d78780	95000.00	\N	active	2026-07-22 22:56:42.505246	2026-07-22 22:56:42.512903	0.00
07436bdd-81ba-4cb3-b727-f3a57db692e6	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	14450.00	50000000.00	active	2026-07-22 22:56:42.490151	2026-07-25 01:33:33.075084	49700.00
2bf4b2c3-d979-4507-9cce-6393866998d0	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	95000.00	\N	active	2026-07-30 17:15:51.456149	2026-07-30 21:50:43.496805	0.00
1db51525-e1a5-4f69-a77e-9ad93f883f50	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	114000.00	\N	active	2026-07-30 21:50:43.436994	2026-08-02 11:23:45.194964	0.00
\.


--
-- Data for Name: savings_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.savings_transactions (id, account_id, type, amount, balance_before, balance_after, description, created_at) FROM stdin;
24b561e1-7479-4a72-899c-6d4fb4c22950	31945a72-12d1-4b83-964e-19685dac8ea7	deposit	50000.00	0.00	50000.00	Initial savings deposit	2026-07-22 22:56:42.465353
15a93479-b4d1-4977-800a-abb282ce56d5	31945a72-12d1-4b83-964e-19685dac8ea7	deposit	25000.00	50000.00	75000.00	Monthly savings contribution	2026-07-22 22:56:42.467465
bb5a1781-6700-4c6b-a8fe-6033991dbfeb	31945a72-12d1-4b83-964e-19685dac8ea7	deposit	30000.00	75000.00	105000.00	Bonus savings deposit	2026-07-22 22:56:42.468624
957ad20c-bfa0-4352-a840-370763c26dff	31945a72-12d1-4b83-964e-19685dac8ea7	withdrawal	10000.00	105000.00	95000.00	ATM withdrawal	2026-07-22 22:56:42.472928
e74c90eb-e44c-4c02-aa7b-1fa33a0cfe47	4583fb67-a8e9-4f55-9f5f-8105b996753d	deposit	50000.00	0.00	50000.00	Initial savings deposit	2026-07-22 22:56:42.483941
1c9ef142-f546-42b6-b5c2-34b348129da4	4583fb67-a8e9-4f55-9f5f-8105b996753d	deposit	25000.00	50000.00	75000.00	Monthly savings contribution	2026-07-22 22:56:42.484962
7d20c026-4c10-4992-a5c0-71ef8e6d7cb3	4583fb67-a8e9-4f55-9f5f-8105b996753d	deposit	30000.00	75000.00	105000.00	Bonus savings deposit	2026-07-22 22:56:42.486194
4962e124-7907-40a6-9a9b-bf28eff687ee	4583fb67-a8e9-4f55-9f5f-8105b996753d	withdrawal	10000.00	105000.00	95000.00	ATM withdrawal	2026-07-22 22:56:42.488063
29a11f04-8534-4ecf-b0c6-fe5d26cad48d	07436bdd-81ba-4cb3-b727-f3a57db692e6	deposit	50000.00	0.00	50000.00	Initial savings deposit	2026-07-22 22:56:42.491401
bdc890b4-20e9-40a1-90ff-0422d9405d7e	07436bdd-81ba-4cb3-b727-f3a57db692e6	deposit	25000.00	50000.00	75000.00	Monthly savings contribution	2026-07-22 22:56:42.492246
f5eea616-e1de-4c13-a6f9-080d7afa80f7	07436bdd-81ba-4cb3-b727-f3a57db692e6	deposit	30000.00	75000.00	105000.00	Bonus savings deposit	2026-07-22 22:56:42.494026
e96468f5-814a-4264-806f-5226c866e1b3	07436bdd-81ba-4cb3-b727-f3a57db692e6	withdrawal	10000.00	105000.00	95000.00	ATM withdrawal	2026-07-22 22:56:42.495987
2a23102b-b72c-40a1-ad4c-40f06b575386	6aa18c1f-4c0b-49dd-abaf-3079f71c07e2	deposit	50000.00	0.00	50000.00	Initial savings deposit	2026-07-22 22:56:42.49953
9b09777f-47dd-4bc7-8189-a9551480d683	6aa18c1f-4c0b-49dd-abaf-3079f71c07e2	deposit	25000.00	50000.00	75000.00	Monthly savings contribution	2026-07-22 22:56:42.500554
b58a4717-6b8b-4e1b-82b6-5cfaf5205b39	6aa18c1f-4c0b-49dd-abaf-3079f71c07e2	deposit	30000.00	75000.00	105000.00	Bonus savings deposit	2026-07-22 22:56:42.501597
ee5e99ad-9f9a-4506-b664-a613758e5f44	6aa18c1f-4c0b-49dd-abaf-3079f71c07e2	withdrawal	10000.00	105000.00	95000.00	ATM withdrawal	2026-07-22 22:56:42.503411
5a9687be-92aa-4a0d-8b5f-1757c812e23a	7bbc104e-e7a5-4fe4-a4ef-e60e99da1ae9	deposit	50000.00	0.00	50000.00	Initial savings deposit	2026-07-22 22:56:42.506499
577c975c-4dac-48f3-8e79-6f0a278605ee	7bbc104e-e7a5-4fe4-a4ef-e60e99da1ae9	deposit	25000.00	50000.00	75000.00	Monthly savings contribution	2026-07-22 22:56:42.507535
ae2fff30-a059-4f5d-9cde-6580a5658d30	7bbc104e-e7a5-4fe4-a4ef-e60e99da1ae9	deposit	30000.00	75000.00	105000.00	Bonus savings deposit	2026-07-22 22:56:42.508618
835a2186-9ea8-4e1b-8569-b32a88f55d34	7bbc104e-e7a5-4fe4-a4ef-e60e99da1ae9	withdrawal	10000.00	105000.00	95000.00	ATM withdrawal	2026-07-22 22:56:42.511501
716b734d-14da-4703-a168-917e0087e888	07436bdd-81ba-4cb3-b727-f3a57db692e6	deposit	1111.00	95000.00	96111.00	Savings deposit	2026-07-22 23:48:39.020766
2769b565-ba02-4169-97ab-fd764095fdeb	07436bdd-81ba-4cb3-b727-f3a57db692e6	withdrawal	80000.00	96111.00	16111.00	Savings withdrawal	2026-07-23 12:21:34.676077
f3ec216a-7db4-4a00-9ce5-dfa2da975f98	07436bdd-81ba-4cb3-b727-f3a57db692e6	withdrawal	800.00	16111.00	15311.00	Savings withdrawal	2026-07-25 00:44:58.279917
bd05bdbf-c72a-4105-9f5d-8161dfb064ee	07436bdd-81ba-4cb3-b727-f3a57db692e6	withdrawal	200.00	15311.00	15111.00	Savings withdrawal	2026-07-25 00:49:29.944435
f128dcf2-b00e-4496-a319-35d3601d0f3e	07436bdd-81ba-4cb3-b727-f3a57db692e6	withdrawal	111.00	15111.00	15000.00	Savings withdrawal	2026-07-25 00:51:58.477822
17e820f6-1232-4aec-b49a-b1a67d380032	07436bdd-81ba-4cb3-b727-f3a57db692e6	withdrawal	400.00	15000.00	14600.00	Savings withdrawal	2026-07-25 01:09:28.514705
a5f56d24-0603-42f9-8728-3fb3cb9a5330	07436bdd-81ba-4cb3-b727-f3a57db692e6	withdrawal	100.00	14600.00	14500.00	Savings withdrawal	2026-07-25 01:20:58.653086
20c5d87e-8b3e-4328-94e2-4c8eed67dd23	07436bdd-81ba-4cb3-b727-f3a57db692e6	withdrawal	50.00	14500.00	14450.00	Savings withdrawal	2026-07-25 01:25:48.116577
a612c6c4-bb2e-4c2f-b3b4-0e86cbe6167f	07436bdd-81ba-4cb3-b727-f3a57db692e6	goal_deposit	700.00	0.00	700.00	Goal savings deposit	2026-07-25 01:32:38.772647
99f1be0f-b7eb-4264-be45-b9d0523237ee	07436bdd-81ba-4cb3-b727-f3a57db692e6	goal_deposit	49000.00	700.00	49700.00	Goal savings deposit	2026-07-25 01:33:33.07653
175f156c-fc75-4380-970d-e5540f2c0c3b	1db51525-e1a5-4f69-a77e-9ad93f883f50	deposit	50000.00	0.00	50000.00	Initial savings deposit	2026-07-30 21:50:43.44164
f78b7d05-b15d-47b2-ad06-20e7c9afcbe4	1db51525-e1a5-4f69-a77e-9ad93f883f50	deposit	25000.00	50000.00	75000.00	Monthly savings contribution	2026-07-30 21:50:43.444913
a763a36e-cf15-437e-aa27-18377494da33	1db51525-e1a5-4f69-a77e-9ad93f883f50	deposit	30000.00	75000.00	105000.00	Bonus savings deposit	2026-07-30 21:50:43.447324
a2b0bf83-82be-43d0-b6a5-a056a669c42e	1db51525-e1a5-4f69-a77e-9ad93f883f50	withdrawal	10000.00	105000.00	95000.00	ATM withdrawal	2026-07-30 21:50:43.453535
23b65a48-f4ec-46c5-868a-23e6f5d8ceec	2bf4b2c3-d979-4507-9cce-6393866998d0	deposit	50000.00	0.00	50000.00	Initial savings deposit	2026-07-30 21:50:43.48796
c29c0ffe-a2f6-48e7-8477-c4140850bb87	2bf4b2c3-d979-4507-9cce-6393866998d0	deposit	25000.00	50000.00	75000.00	Monthly savings contribution	2026-07-30 21:50:43.489719
9e884362-e8b8-495e-8b87-e3a90602f590	2bf4b2c3-d979-4507-9cce-6393866998d0	deposit	30000.00	75000.00	105000.00	Bonus savings deposit	2026-07-30 21:50:43.491487
78d281c6-3ac5-49bd-b165-6e6743bd6979	2bf4b2c3-d979-4507-9cce-6393866998d0	withdrawal	10000.00	105000.00	95000.00	ATM withdrawal	2026-07-30 21:50:43.494453
06d044dd-cf1c-40ba-91d6-0e536cf92125	1db51525-e1a5-4f69-a77e-9ad93f883f50	deposit	9000.00	95000.00	104000.00	Savings deposit	2026-07-30 23:00:12.140373
749b1428-fd24-4b30-98c6-6f000f044678	1db51525-e1a5-4f69-a77e-9ad93f883f50	deposit	3000.00	104000.00	107000.00	Savings deposit	2026-08-02 11:23:36.790712
cac7e0bd-dd46-4fde-8030-0961d2e1e4a4	1db51525-e1a5-4f69-a77e-9ad93f883f50	deposit	7000.00	107000.00	114000.00	Savings deposit	2026-08-02 11:23:45.19637
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.secrets (id, key, encrypted_value, category, description, tenant_id, is_rotation_enabled, last_rotated_at, rotation_interval_days, created_by, updated_by, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: share_issuance_cycles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.share_issuance_cycles (id, product_id, cycle_name, total_units, allocated_units, unit_price, total_value, open_date, close_date, status, approved_by, approved_at, created_by, created_at, updated_at) FROM stdin;
4a0b4f17-5809-4de8-8896-d2e955ce9094	7a7a4e2d-1fc4-4ad9-9036-895961b81829	Q1 2026 Issuance	25000	25000	1000.00	25000000.00	2026-01-02	2026-01-31	closed	00000000-0000-0000-0000-000000000001	2026-01-01 10:00:00	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.166289	2026-07-31 10:51:08.166289
f7694b46-4575-4c08-8182-59816aede11b	7a7a4e2d-1fc4-4ad9-9036-895961b81829	Q2 2026 Issuance	25000	0	1000.00	25000000.00	2026-04-01	2026-04-30	active	00000000-0000-0000-0000-000000000001	2026-03-28 10:00:00	00000000-0000-0000-0000-000000000001	2026-07-31 10:51:08.17152	2026-07-31 10:51:08.17152
5845b5e4-0c1b-4483-9d31-bbf6880476c6	b4d49db3-bd7d-48db-81f1-e75f6ae50654	Fixed Income Subscription — July 2026	500000	250000	100.00	50000000.00	2026-07-01	2026-07-31	approved	00000000-0000-0000-0000-000000000001	2026-06-30 10:00:00	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.638089	2026-07-31 11:15:55.638089
af3741a7-e884-4117-b62c-b651ad61894a	9ed89d03-0586-496f-b869-4534cc80ef08	Fundraising Cycle H1 2026	50000	12500	500.00	25000000.00	2026-01-05	2026-03-31	closed	00000000-0000-0000-0000-000000000001	2026-01-04 10:00:00	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.670711	2026-07-31 11:15:55.670711
d2792693-dc10-4a28-822c-5468b8889de3	98b4c240-a5c1-4e02-b12e-2dab18837efb	Q3 2026 Youth Issuance	100000	0	250.00	25000000.00	2026-07-01	2026-09-30	approved	00000000-0000-0000-0000-000000000001	2026-06-29 10:00:00	00000000-0000-0000-0000-000000000001	2026-07-31 11:15:55.697719	2026-07-31 11:15:55.697719
\.


--
-- Data for Name: sms_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_logs (id, recipient, message, event_type, provider, status, provider_response, created_at) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_tickets (id, subject, description, status, category, related_order_id, related_payment_id, created_by, assigned_to, resolution_note, resolved_at, created_at, updated_at) FROM stdin;
b95afdd1-ebb7-47de-a14f-696d094a7df6	hello	test	closed	other	\N	\N	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	\N	\N	2026-07-31 00:10:19.612	2026-07-31 00:03:43.173449	2026-07-31 00:10:19.614388
\.


--
-- Data for Name: tenant_onboarding_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenant_onboarding_requests (id, org_name, org_code, apex_org_id, status, compliance_docs, kyc_requirements, product_config, contact_info, rejection_reason, review_notes, submitted_by, reviewed_by, reviewed_at, onboarded_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ticket_messages (id, ticket_id, sender_id, sender_role, message, created_at) FROM stdin;
\.


--
-- Data for Name: user_activities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_activities (id, user_id, action, details, ip_address, created_at) FROM stdin;
2a1740c4-a63f-416b-ba27-f6c23e3d0f32	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	logout	\N	\N	2026-07-25 00:32:47.346563
130815dd-5709-481b-a4ae-58dc7a9a6bd5	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-07-25 00:32:54.805195
23bad351-9248-4508-ae84-803f4a311569	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	logout	\N	\N	2026-07-25 00:43:32.563303
75ede858-ceb7-4ece-ad7b-5882316ca72a	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-25 00:43:43.550706
66540c24-3476-4f7c-a5cc-508a47f7f2ca	43f422a2-64c4-488c-aeee-7827e6d714aa	logout	\N	\N	2026-07-25 00:44:35.939512
419bec56-19c7-4484-80fe-8c17340773b2	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-07-25 00:44:41.932067
1fd0a4fe-45d5-45ee-8857-fc26d6db4a8b	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	savings_withdrawal	{"amount": 800, "balanceAfter": 15311}	\N	2026-07-25 00:44:58.284457
3aa20273-f868-40e9-98b1-70f9b6cfbeab	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	savings_withdrawal	{"amount": 200, "balanceAfter": 15111}	\N	2026-07-25 00:49:29.951611
e3ea1695-29b5-4fd8-8e0a-75ec3f141cca	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-25 00:50:45.111626
b7eda272-cc46-4681-8818-743a7743f3b5	43f422a2-64c4-488c-aeee-7827e6d714aa	logout	\N	\N	2026-07-25 00:51:38.263183
39479dca-d781-440d-a333-0fc758c630f1	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-07-25 00:51:45.603996
a2988d97-1989-4b5e-912f-cc13894f1b11	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	savings_withdrawal	{"amount": 111, "balanceAfter": 15000}	\N	2026-07-25 00:51:58.480247
693a279d-b4fa-4df1-8218-90a99cb838b5	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	logout	\N	\N	2026-07-25 00:59:11.834426
52ea548d-1c5c-43d7-8daa-f0fad5963947	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-25 00:59:18.413301
e6f3ce69-86a2-428b-942e-ba794b090af1	43f422a2-64c4-488c-aeee-7827e6d714aa	logout	\N	\N	2026-07-25 01:09:00.687899
2c69f179-313a-4cb0-8832-9f95890a56ef	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-07-25 01:09:13.700045
94f28f14-e0ed-4f30-be08-6efd186f9605	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	savings_withdrawal	{"amount": 400, "balanceAfter": 14600}	\N	2026-07-25 01:09:28.517919
2e745121-fe86-4bf2-832a-5048c350799f	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	logout	\N	\N	2026-07-25 01:11:09.486693
69f2a9e0-70e8-40c9-9f5a-40c17a822691	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-25 01:11:15.457696
7648b43e-d996-4eee-a4ff-e0bdc64beb49	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-25 01:17:15.525124
d5c1c814-16c1-49e2-9537-e2b282a9055e	43f422a2-64c4-488c-aeee-7827e6d714aa	logout	\N	\N	2026-07-25 01:20:31.771532
ba07b8f5-6fb1-428d-bd2f-81f99cb042b3	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-07-25 01:20:37.971793
003e9acc-b22b-4a5a-9c4b-d5acc575b31c	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	savings_withdrawal	{"amount": 100, "balanceAfter": 14500}	\N	2026-07-25 01:20:58.656408
f43b5cf6-61e5-4ebe-9b0e-f50a18be37ed	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	savings_withdrawal	{"amount": 50, "balanceAfter": 14450}	\N	2026-07-25 01:25:48.125738
b53fadef-98fd-42f3-a638-a701850536a2	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	logout	\N	\N	2026-07-25 01:25:51.772181
f5f9f33b-8bf8-4471-8a4b-c9eea2ae976d	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-25 01:26:06.392855
c6c4ac1a-a1e9-447e-a768-b2e609b6dafd	43f422a2-64c4-488c-aeee-7827e6d714aa	logout	\N	\N	2026-07-25 01:26:38.352715
8f45e87e-3dc3-4500-abcb-29fae2388f8b	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-07-25 01:26:44.586498
b777a561-3eae-4070-9ab9-642a23044610	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	goal_deposit	{"amount": 700, "balanceAfter": 700}	\N	2026-07-25 01:32:38.783167
21127a1f-8c6f-404f-946d-727d15092fc1	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	goal_deposit	{"amount": 49000, "balanceAfter": 49700}	\N	2026-07-25 01:33:33.079777
cbae0bb3-d620-433e-942a-5373b28d0e6c	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::ffff:127.0.0.1"}	::ffff:127.0.0.1	2026-07-29 17:50:56.395491
aa2cba44-14f5-45c5-9e35-6220bd9553f9	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	logout	\N	\N	2026-07-29 18:06:49.629405
a024cb9b-bafb-4544-a438-c82de25b003f	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-29 18:07:47.520747
8f09dd12-2a4b-476a-97c7-4cf70f9ea547	43f422a2-64c4-488c-aeee-7827e6d714aa	logout	\N	\N	2026-07-29 18:08:11.285582
cf67d171-44d9-4070-8fd5-507e2bc8a74e	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	logout	\N	\N	2026-07-30 15:09:55.350998
720f4eee-84bd-4073-aa34-311842c7c048	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-30 15:10:59.995124
983ecf44-03ec-4bfe-8658-d6d7a6d636aa	43f422a2-64c4-488c-aeee-7827e6d714aa	logout	\N	\N	2026-07-30 15:13:51.771631
3a8fd266-4367-4970-ad5d-cac59e535da6	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-30 16:12:13.78206
8fdf4a95-a3ee-46cc-af24-7ae4d529c611	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-07-30 16:14:23.619438
21c48fa6-7c40-4f1a-87c0-6a75b8196d26	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-07-30 16:48:48.807093
30cf8993-178e-4dab-8617-c26c26c4acce	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	login	{"ip": "::1"}	::1	2026-07-30 17:15:51.33006
9451b3aa-8247-417e-9a89-2d42bb48279f	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	login	{"ip": "::1"}	::1	2026-07-30 17:29:46.298176
fae2e741-e5e2-491d-946c-e8122921d12c	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	login	{"ip": "::1"}	::1	2026-07-30 17:34:26.954052
7ae2fb66-3382-4b5c-bb3e-574c15bde798	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	login	{"ip": "::1"}	::1	2026-07-30 19:51:10.798594
9e4a1a1e-1093-48b0-8c3f-c69e49542a4f	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	login	{"ip": "::1"}	::1	2026-07-30 20:35:12.192019
b444b4e2-0def-4b11-b834-123664a6b499	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	login	{"ip": "::1"}	::1	2026-07-30 21:43:41.685903
7c1ba001-fbd0-4244-81e5-0522d1b31868	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-30 21:53:41.295912
3341a08a-3c17-4ae9-b076-a440fbca5e5f	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-30 22:29:59.532298
90b8e0d4-2dfe-4f9d-b0cd-04f546575eff	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	login	{"ip": "::1"}	::1	2026-07-30 22:42:04.356408
93d3d582-3032-4c05-ab25-33af2d4a5113	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	login	{"ip": "::1"}	::1	2026-07-30 23:00:24.842664
178be7ac-c485-45d3-ba1a-4d19b825733d	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	logout	\N	\N	2026-07-30 23:13:10.116838
549825ee-0d2b-4892-88ab-4ca585bfdaa4	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-30 23:13:17.842552
2fbe3f41-c443-4cd0-84df-68cba8f31194	43f422a2-64c4-488c-aeee-7827e6d714aa	logout	\N	\N	2026-07-30 23:13:28.581983
2939e9b6-ac60-4a47-8d6c-9b7c34b078db	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	login	{"ip": "::1"}	::1	2026-07-30 23:14:19.124432
f626b27b-53a6-4269-8fee-4b63b796e8bd	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	login	{"ip": "::1"}	::1	2026-07-30 23:37:08.582625
3f3113aa-3642-4a1b-8914-0b1e615f1306	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	login	{"ip": "::1"}	::1	2026-07-30 23:52:37.752016
deb13548-7b59-4ce2-9dce-18ddffd29a4a	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	support_ticket_created	{"subject": "hello", "category": "other"}	\N	2026-07-31 00:03:43.17912
bd9b33ba-23ab-44a2-9f14-3bf3db28e4c1	f49e9e2e-529e-4629-ae7c-e0e27155e9ff	logout	\N	\N	2026-07-31 00:03:50.509113
637b4fd9-1763-4e83-a9b5-c6a8624fa3c8	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	login	{"ip": "::1"}	::1	2026-07-30 23:13:38.293996
6453d668-0bc5-4b5d-a869-6f709ed568d2	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-07-30 22:52:51.366815
8874693e-7ff8-45cd-b5a7-758bfee7d5e1	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-07-30 22:59:20.927868
ce31604d-5a64-4512-a919-9c574d9ed689	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 00:03:55.910907
6cb049e7-fa31-4ed6-9167-58e9473725ee	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 00:20:06.089591
62f66896-d692-4413-b28e-0e7c9597ac49	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 00:34:26.107216
b44cc0e9-7240-48fe-9838-d512aadd790d	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 00:51:39.595453
62b28f73-beee-4480-9cff-18c0c5e139ec	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 10:37:59.5624
a23c26c9-81d2-404c-92c6-60d2f3627dee	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 10:53:41.76323
0ce60259-f716-4064-ad9b-0ed8bd0ea9e6	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 10:53:59.898388
30314506-c672-49cb-b745-34b256a49a7f	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 10:54:39.113581
6816dc54-ca58-4c9d-afa8-fd8996d6e14c	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 10:54:47.084963
9486cf0b-be05-4f4b-9290-cecc8ac436ab	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 10:54:55.405462
a9027e49-a35e-404d-8a7a-6158131cd1b3	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 11:06:17.098003
9552f34c-80e8-4fc3-994f-2e2f963ff7f0	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 11:09:19.732901
3ffe0632-cac8-4628-bd0d-e7373fa7ba7e	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 11:16:03.397914
6d4eae3c-5276-4e1f-96af-c57d5e52fa22	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 11:16:10.776426
92acf3db-eaee-4e68-9d36-d2129abc9a51	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 11:25:58.888826
f383154f-5b4b-44a7-bc33-d9ab5d6b9ee5	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 11:26:27.12433
abf62a01-9feb-40bc-b26f-f5787f222a6e	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 11:26:32.458118
46e75bf1-42f6-46b9-a7d0-89f1c7607bf7	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 11:26:38.474206
85c466a9-c295-416c-bda9-1ef2b5b59b60	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 11:46:21.03853
f8108ab8-3d14-4526-b6b6-01857022938c	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 11:46:43.215868
e35837ac-506d-49a3-bd1a-75299f8cdef0	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 12:05:49.384011
f44fef46-47b5-40d0-b4a2-599234667faa	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 12:28:49.20116
556ea98f-32f2-44e3-89e0-09b7dcb5b8ae	43f422a2-64c4-488c-aeee-7827e6d714aa	logout	\N	\N	2026-07-31 12:38:16.986706
663167f0-88fb-41de-bc30-40dab247fb60	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 12:42:24.6819
b0dd240f-49f7-4879-b42c-56f4a5346171	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-07-31 13:32:05.061541
56a3b37a-c6bd-4d24-bd2f-2c13bee3baa6	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-01 19:26:03.804115
2dc5748f-7ceb-4c4f-91c2-51506c553d27	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-01 19:32:31.190128
81e28b71-c5da-4e47-af01-e3c2ad9f192f	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-01 19:34:18.111633
428041d2-69e1-48d6-9f5e-3c750c554457	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-01 19:35:11.956967
251807cf-ce95-4cb3-8afe-e2317febb9f8	27626449-01e5-4a80-aeaf-3243caf42466	login	{"ip": "::1"}	::1	2026-08-01 19:35:33.834527
481b055d-c6bb-4502-9e95-4f518457c610	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-01 19:35:44.668194
0a5d82de-6a9d-47ea-b7cb-c2cc7389ac50	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-01 19:36:15.83785
d94b8df8-3aae-4b50-8747-a6412f033a9f	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-01 19:36:45.059894
73755525-81a6-4a5a-86dc-cfffd6e1f4b2	0158c520-82d2-42ec-86b9-23165db8602e	login	{"ip": "::1"}	::1	2026-08-01 19:36:46.293722
2898e091-523d-4b6a-b6f1-60fa20d2bc5a	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-01 19:42:38.991374
f800de22-a39a-4a3c-8cb3-4952e9d074a5	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-01 19:50:46.162399
2ca540aa-22b8-43cc-be47-0cd03cc91876	e04cbdc4-0926-4d69-90ae-4e91ea617ed5	login	{"ip": "::1"}	::1	2026-08-01 19:51:10.206156
a94396c4-6555-49d5-aab5-26d4ae062695	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-01 19:52:39.506915
809f1689-489a-4193-8367-a6c5e477d096	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	login	{"ip": "::1"}	::1	2026-08-01 19:57:22.03676
4de80115-f985-40a6-8c4b-223118027ffe	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	logout	\N	\N	2026-08-01 19:58:15.204238
d6f8f9dd-4ae2-4516-b957-e532c7d7b33d	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 19:59:29.231504
db2aef34-ca4b-48e1-9d16-9dfb23d0d3dd	dd856b59-9087-464f-aaae-7aa764d00670	logout	\N	\N	2026-08-01 20:05:53.89245
e5a13570-3d48-45ec-bba2-5aeb68f5cd9b	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:06:13.654938
c8399a7e-92a4-4fd3-851e-63920f79ed72	dd856b59-9087-464f-aaae-7aa764d00670	logout	\N	\N	2026-08-01 20:08:02.609551
55a34a42-d63b-4add-b365-300b6393944c	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	login	{"ip": "::1"}	::1	2026-07-31 13:55:50.925581
5604e2eb-f1a6-4821-a3ac-0abcc1d2df6c	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	login	{"ip": "::1"}	::1	2026-08-01 19:25:21.399159
9591f504-0846-41a2-8874-367e2cddeca6	a990ffb2-bfb9-466c-943a-fb19be731cae	login	{"ip": "::1"}	::1	2026-08-01 19:56:55.698642
46e920d7-b8db-4f9f-b63d-f62fea86d7d6	a990ffb2-bfb9-466c-943a-fb19be731cae	logout	\N	\N	2026-08-01 19:57:13.154376
7f3d1854-be78-40d6-b202-4c5764773cec	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-07-31 12:38:24.964185
9f1458b7-6189-45fa-b0b1-f510ad2b8b89	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-07-31 12:54:32.909797
b1a321a9-e88e-4b4a-bf3b-73a4ef119e3a	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-07-31 12:54:57.701867
335b7015-78f9-472d-89fd-43afb8cdc26f	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-07-31 12:55:59.593183
abe7bbca-22d3-4417-9b71-a095272a0e8a	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	logout	\N	\N	2026-07-31 13:55:43.32983
0effbfa0-ad46-4cbc-89ee-d0c7ea1656ac	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:08:44.295899
cc30d18e-9e69-4f48-a90b-982e09cf07a5	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:08:56.249458
dfc9ac69-9958-474e-9a24-a81976abc3bf	dd856b59-9087-464f-aaae-7aa764d00670	logout	\N	\N	2026-08-01 20:11:19.936279
fccd080b-9cb7-4911-9f76-e468e812af32	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:11:32.988281
fed8a067-ea9a-40a1-806f-ad099fa3cdec	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:13:09.730408
47fc4bb0-affa-4b5b-aa6c-37304e61ef6c	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:16:58.46552
63c03dc8-e13f-495c-aad0-4f96233b12c9	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:21:27.755536
870787fa-7a37-4c3f-bae0-3408984c2ee4	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:21:33.307706
d9e10435-12a4-4dfd-a3f1-75d4b2996bff	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:21:42.463225
376a0049-b5c7-4e37-afa4-2f238d4c27af	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:27:13.394802
e4a2a0f5-d435-49b4-b578-a8f467ce02f9	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:27:41.298621
74715ed3-50be-4ed2-bc5a-64ce88af186e	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:27:48.417399
67c0a621-ef16-421f-af7f-b223ef6d0097	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:28:13.188211
48e09214-3afd-4e54-8782-a721b2964afe	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:44:59.498465
9f6ce34f-5abe-433e-8f01-2ba1ad725d86	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:48:34.474354
fcfb16d5-1e87-4414-b754-f298a9ee794c	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 20:49:40.997397
b5f6655c-d5af-4121-9f72-b00185c865f8	dd856b59-9087-464f-aaae-7aa764d00670	logout	\N	\N	2026-08-01 21:01:39.976783
5892ce0e-3c29-4ac1-9cd1-912da377a97b	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 21:06:16.31754
61bcc520-68de-45d0-ab7c-a835f56e8db8	dd856b59-9087-464f-aaae-7aa764d00670	logout	\N	\N	2026-08-01 21:07:04.715699
10a9a8e9-e043-47bc-a056-26a56308c352	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	login	{"ip": "::1"}	::1	2026-08-01 21:07:40.747077
08d60931-6488-4421-a136-23039531ec5d	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	logout	\N	\N	2026-08-01 21:08:05.792968
e27767bf-609c-4106-b2b0-423d2fde95da	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 21:08:16.195003
4435eac5-9e47-43d9-aa0b-89a6412ca9a0	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 21:13:57.194365
b8f5a886-6739-429c-866f-4edb32592e98	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 21:14:09.476911
4aa973b5-8f3f-456b-9e37-43d30062f77d	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 21:14:16.98745
4d818e14-b9bd-43d2-8680-c47b652dcde0	dd856b59-9087-464f-aaae-7aa764d00670	logout	\N	\N	2026-08-01 21:21:45.347037
1f164e09-5f51-4af4-b387-fb072a67604b	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-01 21:21:55.851754
bd9d1c97-e8f5-49e5-960a-fa65a2542de1	43f422a2-64c4-488c-aeee-7827e6d714aa	logout	\N	\N	2026-08-01 21:23:09.693323
a4c341fc-437b-40f2-bdc9-46d7a494a641	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 21:23:20.649866
94e09809-fae3-4b5e-abcd-0e19e9820182	6ccb2ee7-4961-4316-b230-04598845ef6c	login	{"ip": "::1"}	::1	2026-08-01 21:36:18.143137
f9da69f0-5e71-4e7a-b144-fbc9ee362946	6ccb2ee7-4961-4316-b230-04598845ef6c	login	{"ip": "::1"}	::1	2026-08-01 21:36:26.047165
06b77e58-1bc4-40e7-a321-b35d0b41b8ed	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 21:56:42.407638
c32b0f06-e8f4-42e9-81a8-a46778c41097	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 22:00:01.654622
698e55da-6614-43e0-968c-9ad340527577	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-01 22:05:57.528182
94ee2367-51fb-4599-895f-031ed637b9a1	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-02 10:28:42.02412
f33e53e2-d429-48d3-91d5-7d7cf4bafe6f	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-02 10:32:33.576307
bbd51560-e7f7-4eba-a192-d5c6e66950d2	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-02 10:45:45.970597
68fc5140-c0ec-4020-9352-d789b1a56d95	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-02 10:46:56.27475
a6541bcc-f121-43aa-b179-e623e3c635fb	dd856b59-9087-464f-aaae-7aa764d00670	logout	\N	\N	2026-08-02 10:47:49.728937
27f43882-b5dc-425d-9e7c-c55878112dcb	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	login	{"ip": "::1"}	::1	2026-08-02 10:48:29.238799
ac63d1c3-9f7a-4fb3-b45a-8c6cda935b9d	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	login	{"ip": "::1"}	::1	2026-08-02 10:54:43.833384
031d883f-a0e2-46a1-bd9f-ead2fca2d20d	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	login	{"ip": "::1"}	::1	2026-08-02 11:02:02.190741
8a924405-116e-49d3-a389-c59aebf6b87c	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	login	{"ip": "::1"}	::1	2026-08-02 11:07:52.196187
fceb1ef4-ca68-4a2d-af1b-710edf0727d7	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	login	{"ip": "::1"}	::1	2026-08-02 11:15:40.044374
4babb5ee-e57a-4a66-8e54-618be70a5fc6	87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	logout	\N	\N	2026-08-02 11:20:11.885537
b3d44c04-9573-4db5-93b5-f4aa556705de	dd856b59-9087-464f-aaae-7aa764d00670	login	{"ip": "::1"}	::1	2026-08-02 11:20:20.317177
3a6ba256-3238-4a2f-8b1d-863047bfe11b	dd856b59-9087-464f-aaae-7aa764d00670	logout	\N	\N	2026-08-02 11:21:58.30426
741dd5f3-1782-4a9e-b60b-4d899cb19b92	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 12:54:37.384079
aff5be1f-18f3-4ddc-9ed6-dc77f6ebc128	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 12:54:41.911706
f5797620-9304-483b-86dd-68b962cbfad1	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 12:54:47.067126
09639165-027b-4092-b8b5-92037e785359	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 12:54:52.350957
d5e4e0f3-8b39-42f7-8096-aa30a2ba9b50	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	login	{"ip": "::1"}	::1	2026-08-01 21:07:13.638097
409165ba-114a-4eae-8a37-41309fae0d26	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 11:22:13.689549
b7c31fce-498d-4bc1-a895-ab48532dd7da	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	savings_deposit	{"amount": 3000, "balanceAfter": 107000}	\N	2026-08-02 11:23:36.798799
7021473b-40fe-4581-be84-e73db1cfb56b	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 11:40:10.051132
36a4e625-9a8c-4fb5-b898-8b5032543527	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-08-02 12:40:27.64442
99b2a04a-9577-4512-accc-4466a960614e	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	logout	\N	\N	2026-08-02 12:43:48.626891
918b4fc6-9e9c-4989-9a11-70cea83e2d3e	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 12:54:58.407275
4e7541f2-44d2-418e-bd0e-eb5a048ea895	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 12:56:33.041743
41a952a6-dca1-463b-a24f-edac4eb6a9ec	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 12:56:49.129952
43b99b22-16b7-4323-8a5a-53213ffad3db	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 12:57:52.472914
e8c12376-773c-4a24-9ae2-53c91af132ac	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 12:57:57.552154
39167089-a87e-40ca-86c1-6a3cd68ba7c9	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 13:09:26.765896
ecd18685-9403-4f46-b5b3-576f2d61c6f7	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 13:17:02.96189
e9cc61e8-30a1-4003-b95e-b2f5d9bd9651	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 13:17:10.586658
5f135f82-2291-41f7-b839-2493cb182132	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 13:17:26.302326
5d18dc10-5be8-4df9-97d2-0058c3700e73	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 13:17:34.137212
b38d672f-2e48-46bf-9e8f-2cff70eb64d2	aa38f00e-7fbd-4d31-890f-d63c6ef2b452	login	{"ip": "::1"}	::1	2026-08-02 13:17:40.91539
7462941b-afe1-4c68-aaa5-d66f13cce4f5	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 13:18:13.428718
ac3f2106-fbb8-4cba-a4d8-bbafd8fd6767	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 13:18:20.526251
dc4b04e4-3fc7-4985-b08e-3f3fc525cb84	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 13:26:20.675877
41803385-4b86-4e5d-97fb-daa42ab87322	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 13:28:00.343883
24583476-307a-4334-bacc-8ab9f65ed74b	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 13:30:21.875087
d685daee-d5cb-4a60-a500-ebacc961bfec	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 13:42:24.111404
1866e5da-6428-459b-b8eb-2045ce97aca1	43f422a2-64c4-488c-aeee-7827e6d714aa	login	{"ip": "::1"}	::1	2026-08-02 13:42:46.176692
6a63771b-5a7e-480a-86ac-554c9060d20f	fff19150-f8f4-4330-a063-63d1b0d82372	login	{"ip": "::1"}	::1	2026-08-02 13:50:36.640559
286d2c81-0d89-4c41-a223-a99dcd41f04f	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	logout	\N	\N	2026-07-30 23:14:10.078514
79534305-d8ca-4dd9-93d6-fcfc564daac9	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	logout	\N	\N	2026-08-01 19:25:49.300412
feaeeec7-a5de-41d1-903c-470526c7812a	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	login	{"ip": "::1"}	::1	2026-08-01 20:08:26.486689
b4afd4dd-a266-4213-b2c8-e547c25d3001	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	logout	\N	\N	2026-08-01 20:08:37.394123
da7bff37-b8ef-477e-8c2f-99de6475718f	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	logout	\N	\N	2026-08-01 21:07:24.924557
32e699a3-201e-4366-8429-e935518d1d39	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	login	{"ip": "::1"}	::1	2026-08-02 12:44:06.011651
b53cf600-34af-4039-a295-fc200980418d	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	login	{"ip": "::1"}	::1	2026-08-02 13:04:04.946462
4883d3cb-a826-4795-8610-91b1bfa5e12d	d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	logout	\N	\N	2026-08-02 13:08:52.576078
f51f8bd4-a3c0-460b-9db9-8bd3c4be3bff	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	savings_deposit	{"amount": 9000, "balanceAfter": 104000}	\N	2026-07-30 23:00:12.14584
0a993ca5-9194-45fb-83ce-04694f7e22e2	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	logout	\N	\N	2026-07-30 23:00:19.21231
36917848-ad5b-4c00-a886-56c94a39b6c4	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	savings_deposit	{"amount": 7000, "balanceAfter": 114000}	\N	2026-08-02 11:23:45.202373
421a95e5-c889-4bbc-917c-d5530ff184b0	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 11:55:15.594457
a3f1a211-9ea3-4b39-a4ea-309e35460dc1	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 12:07:45.588177
f269c6fd-3173-4dc5-b7a7-6eac52c6b8ca	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 12:11:22.151136
0b4ffbce-6f37-4a3c-aa22-16d89d64d551	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	logout	\N	\N	2026-08-02 12:14:37.988194
11cdc3e0-05cd-42d2-bc05-a84a9b66c4f8	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 12:35:47.967137
8066f6bb-5e04-4d1e-a261-b7e0025d5684	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	logout	\N	\N	2026-08-02 12:39:36.768494
26207b3d-f569-4040-a393-171c3b906718	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 13:26:29.077495
980adfbd-c28d-4aea-8d1d-fbf29b7903cc	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 13:28:27.810242
f1c3e63a-c60d-41a5-a039-dd61164aa8cd	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 13:30:13.039557
864997f2-98ac-4b28-9612-e53100955825	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-07-31 13:01:34.908614
c867c845-87bc-452f-94a1-1a6513fe5215	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-07-31 13:25:57.303062
15206290-a947-4173-aeb0-9d70821822cf	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-07-31 13:26:05.246549
b72447a8-e21a-4969-b81f-ab5eb92034f1	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-07-31 13:34:57.349924
486e644a-98df-4129-b9ed-16a0a3bc4f00	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-07-31 13:37:51.711678
2f7ce289-e490-4bd5-9a8d-3113133f784d	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-07-31 13:53:31.484012
a795cb2f-effe-40b9-bbc4-4a5beb82402b	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-08-01 19:51:19.395589
9df846e1-d1b6-482d-88c6-a5d8e2b6a9cc	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	login	{"ip": "::1"}	::1	2026-08-01 19:55:34.953052
be6820e2-b62b-439e-a7d9-86cc2009e79f	70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	logout	\N	\N	2026-08-01 19:55:40.808609
3c0c781e-1e85-404a-8bda-0cdb1154d604	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 14:00:51.050439
6dd6f4a5-4160-4f8d-a3cf-28f4122df2cf	fff19150-f8f4-4330-a063-63d1b0d82372	login	{"ip": "::1"}	::1	2026-08-02 14:00:52.096299
53a00ed3-5534-43f7-a685-3c2a34b5bc66	fff19150-f8f4-4330-a063-63d1b0d82372	logout	\N	\N	2026-08-02 14:01:39.762335
54ce2608-f249-4dac-808c-402a7146cef9	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 14:01:47.015278
58c9243d-a02c-4768-9c5a-355e46d1d737	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 14:28:12.715038
bb86ca63-b0c5-49cc-8e19-a859de045e9f	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 14:43:29.855155
530bee06-e324-47f6-9cf2-2f382f09d990	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	login	{"ip": "::1"}	::1	2026-08-02 14:58:52.485049
a35a27e4-87c5-470f-8e8b-42022274ca5a	8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	logout	\N	\N	2026-08-02 15:09:13.739591
f50e4d0f-37b3-4275-96cf-22f45a90bb05	fff19150-f8f4-4330-a063-63d1b0d82372	login	{"ip": "::1"}	::1	2026-08-02 15:16:45.377198
70ed607f-3bac-4e1b-8094-1f9709d6e318	fff19150-f8f4-4330-a063-63d1b0d82372	login	{"ip": "::1"}	::1	2026-08-02 15:34:58.86003
630a7224-0127-4ec0-a6f7-a45a96e216b9	fff19150-f8f4-4330-a063-63d1b0d82372	login	{"ip": "::1"}	::1	2026-08-02 15:36:24.551263
d8f37f3c-6710-4b30-a282-ffea1ddb9a65	fff19150-f8f4-4330-a063-63d1b0d82372	login	{"ip": "::1"}	::1	2026-08-02 15:39:45.105376
5de8518c-cbaf-4e73-9312-08319fcaf9e4	fff19150-f8f4-4330-a063-63d1b0d82372	login	{"ip": "::1"}	::1	2026-08-02 15:40:32.999938
0924941a-168d-4651-b901-d746de207b2b	fff19150-f8f4-4330-a063-63d1b0d82372	login	{"ip": "::1"}	::1	2026-08-02 15:41:33.534249
85c1638d-b329-4c7c-900d-bc53e7895caa	fff19150-f8f4-4330-a063-63d1b0d82372	login	{"ip": "::1"}	::1	2026-08-02 18:56:09.970814
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, role, apex_org_id, organization_id, kyc_status, kyc_reference, is_active, refresh_token_hash, created_at, updated_at, registration_fee_paid, reset_token, reset_token_expiry, social_provider, social_id, notification_preferences, referral_code, referred_by, referral_count, referral_earnings, failed_attempts, locked_until, email_hash, phone_hash, phone, deleted_at, kyc_verified_at, kyc_image, first_name, last_name, must_change_password) FROM stdin;
dc82e50e-c01f-44e4-aac3-a84af916c3da	acctest@test.com	$2b$10$WFwJcTS5XeloZYqHm2S3se.pwkqsYq.LZApyGBlfJh8j246ejcMr6	individual	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	1c604058-5564-43c5-bf9b-46cdab31b9e9	none	\N	t	$2b$10$etPhL.U9QaqV8VrgrrLMGe4RjLVGZeCz8KXXS/pcJ1SMPqoBEzsM.	2026-07-22 21:11:57.420723	2026-07-22 21:12:03.571905	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
8bd25825-c8f4-4673-a50f-d268ba49c156	test@erd.com	$2b$10$hvs8V69..Tw/dYD/fPbp5e6d/XJX8nfNWGmOdIjSuLKhpi4kzsJCC	individual	\N	\N	none	\N	t	\N	2026-07-22 20:50:54.80849	2026-07-22 21:54:22.023409	f	9F5D01	2026-07-22 22:09:22.022	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
4e84964f-4cb3-4bc3-9d37-fb081ae2be51	testreg2@test.com	$2b$10$1N1.V/EnAQvucKGrwidEWOac.qRqKNoa7mKl5wiEo2vks23Pje6l2	individual	\N	\N	approved	\N	t	$2b$10$G4MfZTyEAEMlQxTJmMnES.Z8uEudKcj5KwlRaaeA.b/HhNE3ffgwG	2026-07-22 20:46:11.395376	2026-07-24 13:17:58.981917	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
6c534230-4307-4216-99e3-6852b9d78780	testreg3@test.com	$2b$10$lWOBO.Kaz5SY/9T0Vnf4w.kd4Ny/0NLSZMR.PjdTV47NK3SuWFayC	individual	\N	\N	none	\N	t	$2b$10$n1IiEBYqziFKh6epMsVnUu5aZ8ojgwRNP0qPKGmlPzmdE8r4j33vi	2026-07-22 20:46:37.037599	2026-07-22 20:46:40.576387	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
1ac709e4-89fa-49c7-8b0e-b44d658a3357	apexbm-apex002@coop.com	$2b$10$1rd8BquI/akTGEJcUwhdre2vlRdtX12/6uYhM8nXi72UzDzxoxy7O	apex_business_manager	b8ecfc27-24f1-4dd5-9668-9ba5b2d420ed	\N	none	\N	t	\N	2026-07-24 21:29:26.025067	2026-07-24 21:29:26.025067	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
16409ae8-67ff-4e2f-92c6-eb50ca6e5744	apexbm-apex003@coop.com	$2b$10$gKk7KmWJRPNhcFVNyevNS.uY21oGM8O5Wt9E2agyENj7OtXyoA20u	apex_business_manager	94fa108c-1fc3-45b1-829c-0183e2a31eb6	\N	none	\N	t	\N	2026-07-24 21:29:26.096425	2026-07-24 21:29:26.096425	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
ddf75476-cf56-4cc0-9abc-c07689115749	apexbm-apex004@coop.com	$2b$10$E1WpeWAkzsPJmUKZOsT1meRBP9OtAwIHrwP7UBLHudfovOjXHJlYq	apex_business_manager	63bc3543-39e3-4c1c-85b4-c3f2802099c5	\N	none	\N	t	\N	2026-07-24 21:29:26.167936	2026-07-24 21:29:26.167936	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
6ccb2ee7-4961-4316-b230-04598845ef6c	bm-org002@coop.com	$2b$10$4hKOIG8nY1k1cVEq1Q5cPuzxrLTgCKoJLuqwprxX0.67K9rkoptWi	business_manager	b8ecfc27-24f1-4dd5-9668-9ba5b2d420ed	9cc99602-80f1-4917-b42d-91c0511c6765	none	\N	t	$2b$10$3NEWMTO1Wu9Ue6ukcWItF.Gqjunbh0DsK0o/0lSMIK2P.2wYOmCHO	2026-07-24 21:58:00.940875	2026-08-01 21:36:26.041544	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
eb143f32-c121-43ff-a8f3-278fe9e3c452	bm-org003@coop.com	$2b$10$3UPFn6OhWYJlxv3rxZPteeuIeyxKSYLxDkNzrlWyzIpDRY/jP6Rgq	business_manager	b8ecfc27-24f1-4dd5-9668-9ba5b2d420ed	301336e2-7728-4f40-a5f9-83755964c4df	none	\N	t	\N	2026-07-24 21:58:01.005915	2026-07-24 21:58:01.005915	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
f008c2ac-5ec5-40c9-a613-f47ddfa7fdc3	bm-org004@coop.com	$2b$10$j6qOOfbiJguUKqHZiRRVHulspPl77Ff.0R0i21XROsmXhPK7MDHbO	business_manager	94fa108c-1fc3-45b1-829c-0183e2a31eb6	3a3cf4a8-bdc6-44c3-80d3-67ac29f7b682	none	\N	t	\N	2026-07-24 21:58:01.073973	2026-07-24 21:58:01.073973	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
dd4a3942-fde5-4b0f-ba17-5c95e50c3164	bm-org005@coop.com	$2b$10$7whevXeLluGkL2wFVk4Bo.3Cc.0sW81v/JyaNaaojtquRu2xJ0HHW	business_manager	63bc3543-39e3-4c1c-85b4-c3f2802099c5	90256b85-476c-4d11-8774-287c2e4c4654	none	\N	t	\N	2026-07-24 21:58:01.139493	2026-07-24 21:58:01.139493	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
2b02ed70-c5f2-4632-9eea-5d6818a66aca	bm-org006@coop.com	$2b$10$ekPnIH2Sji3cXCxG6iHwuOD0ivENEdBPde3Yn2KyTF/78/vr602La	business_manager	63bc3543-39e3-4c1c-85b4-c3f2802099c5	fbfdb1fb-f5dd-41cb-b740-3f32e275eb76	none	\N	t	\N	2026-07-24 21:58:01.207684	2026-07-24 21:58:01.207684	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
a990ffb2-bfb9-466c-943a-fb19be731cae	bnpl@demo.com	$2b$10$KZmxPyEx5gpaQDbq6bblqefSBor7.cxR11xONfsozXjQXOa4qyow6	bnpl_manager	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	1c604058-5564-43c5-bf9b-46cdab31b9e9	none	\N	t	\N	2026-07-22 19:32:13.605857	2026-07-24 17:51:02.824524	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	58ed3ae8d16882ea0d0026d9295adb1b7f02e1ced29fa0c4186cbae7bfb0a8a0	c45bc305cdace7e4983a1a229177dc369db9d94fa09f21d00bd5edc5041a89ef	b8c32641215093a684c1b377cd7b31eb:bff2d43d07eb4655dde19b6218cbd10b:d1757b82108a2ccaa607ef	\N	\N	\N	\N	\N	f
dd856b59-9087-464f-aaae-7aa764d00670	bm-org001@coop.com	$2b$10$mLpbxXEx2MYQy1q1nxhv2ePnzeVZFBr4UYtO7OujD7VzuWmCIyCUG	business_manager	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	1c604058-5564-43c5-bf9b-46cdab31b9e9	none	\N	t	\N	2026-07-24 21:58:00.867038	2026-08-02 11:21:58.296119	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
8c93c4b3-c6f1-4986-8b0c-030fb45ee5d5	user@demo.com	$2b$10$ZV4543kW3fSP73bfxokxzeKNJpoVkQCxktGfTo0ZbYwWrIuCuF9/.	individual	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	1c604058-5564-43c5-bf9b-46cdab31b9e9	approved	KYC-1784753892523-zgwfdy	t	\N	2026-07-22 19:32:13.541112	2026-08-02 15:09:13.730141	t	\N	\N	\N	\N	\N	COOPBXFQOP	\N	0	0.00	0	\N	6a72ec0b6f3b2e22ee85c63c6557bf15d214f7701d3ba1d19924d1d877d2c947	e7da1424159f0e1fa87cf3e699dc507a87ff4d376115311152e1738dacda9fc8	5425b665b472fbc2940f51107e459c6c:5047d12f06fb4b936433c56fc3920491:	\N	2026-07-31 13:58:26.579	\N	645b56ef1fed8703ef27d117e083cfc9:e437b64e279430bad00775dec8c3c391:7a6121ef	80553f0f27989da344f5836eeb23f6db:5894a0b4b256d5e61af6f4bcff8b8d46:f63df2	f
d0988f3c-4ca0-41e8-9f32-d099f1e31fcf	admin@demo.com	$2b$10$TiTsuQIM2Hc53skuwsP0g.HeqQIJved/cQ43G6JCRHzBWo9sqgBVa	operational_admin	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	\N	none	\N	t	\N	2026-07-22 19:32:13.473443	2026-07-24 20:36:09.615689	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	cd7e8bc92495207a65a6138e56bd45990d75f0e1ea78aafbb33126fffb2409e5		4b376c0cd5200b426300970e58e8ca1f:a2728e0e33409ccbbc1cff73699e35e6:46bc734cf7ce4b953ee8fb	\N	\N	\N	\N	\N	f
70db3dcb-b0eb-48cf-8566-6cbf71e32cc8	acc@demo.com	$2b$10$surgZwvyC0S4bkymQXo4u.ViDWe4NUnEyLbIy.9pYGGNqyU6gO33C	accountant	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	1c604058-5564-43c5-bf9b-46cdab31b9e9	none	\N	t	$2b$10$Chj2idQYC6CEx0YG1oCDNeZ.btk8ak2UWC8CpuIby2qhqD/Fz3h7u	2026-07-22 19:32:13.671486	2026-07-30 16:48:48.784482	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	0cf39c41dd7c1dfb32faab38f62960689faafa2a553e9ae72b48659541d8668e	6689cfbfe9a289d2ba4ec2d91e0c1b2a04638b38746b0ca0fcf3eef3ab4b9daf	f6b57eef2430a02576fc10000a3b74c1:e8301a20cf549bf5c45898e67faf02fb:93e08b32a98978b9f98f8e	\N	\N	\N	\N	\N	f
87d2b9b5-2b44-47e7-87fa-05d6bc0617ff	apexbm-apex001@coop.com	$2b$10$lfB1f0/QpIVUyAmDXhi6MOFzOMPDiafIlXoawhiexNgnmkaGavd/i	apex_business_manager	c148cc61-b0ba-4d8f-be6b-39f34e1538e1	\N	none	\N	t	\N	2026-07-24 21:29:25.938098	2026-08-02 11:20:11.875505	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
0779d3d4-9a41-441f-9823-49702b064aa6	465446cc1b193d1ab97ba80f4db964ac:d2a36597cea970845149fea032c1f951:a2fd7189dc3bd62951c859142e	$2b$10$IZ8RvbUI1ZNp4ByuGch3qOHHWunOS.T.TmX7.xmJbeSx14PnkIXKm	individual	\N	\N	none	\N	f	\N	2026-08-02 13:26:06.781185	2026-08-02 13:30:22.225998	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	6fd02a683c6e92c7266b3ca0506332cd49e531b4dab3a197b52651a74908f7e9	61d593aff531c413752d4a580c9c6b64977c7c861270528d9ef765715959e9c3	1624d9d17fc3d78d14334d5bc86ca55c:cda1be724ab9890ed9b4b6c06a1be957:cada2a947a97798b678d9b2d2a	\N	\N	\N	dfffd5dcdb8571a2e5b9eeb5685a9a13:d932cf345094db873124f6779e7a5a3f:4b	59ee3bf88d3a9b2ff85d3fbea0ce67f2:c1ba6f9917a83764db909f9dede2aa76:f3cce0	f
bb3b64c5-0635-4521-85fc-b90dc5f369f8	0cabddb260d13b7a31feb2444eeda15a:294b286438dfd87feedb7f9893a09ee3:2e7c2d975bb10c248fe7d5bfead804	$2b$10$tWFUXfhpFpdPPkpyqaWPUeKTYEBPQCHrB/tmYHPk02pDGB8HrIp0q	individual	\N	\N	none	\N	f	\N	2026-08-02 13:26:07.099987	2026-08-02 13:30:22.689978	f	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	3126eb537f666ba79f69d75b42b4b9da12a94d183c3e3e417a5648476e83d63a	4363000e8be360adde27c14db092730381ff0c963652edf941054e1cead0858d	607c6ecacb9a056e63441d5a7c7e672a:b1fd67c1f82909b9e37e1f6b8e9937e3:4802c5ec7b4f512a5dcb97da95	\N	\N	\N	6f89fc12aeffd71f2fb47ffbbc2fabdf:f08f8c4a4f4490a2812506db25fde956:e0	f863fe23e0e4aa16176842a98b1e8b99:07df3a7a2edf03f7368f44789a561ea6:46c4b0	f
a0df9098-ee33-4482-969d-f73ace7cadd0	983ab084743df7e16ea02ce14b700d41:e3fa8234bce4cfa9922115ce2b77de91:4382e03aff9b42cef815bfb05b53	$2b$10$m6BwZGFRIAi2qLJbhXza8ekiSo0g81XTuw1t1UR2GnUoJmnSNyMEm	accountant	\N	fbfdb1fb-f5dd-41cb-b740-3f32e275eb76	none	\N	f	\N	2026-08-02 13:42:24.274885	2026-08-02 13:42:46.216764	t	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	aa26678a3b50d5dac86f7697c73a64bc55b00939d6dee26390c891c69ae3b581	\N	\N	\N	\N	\N	3c536c3b78b454dcc9d98933902ba5bd:abb0d3dc38fc4fc82527f5df7716f915:97249e5e	1dab616cce9392c02123edec1695bc04:e331f7008b0d6300dfeb307815d71325:9feca2	t
aa38f00e-7fbd-4d31-890f-d63c6ef2b452	8d47e2e975d0f20a28b05ef20d1a9507:719bca344005982262ada9bcbc796bd8:3c83a7288db7e467cb949387ead8	$2b$10$Y5USYFcMXCeIpQUxLbLO6etzduD4jqM8Vt0oCR6/eBqQLI7QoSiFO	accountant	\N	fbfdb1fb-f5dd-41cb-b740-3f32e275eb76	none	\N	f	$2b$10$1zeDsEezeU35fjXvPkArX.V34L9Lru1kQzxS0jsRRAQXloN0fEQei	2026-08-02 13:17:26.456688	2026-08-02 13:18:20.57413	t	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	685c81563a5b402e3177e39105febc4ff05c021f3b1359f0ba5f36091ef3a847	\N	\N	\N	\N	\N	d0b8bf962e6abb2c8ac6d2e128e130b3:d558046410616aed9502d8a35770ad78:f0	72ca601f8b667435f797720bb53e3c1f:796a96e744b7f0eadbcec9efbcdc290d:41	f
aea35868-659a-4394-b3da-dd0d3737e006	7b85cae605c19a058884b6b8e3a494e5:06f20c0d1325598dda9308640e8d9a00:475db88735672855189288082455	$2b$10$bYHtCzFvHanISCN53bF1oeHAikx12nNJd/9DSn0ttRbTlfTGzVCOa	bnpl_manager	\N	fbfdb1fb-f5dd-41cb-b740-3f32e275eb76	none	\N	f	\N	2026-08-02 13:17:34.342991	2026-08-02 13:18:20.609508	t	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	a3e32899ff230ac4dc880ca6e7946466a80e31bb44cec61a96b3deb423875884	\N	\N	\N	\N	\N	\N	\N	f
3c15bb9a-b58c-4255-8bf9-a52eca1984a7	58dbae211b99c9b549186f90a9a08f64:c32439e9ce6ecb2e7e6bbbdb1fafb8ae:145e00a9f26f108aeb282e9e7fee7f7323	$2b$10$u7lggS3.gai.Mf6UY0Aj5eho8TopKKS84cG02M8cGPpN17SGFLQCe	operational_admin	\N	\N	none	\N	f	\N	2026-08-02 13:17:34.479047	2026-08-02 13:18:20.645262	t	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	d0cd20cc87382728ba16e9512ac7a6cabbf55bcd237b35a011e609558455e2f3	\N	\N	\N	\N	\N	\N	\N	f
f49e9e2e-529e-4629-ae7c-e0e27155e9ff	aae71bdcf824d087def2bf5d9dc9c8af:7eb9a03748eb803bc502036a87b0bf1c:fe7a75b69be7db9b764de7ebe0	$2b$10$nT/Gz8EpeneSYynij0cwfeuojFh.aIaNZQfNqFQL0clirxb2QQRUq	individual	94fa108c-1fc3-45b1-829c-0183e2a31eb6	3a3cf4a8-bdc6-44c3-80d3-67ac29f7b682	rejected	KYC-1785449176946-5w7io1	t	\N	2026-07-30 17:03:48.445835	2026-08-02 13:28:40.790009	f	\N	\N	\N	\N	{"sms": false, "email": true, "inApp": true}	COOPTKKFPH	\N	0	0.00	1	\N	2c44b9a56a853548aea328110647417a1404a9549d47875b95b5baed78841621	9876ccefa1e426aad25916a9cec49e9598bffcd5434d356c7d0c3cd3f0142baa	9aaa8de17f2b5a09f5497d3bc133d449:00701b16e1ccd537177fb299a04bd912:df1b82121cb3a371484519	\N	\N	\N	\N	\N	f
fff19150-f8f4-4330-a063-63d1b0d82372	1bb6c8f17212f5575d225993231278db:eab028a3e693df3985bab81bf0445c22:f4866464af3a3e006ecc752f38903a2b159b7e	$2b$10$dn4HMMobO7bjJ8pFeZKgAub1iH7A/6XNChnvhCgBL.0iLMJb9hVDy	super_admin	\N	\N	none	\N	t	$2b$10$o6Fxh3BJt98UpHxgdliA4OjsuHecwvJ3ZtQfajfnr5bx/j/pEa2CK	2026-08-02 13:50:06.934687	2026-08-02 18:56:09.938846	t	\N	\N	\N	\N	\N	\N	\N	0	0.00	0	\N	f217627f82dfd17cd30ec91b446acef1f3ac469f65d0e864537671c9a8654980	5d04862a96bd5c5493fc2d2958d786a7ed318bf4c38e9c13d41e9be5813cef28	ba19b9f5165392429e94d8b0102b6f95:fc540db98428f9e68cbeca47abb14ae9:f323ca07e98bc1080df929	\N	\N	\N	49ef448d8a35df62ea1fef0e90fc738e:271ed19e1e6407b046847ed1d494b0b9:cebb1c16f0	e3b466ee51e95ba6c7e01440d4540926:4f5e7496d961c4af28e341051340cf8a:ee4bf5e101	f
\.


--
-- Data for Name: webhook_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_logs (id, provider, event_type, event_id, payment_id, status, payload, error_message, retry_count, created_at) FROM stdin;
\.


--
-- Name: distribution_runs PK_0a16b0b8dcb8112cf97a87bdd6e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_runs
    ADD CONSTRAINT "PK_0a16b0b8dcb8112cf97a87bdd6e" PRIMARY KEY (id);


--
-- Name: reconciliation_results PK_0b6608e74a7d0ef09b647909960; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reconciliation_results
    ADD CONSTRAINT "PK_0b6608e74a7d0ef09b647909960" PRIMARY KEY (id);


--
-- Name: bnpl_catalog_org_eligibility PK_0c6569f0101e551b71170f3ce0a; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_catalog_org_eligibility
    ADD CONSTRAINT "PK_0c6569f0101e551b71170f3ce0a" PRIMARY KEY (id);


--
-- Name: bnpl_audit_logs PK_0f4ff8ed9ace6b1d5e9141eab07; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_audit_logs
    ADD CONSTRAINT "PK_0f4ff8ed9ace6b1d5e9141eab07" PRIMARY KEY (id);


--
-- Name: user_activities PK_1245d4d2cf04ba7743f2924d951; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activities
    ADD CONSTRAINT "PK_1245d4d2cf04ba7743f2924d951" PRIMARY KEY (id);


--
-- Name: global_security_config PK_1872003a189057a39dc6ecea088; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_security_config
    ADD CONSTRAINT "PK_1872003a189057a39dc6ecea088" PRIMARY KEY (id);


--
-- Name: payments PK_197ab7af18c93fbb0c9b28b4a59; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "PK_197ab7af18c93fbb0c9b28b4a59" PRIMARY KEY (id);


--
-- Name: audit_logs PK_1bb179d048bbc581caa3b013439; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "PK_1bb179d048bbc581caa3b013439" PRIMARY KEY (id);


--
-- Name: investment_holdings PK_2091fdb00bc8fd75df48865d0db; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_holdings
    ADD CONSTRAINT "PK_2091fdb00bc8fd75df48865d0db" PRIMARY KEY (id);


--
-- Name: bnpl_plans PK_2286acd9256cacaad47a70f8366; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_plans
    ADD CONSTRAINT "PK_2286acd9256cacaad47a70f8366" PRIMARY KEY (id);


--
-- Name: bnpl_collection_priorities PK_291192e678e352df9becc5cf0d0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_collection_priorities
    ADD CONSTRAINT "PK_291192e678e352df9becc5cf0d0" PRIMARY KEY (id);


--
-- Name: ticket_messages PK_37beb692dedf7eccb4e519ccec1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT "PK_37beb692dedf7eccb4e519ccec1" PRIMARY KEY (id);


--
-- Name: disputes PK_3c97580d01c1a4b0b345c42a107; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disputes
    ADD CONSTRAINT "PK_3c97580d01c1a4b0b345c42a107" PRIMARY KEY (id);


--
-- Name: investment_nav_snapshots PK_40aa7373c5d8d8171f73b8545a3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_nav_snapshots
    ADD CONSTRAINT "PK_40aa7373c5d8d8171f73b8545a3" PRIMARY KEY (id);


--
-- Name: savings_transactions PK_415ed2feae799fb45637508b996; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.savings_transactions
    ADD CONSTRAINT "PK_415ed2feae799fb45637508b996" PRIMARY KEY (id);


--
-- Name: app_settings PK_4800b266ba790931744b3e53a74; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT "PK_4800b266ba790931744b3e53a74" PRIMARY KEY (id);


--
-- Name: bnpl_installments PK_4d7cf5a7cc597c353f2c46d09e5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_installments
    ADD CONSTRAINT "PK_4d7cf5a7cc597c353f2c46d09e5" PRIMARY KEY (id);


--
-- Name: reconciliation_runs PK_4edbdb165c9e754997036a4176a; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reconciliation_runs
    ADD CONSTRAINT "PK_4edbdb165c9e754997036a4176a" PRIMARY KEY (id);


--
-- Name: adjustment_requests PK_53c13952ca8850e9886c38b1e56; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.adjustment_requests
    ADD CONSTRAINT "PK_53c13952ca8850e9886c38b1e56" PRIMARY KEY (id);


--
-- Name: accounts PK_5a7a02c20412299d198e097a8fe; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "PK_5a7a02c20412299d198e097a8fe" PRIMARY KEY (id);


--
-- Name: apex_organizations PK_5bcbd3ebb64085c39e5cf2f0f8f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.apex_organizations
    ADD CONSTRAINT "PK_5bcbd3ebb64085c39e5cf2f0f8f" PRIMARY KEY (id);


--
-- Name: loans PK_5c6942c1e13e4de135c5203ee61; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loans
    ADD CONSTRAINT "PK_5c6942c1e13e4de135c5203ee61" PRIMARY KEY (id);


--
-- Name: fee_pots PK_6342eaea1748fba323bcd8f525b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fee_pots
    ADD CONSTRAINT "PK_6342eaea1748fba323bcd8f525b" PRIMARY KEY (id);


--
-- Name: bnpl_plan_configs PK_63edcaad1fe9a726cf998a47806; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_plan_configs
    ADD CONSTRAINT "PK_63edcaad1fe9a726cf998a47806" PRIMARY KEY (id);


--
-- Name: investment_pricing_config PK_671c51446fea08383ab8bda647d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_pricing_config
    ADD CONSTRAINT "PK_671c51446fea08383ab8bda647d" PRIMARY KEY (id);


--
-- Name: organizations PK_6b031fcd0863e3f6b44230163f9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT "PK_6b031fcd0863e3f6b44230163f9" PRIMARY KEY (id);


--
-- Name: journal_lines PK_70cba2da4588cee8921f73ef136; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT "PK_70cba2da4588cee8921f73ef136" PRIMARY KEY (id);


--
-- Name: bnpl_collection_playbooks PK_74af49ad9479cf1bd532b401f2a; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_collection_playbooks
    ADD CONSTRAINT "PK_74af49ad9479cf1bd532b401f2a" PRIMARY KEY (id);


--
-- Name: savings_accounts PK_75c3ac9a54f19179f999beb9cc7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.savings_accounts
    ADD CONSTRAINT "PK_75c3ac9a54f19179f999beb9cc7" PRIMARY KEY (id);


--
-- Name: notification_templates PK_76f0fc48b8d057d2ae7f3a2848a; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT "PK_76f0fc48b8d057d2ae7f3a2848a" PRIMARY KEY (id);


--
-- Name: investment_products PK_7721e1a1ba3d642f93a2be7c497; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_products
    ADD CONSTRAINT "PK_7721e1a1ba3d642f93a2be7c497" PRIMARY KEY (id);


--
-- Name: share_issuance_cycles PK_7df8a85462b621b01d7c2f4228f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.share_issuance_cycles
    ADD CONSTRAINT "PK_7df8a85462b621b01d7c2f4228f" PRIMARY KEY (id);


--
-- Name: distribution_payments PK_7fffc3592b09b535aaa6a73b520; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_payments
    ADD CONSTRAINT "PK_7fffc3592b09b535aaa6a73b520" PRIMARY KEY (id);


--
-- Name: sms_logs PK_811e3a63f5e14a50475c6e8be3d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_logs
    ADD CONSTRAINT "PK_811e3a63f5e14a50475c6e8be3d" PRIMARY KEY (id);


--
-- Name: bnpl_catalog_items PK_851e52aead4a0f184cdb5d6b160; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_catalog_items
    ADD CONSTRAINT "PK_851e52aead4a0f184cdb5d6b160" PRIMARY KEY (id);


--
-- Name: support_tickets PK_942e8d8f5df86100471d2324643; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT "PK_942e8d8f5df86100471d2324643" PRIMARY KEY (id);


--
-- Name: device_sessions PK_94d0c25305680904fc03285a38e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_sessions
    ADD CONSTRAINT "PK_94d0c25305680904fc03285a38e" PRIMARY KEY (id);


--
-- Name: bnpl_catalog_images PK_97882b9e3996847dc574f813734; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_catalog_images
    ADD CONSTRAINT "PK_97882b9e3996847dc574f813734" PRIMARY KEY (id);


--
-- Name: bnpl_idempotency_keys PK_9ed4b2dc8f63971890e11f69a9e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_idempotency_keys
    ADD CONSTRAINT "PK_9ed4b2dc8f63971890e11f69a9e" PRIMARY KEY (id);


--
-- Name: loan_repayments PK_a37968e2dcfb72f910f5480cc16; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_repayments
    ADD CONSTRAINT "PK_a37968e2dcfb72f910f5480cc16" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: bnpl_exception_reasons PK_a47c79b9b09ed8cd370e2ca6945; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_exception_reasons
    ADD CONSTRAINT "PK_a47c79b9b09ed8cd370e2ca6945" PRIMARY KEY (id);


--
-- Name: journal_entries PK_a70368e64230434457c8d007ab3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT "PK_a70368e64230434457c8d007ab3" PRIMARY KEY (id);


--
-- Name: investment_orders PK_aab8ed16bf02961918c3c389c5a; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_orders
    ADD CONSTRAINT "PK_aab8ed16bf02961918c3c389c5a" PRIMARY KEY (id);


--
-- Name: bnpl_processing_steps PK_ad474849e96284103f8e1b5a2dd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_processing_steps
    ADD CONSTRAINT "PK_ad474849e96284103f8e1b5a2dd" PRIMARY KEY (id);


--
-- Name: investment_eligibility_rules PK_ad53c06922215fcf845f71f5f56; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_eligibility_rules
    ADD CONSTRAINT "PK_ad53c06922215fcf845f71f5f56" PRIMARY KEY (id);


--
-- Name: bnpl_exception_cases PK_b47ea28756a8fe9517ddc3e98d8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_exception_cases
    ADD CONSTRAINT "PK_b47ea28756a8fe9517ddc3e98d8" PRIMARY KEY (id);


--
-- Name: kyc_submissions PK_b6ce86b4b10d774272de1730a71; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kyc_submissions
    ADD CONSTRAINT "PK_b6ce86b4b10d774272de1730a71" PRIMARY KEY (id);


--
-- Name: distributions PK_b73beffd2ed658ba71d8bd7d820; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributions
    ADD CONSTRAINT "PK_b73beffd2ed658ba71d8bd7d820" PRIMARY KEY (id);


--
-- Name: webhook_logs PK_c41f6cdf59cdfe3704807650896; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT "PK_c41f6cdf59cdfe3704807650896" PRIMARY KEY (id);


--
-- Name: bnpl_approval_requests PK_c67ba3efddae23412616260ce3b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_approval_requests
    ADD CONSTRAINT "PK_c67ba3efddae23412616260ce3b" PRIMARY KEY (id);


--
-- Name: incidents PK_ccb34c01719889017e2246469f9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT "PK_ccb34c01719889017e2246469f9" PRIMARY KEY (id);


--
-- Name: secrets PK_d4ff48ddba1883d4dc142b9c697; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secrets
    ADD CONSTRAINT "PK_d4ff48ddba1883d4dc142b9c697" PRIMARY KEY (id);


--
-- Name: saved_payment_methods PK_d92af22c1c4ce0a5f8d7532e286; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_payment_methods
    ADD CONSTRAINT "PK_d92af22c1c4ce0a5f8d7532e286" PRIMARY KEY (id);


--
-- Name: feature_flags PK_db657d344e9caacfc9d5cf8bbac; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT "PK_db657d344e9caacfc9d5cf8bbac" PRIMARY KEY (id);


--
-- Name: redemption_requests PK_dd0e5a10ff681bf5b00fc80dbb0; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redemption_requests
    ADD CONSTRAINT "PK_dd0e5a10ff681bf5b00fc80dbb0" PRIMARY KEY (id);


--
-- Name: bnpl_risk_flags PK_df1d4af80da87a11eaeb6b22608; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_risk_flags
    ADD CONSTRAINT "PK_df1d4af80da87a11eaeb6b22608" PRIMARY KEY (id);


--
-- Name: investment_product_versions PK_dff0f92a97f8b810a50de71780c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_product_versions
    ADD CONSTRAINT "PK_dff0f92a97f8b810a50de71780c" PRIMARY KEY (id);


--
-- Name: fee_share_ledger PK_e7389eb6cda38b28ee9798bbfc5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fee_share_ledger
    ADD CONSTRAINT "PK_e7389eb6cda38b28ee9798bbfc5" PRIMARY KEY (id);


--
-- Name: referrals PK_ea9980e34f738b6252817326c08; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT "PK_ea9980e34f738b6252817326c08" PRIMARY KEY (id);


--
-- Name: fee_withdrawal_requests PK_ecc4979b8a1a69387501e99cf8e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fee_withdrawal_requests
    ADD CONSTRAINT "PK_ecc4979b8a1a69387501e99cf8e" PRIMARY KEY (id);


--
-- Name: global_risk_rules PK_efeed26dfacd0721ff19881d811; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_risk_rules
    ADD CONSTRAINT "PK_efeed26dfacd0721ff19881d811" PRIMARY KEY (id);


--
-- Name: bnpl_subscriptions PK_f579056411b5a3add2bfe91bd28; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_subscriptions
    ADD CONSTRAINT "PK_f579056411b5a3add2bfe91bd28" PRIMARY KEY (id);


--
-- Name: policy_templates PK_f7f52132aef1a1401aaf4b03928; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_templates
    ADD CONSTRAINT "PK_f7f52132aef1a1401aaf4b03928" PRIMARY KEY (id);


--
-- Name: in_app_notifications PK_f871e2a23724692bbb5b3b75c98; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.in_app_notifications
    ADD CONSTRAINT "PK_f871e2a23724692bbb5b3b75c98" PRIMARY KEY (id);


--
-- Name: bnpl_collection_queues PK_fbcb64c025d11ab42a5b0e6f0f8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_collection_queues
    ADD CONSTRAINT "PK_fbcb64c025d11ab42a5b0e6f0f8" PRIMARY KEY (id);


--
-- Name: tenant_onboarding_requests PK_fd6e77334ba6f14a80da504c797; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_onboarding_requests
    ADD CONSTRAINT "PK_fd6e77334ba6f14a80da504c797" PRIMARY KEY (id);


--
-- Name: login_history PK_fe377f36d49c39547cb6b9f0727; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT "PK_fe377f36d49c39547cb6b9f0727" PRIMARY KEY (id);


--
-- Name: investment_corporate_actions PK_ff7a694493a61e7a9fcc26318df; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_corporate_actions
    ADD CONSTRAINT "PK_ff7a694493a61e7a9fcc26318df" PRIMARY KEY (id);


--
-- Name: users UQ_0e438a8460e5816e07aeb6b334f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_0e438a8460e5816e07aeb6b334f" UNIQUE (phone_hash);


--
-- Name: investment_pricing_config UQ_147074b2f021162c388bbbb3574; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_pricing_config
    ADD CONSTRAINT "UQ_147074b2f021162c388bbbb3574" UNIQUE (product_id);


--
-- Name: global_security_config UQ_1acbe8a551394495fc833d190c3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_security_config
    ADD CONSTRAINT "UQ_1acbe8a551394495fc833d190c3" UNIQUE (key);


--
-- Name: bnpl_processing_steps UQ_1e57c5ea736fe6a9fabb6ea1283; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_processing_steps
    ADD CONSTRAINT "UQ_1e57c5ea736fe6a9fabb6ea1283" UNIQUE (idempotency_key);


--
-- Name: feature_flags UQ_36d0344370584b4d6a953c53a69; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT "UQ_36d0344370584b4d6a953c53a69" UNIQUE (key);


--
-- Name: accounts UQ_490319656e54a7957dc1fed027c; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "UQ_490319656e54a7957dc1fed027c" UNIQUE (code);


--
-- Name: users UQ_73c6d38fdf47c60c087e9857699; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_73c6d38fdf47c60c087e9857699" UNIQUE (email_hash);


--
-- Name: organizations UQ_7e27c3b62c681fbe3e2322535f2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT "UQ_7e27c3b62c681fbe3e2322535f2" UNIQUE (code);


--
-- Name: apex_organizations UQ_82db7e71515767be8bb172a66b5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.apex_organizations
    ADD CONSTRAINT "UQ_82db7e71515767be8bb172a66b5" UNIQUE (code);


--
-- Name: notification_templates UQ_8984071929794bfee03a46d2035; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT "UQ_8984071929794bfee03a46d2035" UNIQUE (key);


--
-- Name: bnpl_plan_configs UQ_8dff378956ca590bb1435632424; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_plan_configs
    ADD CONSTRAINT "UQ_8dff378956ca590bb1435632424" UNIQUE (organization_id);


--
-- Name: app_settings UQ_975c2db59c65c05fd9c6b63a2ab; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT "UQ_975c2db59c65c05fd9c6b63a2ab" UNIQUE (key);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: users UQ_ba10055f9ef9690e77cf6445cba; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_ba10055f9ef9690e77cf6445cba" UNIQUE (referral_code);


--
-- Name: webhook_logs UQ_d354c3da9b4ea41126f95add781; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT "UQ_d354c3da9b4ea41126f95add781" UNIQUE (event_id);


--
-- Name: secrets UQ_e603027e41ab59481c899780859; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secrets
    ADD CONSTRAINT "UQ_e603027e41ab59481c899780859" UNIQUE (key);


--
-- Name: bnpl_idempotency_keys UQ_ea43bf294268f02d8f02fcb581e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_idempotency_keys
    ADD CONSTRAINT "UQ_ea43bf294268f02d8f02fcb581e" UNIQUE (idempotency_key);


--
-- Name: global_risk_rules UQ_ef8436fe7bbeace54b83c1e3491; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_risk_rules
    ADD CONSTRAINT "UQ_ef8436fe7bbeace54b83c1e3491" UNIQUE ("ruleKey");


--
-- Name: IDX_095076c892fd4f640ea401d83a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_095076c892fd4f640ea401d83a" ON public.in_app_notifications USING btree (user_id);


--
-- Name: IDX_18af9fcaffac6d6d3b28130e14; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_18af9fcaffac6d6d3b28130e14" ON public.referrals USING btree (referrer_id);


--
-- Name: IDX_2cd10fda8276bb995288acfbfb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_2cd10fda8276bb995288acfbfb" ON public.audit_logs USING btree (created_at);


--
-- Name: IDX_3703ae83894cb2e054d405b927; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_3703ae83894cb2e054d405b927" ON public.referrals USING btree (referee_id);


--
-- Name: IDX_a283f37e08edf5e37d38b375ee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_a283f37e08edf5e37d38b375ee" ON public.user_activities USING btree (user_id);


--
-- Name: IDX_ad9ce49cb73c0b33746a56b6bd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_ad9ce49cb73c0b33746a56b6bd" ON public.login_history USING btree (user_id);


--
-- Name: IDX_c72beecc73a7cc4beb9dd9c183; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_c72beecc73a7cc4beb9dd9c183" ON public.referrals USING btree (referral_code);


--
-- Name: IDX_ef882827dd1e8797c570d181b6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_ef882827dd1e8797c570d181b6" ON public.saved_payment_methods USING btree (user_id);


--
-- Name: users FK_04a7ea2efc02906c0dfbeb5d4c1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "FK_04a7ea2efc02906c0dfbeb5d4c1" FOREIGN KEY (apex_org_id) REFERENCES public.apex_organizations(id);


--
-- Name: share_issuance_cycles FK_1a0b4cd7d83fadeba17639e48e6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.share_issuance_cycles
    ADD CONSTRAINT "FK_1a0b4cd7d83fadeba17639e48e6" FOREIGN KEY (product_id) REFERENCES public.investment_products(id);


--
-- Name: journal_lines FK_1fd23ae91f0c24764b4e581c72e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT "FK_1fd23ae91f0c24764b4e581c72e" FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id);


--
-- Name: users FK_21a659804ed7bf61eb91688dea7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "FK_21a659804ed7bf61eb91688dea7" FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: investment_product_versions FK_43d223009f1bb7ba9e41c9cd68b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_product_versions
    ADD CONSTRAINT "FK_43d223009f1bb7ba9e41c9cd68b" FOREIGN KEY (product_id) REFERENCES public.investment_products(id);


--
-- Name: bnpl_plans FK_6390f21aa1b631def7eb0eb8509; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_plans
    ADD CONSTRAINT "FK_6390f21aa1b631def7eb0eb8509" FOREIGN KEY (catalog_item_id) REFERENCES public.bnpl_catalog_items(id);


--
-- Name: investment_holdings FK_63c0ca878ca0c778150e04d4565; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_holdings
    ADD CONSTRAINT "FK_63c0ca878ca0c778150e04d4565" FOREIGN KEY (product_id) REFERENCES public.investment_products(id);


--
-- Name: bnpl_subscriptions FK_675bb10d5d14c6f8d5bde62b04a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_subscriptions
    ADD CONSTRAINT "FK_675bb10d5d14c6f8d5bde62b04a" FOREIGN KEY (plan_id) REFERENCES public.bnpl_plans(id);


--
-- Name: bnpl_installments FK_6dbdfef1a9677536622c355d0c2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_installments
    ADD CONSTRAINT "FK_6dbdfef1a9677536622c355d0c2" FOREIGN KEY (subscription_id) REFERENCES public.bnpl_subscriptions(id);


--
-- Name: ticket_messages FK_75b3a5f421dbf7b73778da519cb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT "FK_75b3a5f421dbf7b73778da519cb" FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: distribution_payments FK_772ccc78b39372e0b678c1cba07; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distribution_payments
    ADD CONSTRAINT "FK_772ccc78b39372e0b678c1cba07" FOREIGN KEY (distribution_id) REFERENCES public.distributions(id);


--
-- Name: investment_eligibility_rules FK_7af26343958ccf3c77ba5ed8755; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_eligibility_rules
    ADD CONSTRAINT "FK_7af26343958ccf3c77ba5ed8755" FOREIGN KEY (product_id) REFERENCES public.investment_products(id);


--
-- Name: organizations FK_8a0f01b2d5db92c82b35913844e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT "FK_8a0f01b2d5db92c82b35913844e" FOREIGN KEY (apex_org_id) REFERENCES public.apex_organizations(id);


--
-- Name: redemption_requests FK_8db1ad9baac214fb9201a986c54; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redemption_requests
    ADD CONSTRAINT "FK_8db1ad9baac214fb9201a986c54" FOREIGN KEY (holding_id) REFERENCES public.investment_holdings(id);


--
-- Name: investment_orders FK_a19645905e1c34c7d3a8757a4c6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investment_orders
    ADD CONSTRAINT "FK_a19645905e1c34c7d3a8757a4c6" FOREIGN KEY (product_id) REFERENCES public.investment_products(id);


--
-- Name: savings_transactions FK_c8eba2bb069f6785e65a0a08f34; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.savings_transactions
    ADD CONSTRAINT "FK_c8eba2bb069f6785e65a0a08f34" FOREIGN KEY (account_id) REFERENCES public.savings_accounts(id);


--
-- Name: reconciliation_results FK_d6dfcd58b73d49105b8c5b65342; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reconciliation_results
    ADD CONSTRAINT "FK_d6dfcd58b73d49105b8c5b65342" FOREIGN KEY (run_id) REFERENCES public.reconciliation_runs(id);


--
-- Name: bnpl_catalog_images FK_dc836293349ad96fc05cb9bd191; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bnpl_catalog_images
    ADD CONSTRAINT "FK_dc836293349ad96fc05cb9bd191" FOREIGN KEY (catalog_item_id) REFERENCES public.bnpl_catalog_items(id) ON DELETE CASCADE;


--
-- Name: loan_repayments FK_fe78de3cafcee22d993dc917be1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_repayments
    ADD CONSTRAINT "FK_fe78de3cafcee22d993dc917be1" FOREIGN KEY (loan_id) REFERENCES public.loans(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 7LF6XupuJlEB4G6r3wDY664qvsSshXUWQUFrc0ivQ4bpcCKr43LND4XBresXy2C

